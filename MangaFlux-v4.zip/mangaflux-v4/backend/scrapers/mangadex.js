const axios = require('axios');
const Manga = require('../models/Manga');
const Chapter = require('../models/Chapter');

const BASE = 'https://api.mangadex.org';
const COVERS = 'https://uploads.mangadex.org/covers';

/**
 * MangaDex expects bracket-style array/object query params, e.g.
 *   order[followedCount]=desc
 *   includes[]=cover_art&includes[]=author
 * Axios's default paramsSerializer does NOT produce this format for nested
 * objects (it stringifies them as [object Object]) and serializes arrays as
 * repeated keys without brackets — both silently break MangaDex filtering
 * and sorting (requests still succeed, but return unsorted/unfiltered data).
 * This custom serializer fixes that.
 */
function serializeParams(params) {
  const parts = [];
  const add = (key, value) => parts.push(`${encodeURIComponent(key)}=${encodeURIComponent(value)}`);

  for (const [key, val] of Object.entries(params)) {
    if (val === undefined || val === null) continue;
    if (Array.isArray(val)) {
      val.forEach(v => add(`${key}[]`, v));
    } else if (typeof val === 'object') {
      for (const [subKey, subVal] of Object.entries(val)) {
        add(`${key}[${subKey}]`, subVal);
      }
    } else {
      add(key, val);
    }
  }
  return parts.join('&');
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

/**
 * Retry wrapper. Returns { data, error } instead of swallowing the failure
 * reason — the caller needs to know WHY something came back empty so the
 * run summary can report real causes instead of a misleadingly clean count.
 *
 * MangaDex's /at-home/server/{id} endpoint (used to fetch actual page images)
 * has a much stricter, separately-tracked rate limit than the main API. The
 * previous version used the same short retry window for both, which meant
 * page-fetches were silently exhausting their retries under normal scraping
 * volume — manga records still saved fine, chapters/pages just never landed.
 */
async function apiGet(url, params = {}, { retries = 4, baseDelay = 2000, label = '' } = {}) {
  let lastErr = null;
  for (let i = 0; i < retries; i++) {
    try {
      const res = await axios.get(url, {
        params,
        paramsSerializer: serializeParams,
        timeout: 20000,
        headers: { 'User-Agent': 'MangaFlux/3.0 (contact@mangaflux.com)' },
      });
      return { data: res.data, error: null };
    } catch (e) {
      const status = e.response?.status;
      lastErr = status ? `HTTP ${status}` : e.code || e.message;

      if (status === 429 || status === 503) {
        const wait = baseDelay * (i + 1);
        console.log(`[MangaDex]${label ? ` [${label}]` : ''} ${status === 429 ? 'Rate limited' : 'Service unavailable'} — retrying in ${wait}ms (${i + 1}/${retries})`);
        await sleep(wait);
        continue;
      }
      if (e.code === 'ECONNABORTED' || e.code === 'ETIMEDOUT') {
        console.log(`[MangaDex]${label ? ` [${label}]` : ''} Timed out — retrying (${i + 1}/${retries})`);
        await sleep(1500);
        continue;
      }
      // Non-retryable error (404, network down, etc.) — stop immediately
      console.error(`[MangaDex]${label ? ` [${label}]` : ''} ${url} failed: ${lastErr}`);
      return { data: null, error: lastErr };
    }
  }
  console.error(`[MangaDex]${label ? ` [${label}]` : ''} ${url} failed after ${retries} retries (${lastErr})`);
  return { data: null, error: lastErr || 'max-retries-exceeded' };
}

async function fetchPopularManga(limit = 25) {
  const { data, error } = await apiGet(`${BASE}/manga`, {
    limit,
    order: { followedCount: 'desc' },
    includes: ['cover_art', 'author', 'artist'],
    availableTranslatedLanguage: ['en'],
    contentRating: ['safe', 'suggestive'],
    hasAvailableChapters: 'true',
  }, { label: 'manga-list' });
  return { list: data?.data || [], error };
}

async function fetchChapters(mangadexId, limit = 10) {
  const { data, error } = await apiGet(`${BASE}/chapter`, {
    manga: mangadexId,
    limit,
    translatedLanguage: ['en'],
    order: { chapter: 'desc' },
    contentRating: ['safe', 'suggestive'],
    includes: ['scanlation_group'],
  }, { label: 'chapter-list' });
  return { list: data?.data || [], error };
}

async function fetchChapterPages(chapterId) {
  // Stricter retry/backoff tuned for the at-home/server endpoint specifically
  const { data, error } = await apiGet(`${BASE}/at-home/server/${chapterId}`, {}, {
    retries: 5, baseDelay: 3000, label: 'pages',
  });
  if (!data) return { pages: [], error };

  const { baseUrl, chapter } = data;
  const files = chapter?.dataSaver || chapter?.data;
  const folder = chapter?.dataSaver ? 'data-saver' : 'data';
  if (!files?.length) return { pages: [], error: 'no-files-in-response' };

  const pages = files.map((file, i) => ({ pageNumber: i + 1, imageUrl: `${baseUrl}/${folder}/${chapter.hash}/${file}` }));
  return { pages, error: null };
}

function extractCover(manga) {
  const rel = manga.relationships?.find(r => r.type === 'cover_art');
  if (rel?.attributes?.fileName) return `${COVERS}/${manga.id}/${rel.attributes.fileName}.512.jpg`;
  return '';
}

function extractAuthors(manga, type = 'author') {
  return manga.relationships?.filter(r => r.type === type)
    .map(r => r.attributes?.name || '').filter(Boolean) || [];
}

async function scrapeManga(limit = 25) {
  console.log('[Scraper] ── Starting MangaDex scrape ──');
  const { list: mangaList, error: listError } = await fetchPopularManga(limit);

  if (!mangaList.length) {
    console.log(`[Scraper] No manga returned (${listError || 'empty response'}). Check network connectivity or MangaDex status (https://status.mangadex.org).`);
    return { ok: false, processed: 0, errors: 0, newChapters: 0, reason: listError || 'empty-response' };
  }
  console.log(`[Scraper] Fetched ${mangaList.length} manga from MangaDex. Processing...`);

  let mangaOk = 0, mangaFailed = 0, newChaptersTotal = 0;
  let chaptersAttempted = 0, chaptersSkippedExisting = 0, chaptersFailedPages = 0, chaptersFailedOther = 0;
  const failureSamples = [];

  for (const [idx, item] of mangaList.entries()) {
    let title = `Untitled (${item.id?.slice(0, 6) || '??'})`;
    try {
      const attrs = item.attributes;
      title = attrs.title?.en
        || attrs.title?.['ja-ro']
        || attrs.altTitles?.find(t => t.en)?.en
        || Object.values(attrs.title || {})[0]
        || title;

      const coverImage = extractCover(item);
      const authors = extractAuthors(item, 'author');
      const artists = extractAuthors(item, 'artist');

      const type = attrs.originalLanguage === 'ko' ? 'manhwa'
                 : attrs.originalLanguage === 'zh' || attrs.originalLanguage === 'zh-hk' ? 'manhua'
                 : 'manga';

      const status = attrs.status === 'completed' ? 'completed'
                   : attrs.status === 'hiatus'    ? 'hiatus'
                   : attrs.status === 'cancelled' ? 'cancelled'
                   : 'ongoing';

      const genres = attrs.tags?.filter(t => t.attributes?.group === 'genre')
        .map(t => t.attributes?.name?.en).filter(Boolean) || [];

      const mangaData = {
        title,
        description: attrs.description?.en?.slice(0, 2000) || '',
        coverImage, type, status, genres, authors, artists,
        releaseYear: attrs.year || null,
        source: 'mangadex', sourceId: item.id,
        sourceUrl: `https://mangadex.org/title/${item.id}`,
        lastUpdated: new Date(),
      };

      let manga = await Manga.findOne({ sourceId: item.id });
      if (manga) {
        Object.assign(manga, mangaData);
        await manga.save();
      } else {
        const slug = await Manga.generateUniqueSlug(title, item.id);
        manga = await Manga.create({ ...mangaData, slug });
      }

      const { list: chapters, error: chListError } = await fetchChapters(item.id, 10);
      await sleep(500);

      if (chListError) {
        failureSamples.push(`${title}: chapter list fetch failed (${chListError})`);
      }

      let newChs = 0;
      for (const ch of chapters) {
        chaptersAttempted++;
        const chNum = parseFloat(ch.attributes?.chapter);
        if (Number.isNaN(chNum)) { chaptersFailedOther++; continue; }

        const exists = await Chapter.findOne({ manga: manga._id, number: chNum });
        if (exists) { chaptersSkippedExisting++; continue; }

        await sleep(600);
        const { pages, error: pageError } = await fetchChapterPages(ch.id);
        if (!pages.length) {
          chaptersFailedPages++;
          if (failureSamples.length < 10) failureSamples.push(`${title} ch.${chNum}: page fetch failed (${pageError || 'no pages returned'})`);
          continue;
        }

        try {
          await Chapter.create({
            manga: manga._id, number: chNum,
            title: ch.attributes?.title || `Chapter ${chNum}`,
            pages, source: 'mangadex', sourceId: ch.id,
            sourceUrl: `https://mangadex.org/chapter/${ch.id}`,
          });
        } catch (chErr) {
          if (chErr.code === 11000) { chaptersSkippedExisting++; continue; } // race-condition duplicate
          chaptersFailedOther++;
          if (failureSamples.length < 10) failureSamples.push(`${title} ch.${chNum}: save failed (${chErr.message})`);
          continue;
        }

        await Manga.findByIdAndUpdate(manga._id, {
          $inc: { chapterCount: 1 },
          $max: { latestChapter: chNum },
          lastUpdated: new Date(),
        });
        newChs++;
      }

      newChaptersTotal += newChs;
      console.log(`[Scraper] (${idx + 1}/${mangaList.length}) ${title} — ${newChs} new chapter(s) of ${chapters.length} checked`);
      mangaOk++;
    } catch (e) {
      console.error(`[Scraper] ✗ ${title} failed entirely:`, e.name, '-', e.message);
      if (e.errors) {
        // Mongoose ValidationError — list each field that failed
        Object.entries(e.errors).forEach(([field, err]) => console.error(`    field "${field}": ${err.message}`));
      }
      if (process.env.DEBUG_SCRAPER) console.error(e.stack);
      failureSamples.push(`${title}: ${e.name || 'Error'} - ${e.message || 'no message'}`);
      mangaFailed++;
    }
  }

  const summary = {
    ok: true,
    processed: mangaOk,
    errors: mangaFailed,
    newChapters: newChaptersTotal,
    chapters: {
      attempted: chaptersAttempted,
      added: newChaptersTotal,
      skippedExisting: chaptersSkippedExisting,
      failedPageFetch: chaptersFailedPages,
      failedOther: chaptersFailedOther,
    },
    failureSamples,
  };

  console.log(`[Scraper] ── Done: ${mangaOk} manga ok, ${mangaFailed} manga failed, ${newChaptersTotal} new chapters added (${chaptersFailedPages} chapter page-fetches failed, ${chaptersSkippedExisting} already existed) ──`);
  if (newChaptersTotal === 0 && chaptersAttempted > 0) {
    console.warn('[Scraper] ⚠ Manga were saved but ZERO chapters were added. This usually means the /at-home/server endpoint is being rate-limited — check the failure samples below or try running again in a few minutes.');
    failureSamples.slice(0, 5).forEach(s => console.warn(`  - ${s}`));
  }

  return summary;
}

module.exports = { scrapeManga };
