const mongoose = require('mongoose');

const readingListSchema = new mongoose.Schema({
  user:        { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  name:        { type: String, required: true, trim: true, maxlength: 60 },
  description: { type: String, default: '', maxlength: 300 },
  coverImage:  { type: String, default: '' }, // optional custom cover; falls back to first manga's cover in UI
  manga:       [{ type: mongoose.Schema.Types.ObjectId, ref: 'Manga' }],
  isPublic:    { type: Boolean, default: true },
  likes:       [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  slug:        { type: String, unique: true, sparse: true }, // for shareable public URLs
}, { timestamps: true });

readingListSchema.index({ user: 1, createdAt: -1 });

function slugify(str = '') {
  return String(str).toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60);
}

readingListSchema.statics.generateUniqueSlug = async function (name, userId) {
  const List = this;
  let base = slugify(name) || `list-${Date.now()}`;
  let candidate = `${base}-${String(userId).slice(-5)}`;
  let suffix = 1;
  while (suffix < 20 && await List.exists({ slug: candidate })) {
    candidate = `${base}-${String(userId).slice(-5)}-${suffix}`;
    suffix++;
  }
  return candidate;
};

readingListSchema.pre('save', async function (next) {
  try {
    if (!this.slug) this.slug = await this.constructor.generateUniqueSlug(this.name, this.user);
    next();
  } catch (err) { next(err); }
});

module.exports = mongoose.model('ReadingList', readingListSchema);
