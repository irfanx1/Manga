const mongoose = require('mongoose');

const mangaSchema = new mongoose.Schema({
  title:             { type: String, required: true, trim: true },
  alternativeTitles: [String],
  description:       { type: String, default: '' },
  coverImage:        { type: String, default: '' },
  bannerImage:       { type: String, default: '' },
  type:   { type: String, enum: ['manga','manhwa','manhua','webtoon'], default: 'manga' },
  status: { type: String, enum: ['ongoing','completed','hiatus','cancelled'], default: 'ongoing' },
  genres:  [String],
  authors: [String],
  artists: [String],
  releaseYear: { type: Number, default: null },
  rating:       { type: Number, default: 0, min: 0, max: 10 },
  totalRatings: { type: Number, default: 0 },
  views:         { type: Number, default: 0 },
  bookmarkCount: { type: Number, default: 0 },
  chapterCount:  { type: Number, default: 0 },
  latestChapter: { type: Number, default: 0 },
  source:    { type: String, default: 'manual' },
  sourceId:  { type: String, default: '' },
  sourceUrl: { type: String, default: '' },
  slug:      { type: String, unique: true },
  isPublished: { type: Boolean, default: true },
  featured:    { type: Boolean, default: false },
  isPremium:   { type: Boolean, default: false },
  lastUpdated: { type: Date, default: Date.now },
}, { timestamps: true });

/**
 * Slugify helper — handles titles with non-Latin scripts (Korean/Chinese/Japanese)
 * which previously could collapse to an empty string and cause duplicate-key
 * errors on insert (every manhwa/manhua with no romanized title collided on "").
 */
function slugify(str = '') {
  return String(str)
    .toLowerCase()
    .normalize('NFKD').replace(/[\u0300-\u036f]/g, '') // strip accents
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80);
}

mangaSchema.statics.generateUniqueSlug = async function (title, fallbackId = '') {
  const Manga = this;
  let base = slugify(title);
  if (!base) base = fallbackId ? `title-${String(fallbackId).slice(0, 8)}` : `title-${Date.now()}`;

  let candidate = base;
  let suffix = 1;
  // Guard against infinite loop with a sane upper bound
  while (suffix < 50 && await Manga.exists({ slug: candidate })) {
    candidate = `${base}-${suffix}`;
    suffix++;
  }
  return candidate;
};

mangaSchema.pre('save', async function (next) {
  try {
    if (!this.slug) {
      this.slug = await this.constructor.generateUniqueSlug(this.title, this.sourceId);
    }
    next();
  } catch (err) {
    next(err);
  }
});

mangaSchema.index({ title: 'text', alternativeTitles: 'text', description: 'text' });
mangaSchema.index({ genres: 1, status: 1, type: 1, views: -1, rating: -1, lastUpdated: -1 });

module.exports = mongoose.model('Manga', mangaSchema);
