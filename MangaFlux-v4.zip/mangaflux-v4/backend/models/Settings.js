const mongoose = require('mongoose');

// Singleton-style document — there should only ever be one Settings record.
const settingsSchema = new mongoose.Schema({
  siteName:   { type: String, default: 'MangaFlux' },
  logoUrl:    { type: String, default: '' },   // empty = use the default text/icon logo
  faviconUrl: { type: String, default: '' },
}, { timestamps: true });

settingsSchema.statics.getSingleton = async function () {
  const Settings = this;
  let doc = await Settings.findOne();
  if (!doc) doc = await Settings.create({});
  return doc;
};

module.exports = mongoose.model('Settings', settingsSchema);
