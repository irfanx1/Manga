/**
 * Static achievement catalog. Achievements aren't stored as documents —
 * they're evaluated on the fly from a user's existing stats (chaptersRead,
 * streak, bookmarks, etc.) so there's no extra write-path or sync risk.
 * `User.unlockedAchievementIds` (an array of these `id` strings) is the only
 * thing persisted, purely so the UI can detect "newly unlocked" and show a
 * one-time celebration toast instead of re-celebrating every page load.
 */
const ACHIEVEMENTS = [
  { id: 'first_chapter',   label: 'First Steps',      description: 'Read your first chapter',              tier: 'bronze', check: (u) => u.stats.chaptersRead >= 1 },
  { id: 'chapters_25',     label: 'Getting Hooked',   description: 'Read 25 chapters',                      tier: 'bronze', check: (u) => u.stats.chaptersRead >= 25 },
  { id: 'chapters_100',    label: 'Bookworm',         description: 'Read 100 chapters',                     tier: 'silver', check: (u) => u.stats.chaptersRead >= 100 },
  { id: 'chapters_500',    label: 'Page Turner',      description: 'Read 500 chapters',                     tier: 'gold',   check: (u) => u.stats.chaptersRead >= 500 },
  { id: 'chapters_1000',   label: 'Living Library',   description: 'Read 1,000 chapters',                   tier: 'platinum', check: (u) => u.stats.chaptersRead >= 1000 },

  { id: 'streak_3',        label: 'Warming Up',       description: 'Maintain a 3-day reading streak',       tier: 'bronze', check: (u) => u.streak.longest >= 3 },
  { id: 'streak_7',        label: 'Committed',        description: 'Maintain a 7-day reading streak',       tier: 'silver', check: (u) => u.streak.longest >= 7 },
  { id: 'streak_30',       label: 'Unstoppable',      description: 'Maintain a 30-day reading streak',      tier: 'gold',   check: (u) => u.streak.longest >= 30 },
  { id: 'streak_100',      label: 'Legendary Reader', description: 'Maintain a 100-day reading streak',     tier: 'platinum', check: (u) => u.streak.longest >= 100 },

  { id: 'bookmarks_5',     label: 'Curator',          description: 'Bookmark 5 manga',                      tier: 'bronze', check: (u) => (u.bookmarks?.length || 0) >= 5 },
  { id: 'bookmarks_25',    label: 'Collector',        description: 'Bookmark 25 manga',                     tier: 'silver', check: (u) => (u.bookmarks?.length || 0) >= 25 },
  { id: 'bookmarks_100',   label: 'Archivist',        description: 'Bookmark 100 manga',                    tier: 'gold',   check: (u) => (u.bookmarks?.length || 0) >= 100 },

  { id: 'lists_1',         label: 'List Maker',       description: 'Create your first reading list',        tier: 'bronze', check: (u) => (u.listCount || 0) >= 1 },
  { id: 'lists_5',         label: 'Tastemaker',       description: 'Create 5 reading lists',                tier: 'silver', check: (u, ctx) => (ctx?.listCount || 0) >= 5 },

  { id: 'comments_10',     label: 'Conversationalist',description: 'Post 10 comments',                      tier: 'bronze', check: (u, ctx) => (ctx?.commentCount || 0) >= 10 },

  { id: 'night_owl',       label: 'Night Owl',        description: 'Read a chapter between midnight and 4am', tier: 'bronze', check: (u) => !!u.unlockedFlags?.nightOwl },
  { id: 'early_bird',      label: 'Early Bird',       description: 'Read a chapter between 5am and 7am',     tier: 'bronze', check: (u) => !!u.unlockedFlags?.earlyBird },

  { id: 'premium_member',  label: 'Supporter',        description: 'Subscribe to Premium',                  tier: 'gold',   check: (u) => !!u.isPremium },
];

const TIER_ORDER = { bronze: 0, silver: 1, gold: 2, platinum: 3 };

/**
 * Evaluates which achievements a user currently qualifies for.
 * `ctx` carries extra computed values (listCount, commentCount) that aren't
 * stored directly on the User document, to avoid denormalizing counts that
 * could drift out of sync.
 */
function evaluateAchievements(user, ctx = {}) {
  return ACHIEVEMENTS.map(a => ({
    ...a,
    unlocked: !!a.check(user, ctx),
  })).sort((a, b) => TIER_ORDER[a.tier] - TIER_ORDER[b.tier]);
}

module.exports = { ACHIEVEMENTS, evaluateAchievements, TIER_ORDER };
