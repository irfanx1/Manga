/**
 * reset-owner.js
 * ─────────────────────────────────────────────────────────────
 * One-off utility to delete the existing owner account so the
 * server creates a brand new one (using whatever ADMIN_EMAIL /
 * ADMIN_PASSWORD are currently in your .env) the next time you
 * start it with `npm run dev` or `node server.js`.
 *
 * Usage:
 *   cd backend
 *   node reset-owner.js
 *
 * Safe to delete this file afterwards.
 * ─────────────────────────────────────────────────────────────
 */

require('dotenv').config();
const mongoose = require('mongoose');
const readline = require('readline');

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/mangaflux';

function ask(question) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise(resolve => rl.question(question, ans => { rl.close(); resolve(ans); }));
}

async function main() {
  console.log('\nConnecting to MongoDB...');
  await mongoose.connect(MONGODB_URI);
  console.log('✓ Connected\n');

  const User = require('./models/User');
  const owner = await User.findOne({ role: 'owner' });

  if (!owner) {
    console.log('No owner account currently exists — nothing to reset.');
    console.log('Just start the server normally and one will be created automatically.\n');
    await mongoose.connection.close();
    return;
  }

  console.log('Current owner account found:');
  console.log(`  Username: ${owner.username}`);
  console.log(`  Email:    ${owner.email}`);
  console.log(`  Created:  ${owner.createdAt}\n`);

  console.log('This will DELETE this owner account.');
  console.log('The next time you start the server, a fresh owner account will be');
  console.log(`created automatically using ADMIN_EMAIL / ADMIN_PASSWORD from your .env`);
  console.log(`(currently: ${process.env.ADMIN_EMAIL || 'admin@mangaflux.com'} / ${process.env.ADMIN_PASSWORD ? '[set in .env]' : 'admin123 (default)'})\n`);

  const answer = await ask('Type "yes" to confirm deletion: ');

  if (answer.trim().toLowerCase() !== 'yes') {
    console.log('\nCancelled. Nothing was changed.\n');
    await mongoose.connection.close();
    return;
  }

  await User.deleteOne({ _id: owner._id });
  console.log('\n✓ Owner account deleted.');
  console.log('Now run "npm run dev" (or "node server.js") and a fresh owner account');
  console.log('will be created — the new credentials will be printed to the console');
  console.log('and saved to OWNER_CREDENTIALS.txt.\n');

  await mongoose.connection.close();
}

main().catch(err => {
  console.error('\n✗ Error:', err.message);
  process.exit(1);
});
