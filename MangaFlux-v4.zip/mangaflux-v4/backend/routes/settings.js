const express = require('express');
const Settings = require('../models/Settings');
const { protect, restrictTo } = require('../middleware/auth');
const router = express.Router();

const MAX_LOGO_BYTES = 1.5 * 1024 * 1024; // ~1.5MB decoded, generous for a logo

// ── Public: get current branding ─────────────────────────────────────────────
router.get('/', async (req, res) => {
  try {
    const settings = await Settings.getSingleton();
    res.json({ settings });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

// ── Admin: update site name ──────────────────────────────────────────────────
router.patch('/', protect, restrictTo('admin', 'owner'), async (req, res) => {
  try {
    const settings = await Settings.getSingleton();
    if (req.body.siteName !== undefined) settings.siteName = req.body.siteName.trim().slice(0, 40);
    await settings.save();
    res.json({ settings });
  } catch (err) { res.status(400).json({ message: err.message }); }
});

// ── Admin: upload logo as base64 data URL ────────────────────────────────────
// Accepts { dataUrl: "data:image/png;base64,...." } from a <input type=file>
// read via FileReader on the frontend — avoids needing multer/disk storage
// for what's just a small branding image.
router.post('/logo', protect, restrictTo('admin', 'owner'), async (req, res) => {
  try {
    const { dataUrl } = req.body;
    if (!dataUrl || !dataUrl.startsWith('data:image/')) {
      return res.status(400).json({ message: 'A valid image data URL is required' });
    }

    const base64Part = dataUrl.split(',')[1] || '';
    const approxBytes = base64Part.length * 0.75;
    if (approxBytes > MAX_LOGO_BYTES) {
      return res.status(413).json({ message: 'Logo image is too large — please use an image under ~1MB' });
    }

    const settings = await Settings.getSingleton();
    settings.logoUrl = dataUrl;
    await settings.save();
    res.json({ settings });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

// ── Admin: remove custom logo (revert to text/icon default) ──────────────────
router.delete('/logo', protect, restrictTo('admin', 'owner'), async (req, res) => {
  try {
    const settings = await Settings.getSingleton();
    settings.logoUrl = '';
    await settings.save();
    res.json({ settings });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

module.exports = router;
