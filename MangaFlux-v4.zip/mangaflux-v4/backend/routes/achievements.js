const express = require('express');
const User = require('../models/User');
const ReadingList = require('../models/ReadingList');
const Comment = require('../models/Comment');
const { evaluateAchievements } = require('../data/achievements');
const { protect } = require('../middleware/auth');
const router = express.Router();

// ── Get achievement progress for the current user ───────────────────────────
router.get('/', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    const [listCount, commentCount] = await Promise.all([
      ReadingList.countDocuments({ user: user._id }),
      Comment.countDocuments({ user: user._id, isDeleted: false }),
    ]);

    const evaluated = evaluateAchievements(user, { listCount, commentCount });

    // Detect newly-unlocked (unlocked now, but not in the stored list) so the
    // frontend can show a one-time celebration instead of re-celebrating
    // every time this endpoint is hit.
    const newlyUnlocked = evaluated.filter(a => a.unlocked && !user.unlockedAchievementIds.includes(a.id));

    if (newlyUnlocked.length > 0) {
      user.unlockedAchievementIds = [
        ...new Set([...user.unlockedAchievementIds, ...newlyUnlocked.map(a => a.id)]),
      ];
      await user.save();
    }

    res.json({
      achievements: evaluated.map(({ check, ...rest }) => rest), // strip the function before sending
      newlyUnlocked: newlyUnlocked.map(({ check, ...rest }) => rest),
      unlockedCount: evaluated.filter(a => a.unlocked).length,
      totalCount: evaluated.length,
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
