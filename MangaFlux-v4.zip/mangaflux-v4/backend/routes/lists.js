const express = require('express');
const ReadingList = require('../models/ReadingList');
const Manga = require('../models/Manga');
const { protect, optionalAuth } = require('../middleware/auth');
const router = express.Router();

// ── My lists ──────────────────────────────────────────────────────────────────
router.get('/mine', protect, async (req, res) => {
  try {
    const lists = await ReadingList.find({ user: req.user._id }).sort('-updatedAt')
      .populate('manga', 'title coverImage slug');
    res.json({ lists });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

// ── Public lists (discovery feed) ────────────────────────────────────────────
router.get('/discover', async (req, res) => {
  try {
    const { sort = '-createdAt', limit = 24 } = req.query;
    const lists = await ReadingList.find({ isPublic: true })
      .sort(sort === 'popular' ? '-likeCount' : sort)
      .limit(Math.min(Number(limit) || 24, 60))
      .populate('user', 'username avatar')
      .populate('manga', 'title coverImage slug');
    res.json({ lists });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

// ── Single list by slug (public view) ────────────────────────────────────────
router.get('/:slug', optionalAuth, async (req, res) => {
  try {
    const list = await ReadingList.findOne({ slug: req.params.slug })
      .populate('user', 'username avatar')
      .populate('manga', 'title coverImage slug type status rating chapterCount');
    if (!list) return res.status(404).json({ message: 'List not found' });
    if (!list.isPublic && (!req.user || req.user._id.toString() !== list.user._id.toString())) {
      return res.status(403).json({ message: 'This list is private' });
    }
    const likedByMe = req.user ? list.likes.some(id => id.toString() === req.user._id.toString()) : false;
    res.json({ list: { ...list.toObject(), likeCount: list.likes.length, likedByMe, likes: undefined } });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

// ── Create list ───────────────────────────────────────────────────────────────
router.post('/', protect, async (req, res) => {
  try {
    const { name, description, isPublic } = req.body;
    if (!name?.trim()) return res.status(400).json({ message: 'List name is required' });
    const list = await ReadingList.create({
      user: req.user._id, name: name.trim(), description: description?.trim() || '',
      isPublic: isPublic !== false,
    });
    res.status(201).json({ list });
  } catch (err) { res.status(400).json({ message: err.message }); }
});

// ── Update list metadata ──────────────────────────────────────────────────────
router.patch('/:id', protect, async (req, res) => {
  try {
    const list = await ReadingList.findById(req.params.id);
    if (!list) return res.status(404).json({ message: 'List not found' });
    if (list.user.toString() !== req.user._id.toString()) return res.status(403).json({ message: 'Not your list' });

    const { name, description, isPublic, coverImage } = req.body;
    if (name !== undefined) list.name = name.trim();
    if (description !== undefined) list.description = description.trim();
    if (isPublic !== undefined) list.isPublic = !!isPublic;
    if (coverImage !== undefined) list.coverImage = coverImage;
    await list.save();
    res.json({ list });
  } catch (err) { res.status(400).json({ message: err.message }); }
});

// ── Add / remove manga from a list ───────────────────────────────────────────
router.post('/:id/manga/:mangaId', protect, async (req, res) => {
  try {
    const list = await ReadingList.findById(req.params.id);
    if (!list) return res.status(404).json({ message: 'List not found' });
    if (list.user.toString() !== req.user._id.toString()) return res.status(403).json({ message: 'Not your list' });

    const manga = await Manga.findById(req.params.mangaId).select('_id');
    if (!manga) return res.status(404).json({ message: 'Manga not found' });

    const idx = list.manga.findIndex(m => m.toString() === req.params.mangaId);
    if (idx === -1) list.manga.push(req.params.mangaId);
    else list.manga.splice(idx, 1);
    await list.save();
    res.json({ added: idx === -1, mangaCount: list.manga.length });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

// ── Like / unlike a public list ──────────────────────────────────────────────
router.post('/:id/like', protect, async (req, res) => {
  try {
    const list = await ReadingList.findById(req.params.id);
    if (!list) return res.status(404).json({ message: 'List not found' });
    const idx = list.likes.findIndex(id => id.toString() === req.user._id.toString());
    if (idx === -1) list.likes.push(req.user._id); else list.likes.splice(idx, 1);
    await list.save();
    res.json({ liked: idx === -1, likeCount: list.likes.length });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

// ── Delete list ───────────────────────────────────────────────────────────────
router.delete('/:id', protect, async (req, res) => {
  try {
    const list = await ReadingList.findById(req.params.id);
    if (!list) return res.status(404).json({ message: 'List not found' });
    if (list.user.toString() !== req.user._id.toString() && !['admin', 'owner'].includes(req.user.role)) {
      return res.status(403).json({ message: 'Not your list' });
    }
    await list.deleteOne();
    res.json({ message: 'Deleted' });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

module.exports = router;
