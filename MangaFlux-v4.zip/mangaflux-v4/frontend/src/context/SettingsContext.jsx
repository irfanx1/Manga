import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import api from '../utils/api';

const SettingsContext = createContext(null);

export function SettingsProvider({ children }) {
  const [settings, setSettings] = useState({ siteName: 'MangaFlux', logoUrl: '' });
  const [loading, setLoading]   = useState(true);

  const load = useCallback(async () => {
    try {
      const data = await api.get('/settings');
      setSettings(data.settings);
    } catch { /* fall back to defaults above */ }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  return (
    <SettingsContext.Provider value={{ settings, loading, reloadSettings: load }}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const ctx = useContext(SettingsContext);
  if (!ctx) throw new Error('useSettings must be used within SettingsProvider');
  return ctx;
}
