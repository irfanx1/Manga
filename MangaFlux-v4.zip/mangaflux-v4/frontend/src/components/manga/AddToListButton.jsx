import { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../../utils/api';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';

const ListIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M6 5h10M6 10h10M6 15h10M3 5h.01M3 10h.01M3 15h.01"/></svg>;
const CheckIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 10l4 4 8-8"/></svg>;
const PlusIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M10 4v12M4 10h12"/></svg>;

export default function AddToListButton({ mangaId }) {
  const { user } = useAuth();
  const showToast = useToast();
  const [open, setOpen] = useState(false);
  const [lists, setLists] = useState([]);
  const [loading, setLoading] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    if (!open) return;
    const handler = (e) => { if (!ref.current?.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  const openPicker = async () => {
    if (!user) { showToast('Sign in to add manga to a list.', 'info'); return; }
    setOpen(true);
    setLoading(true);
    try {
      const data = await api.get('/lists/mine');
      setLists(data.lists || []);
    } finally { setLoading(false); }
  };

  const toggle = async (listId) => {
    try {
      const res = await api.post(`/lists/${listId}/manga/${mangaId}`);
      setLists(ls => ls.map(l => l._id === listId
        ? { ...l, manga: res.added ? [...l.manga, { _id: mangaId }] : l.manga.filter(m => m._id !== mangaId) }
        : l));
      showToast(res.added ? 'Added to list' : 'Removed from list', 'success');
    } catch (err) { showToast(err.message || 'Failed to update list', 'error'); }
  };

  const inList = (list) => list.manga?.some(m => (m._id || m) === mangaId);

  return (
    <div className="add-to-list" ref={ref}>
      <button className="btn-icon" onClick={openPicker} aria-label="Add to list" data-tip="Add to list"><ListIcon /></button>
      {open && (
        <div className="add-to-list__panel scale-in">
          <div className="add-to-list__head">Add to list</div>
          {loading ? (
            <div className="add-to-list__loading"><span className="spinner" /></div>
          ) : lists.length === 0 ? (
            <div className="add-to-list__empty">
              <p>You don't have any lists yet.</p>
              <Link to="/lists" className="btn btn-secondary btn-sm" onClick={() => setOpen(false)}><PlusIcon /> Create one</Link>
            </div>
          ) : (
            <div className="add-to-list__items">
              {lists.map(l => (
                <button key={l._id} className="add-to-list__item" onClick={() => toggle(l._id)}>
                  <span>{l.name}</span>
                  {inList(l) && <CheckIcon />}
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
