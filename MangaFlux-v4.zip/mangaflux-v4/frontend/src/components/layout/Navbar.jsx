import { useState, useRef, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useNotifications } from '../../context/NotificationContext';
import { useSettings } from '../../context/SettingsContext';
import CommandPalette from '../CommandPalette';
import NotificationPanel from './NotificationPanel';
import './Navbar.css';

const SearchIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><circle cx="8.5" cy="8.5" r="5.5"/><path d="M13.5 13.5 18 18"/></svg>;
const BellIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M5 8a5 5 0 0110 0c0 2.5 1 4 1.5 5H3.5C4 12 5 10.5 5 8z"/><path d="M8 16a2 2 0 004 0"/></svg>;
const UserIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7"><circle cx="10" cy="7" r="3.5"/><path d="M3 18c0-4 3.1-6.5 7-6.5s7 2.5 7 6.5" strokeLinecap="round"/></svg>;
const LogoutIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7"><path d="M13 3h4v14h-4M8 14l4-4-4-4M12 10H3" strokeLinecap="round" strokeLinejoin="round"/></svg>;
const ShieldIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7"><path d="M10 2L4 5v5c0 4.4 2.6 7.6 6 8.9C14.4 17.6 17 14.4 17 10V5L10 2z" strokeLinecap="round" strokeLinejoin="round"/></svg>;
const LibraryIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7"><path d="M4 4h4v12H4zM8 6h4v10H8zM12 3h4v13h-4z" strokeLinecap="round" strokeLinejoin="round"/></svg>;
const TrophyIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M6 4h8v3a4 4 0 01-8 0V4z"/><path d="M6 5H4a1 1 0 00-1 1v1a3 3 0 003 3M14 5h2a1 1 0 011 1v1a3 3 0 01-3 3M8 14h4M10 11v3M7 17h6"/></svg>;
const StarIcon = () => <svg viewBox="0 0 20 20" fill="currentColor"><path d="M10 1l2.39 4.84 5.34.78-3.87 3.77.91 5.33L10 13.27l-4.77 2.45.91-5.33L2.27 6.62l5.34-.78L10 1z"/></svg>;
const FlameIcon = () => <svg viewBox="0 0 20 20" fill="currentColor"><path d="M10 1c1 3-3 4-3 7a3 3 0 006 0c1 1 2 2.5 2 4.5a5 5 0 11-10 0C5 8 8 6 10 1z"/></svg>;
const ListIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M6 5h10M6 10h10M6 15h10M3 5h.01M3 10h.01M3 15h.01"/></svg>;
const MedalIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><circle cx="10" cy="12.5" r="4.5"/><path d="M7.5 8.5L5 2h3l2 5 2-5h3l-2.5 6.5"/></svg>;
const CrownIcon = () => <svg viewBox="0 0 20 20" fill="currentColor"><path d="M2 7l3 3 5-5 5 5 3-3-1.5 9h-13L2 7z"/></svg>;

export default function Navbar() {
  const { user, logout } = useAuth();
  const { unreadCount }  = useNotifications();
  const { settings }     = useSettings();
  const location  = useLocation();
  const navigate  = useNavigate();
  const [dropOpen, setDropOpen]   = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [cmdkOpen, setCmdkOpen]   = useState(false);
  const dropRef  = useRef(null);
  const notifRef = useRef(null);

  const isReader = location.pathname.includes('/chapter/');

  useEffect(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') { e.preventDefault(); setCmdkOpen(o => !o); }
      if (e.key === 'Escape') setCmdkOpen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  useEffect(() => {
    if (!dropOpen && !notifOpen) return;
    const handler = (e) => {
      if (dropOpen && !dropRef.current?.contains(e.target)) setDropOpen(false);
      if (notifOpen && !notifRef.current?.contains(e.target)) setNotifOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [dropOpen, notifOpen]);

  useEffect(() => { setDropOpen(false); setNotifOpen(false); }, [location.pathname]);

  if (isReader) return null;

  const initials = user?.username?.[0]?.toUpperCase() || 'U';

  return (
    <>
      <nav className="nav">
        <div className="nav__inner">
          {/* Logo is intentionally a plain, non-interactive label — not a
              link. It should not navigate, highlight, or show any focus/hover
              state. Use the "Home" nav link below for actual navigation. */}
          <div className="nav__logo">
            {settings.logoUrl
              ? <img src={settings.logoUrl} alt={settings.siteName} className="nav__logo-img" />
              : <span className="nav__logo-mark" />
            }
            <span className="nav__logo-text">{settings.siteName}</span>
          </div>

          <ul className="nav__links">
            <li><Link to="/" className={`nav__link ${location.pathname === '/' ? 'active' : ''}`}>Home</Link></li>
            <li><Link to="/explore" className={`nav__link ${location.pathname.startsWith('/explore') ? 'active' : ''}`}>Browse</Link></li>
            <li><Link to="/rankings" className={`nav__link ${location.pathname.startsWith('/rankings') ? 'active' : ''}`}>Rankings</Link></li>
            <li><Link to="/lists" className={`nav__link ${location.pathname.startsWith('/lists') ? 'active' : ''}`}>Lists</Link></li>
            {user && <li><Link to="/library" className={`nav__link ${location.pathname === '/library' ? 'active' : ''}`}>Library</Link></li>}
          </ul>

          <div className="nav__actions">
            <button className="nav__search-trigger" onClick={() => setCmdkOpen(true)}>
              <SearchIcon />
              <span>Search</span>
              <kbd>⌘K</kbd>
            </button>
            <button className="btn-icon nav__search-icon-only" onClick={() => setCmdkOpen(true)} aria-label="Search"><SearchIcon /></button>

            {user && (
              <div className="nav__user" ref={notifRef}>
                <button className="btn-icon nav__bell" onClick={() => setNotifOpen(o => !o)} aria-label="Notifications">
                  <BellIcon />
                  {unreadCount > 0 && <span className="nav__bell-dot">{unreadCount > 9 ? '9+' : unreadCount}</span>}
                </button>
                {notifOpen && <NotificationPanel onClose={() => setNotifOpen(false)} />}
              </div>
            )}

            {user ? (
              <div className="nav__user" ref={dropRef}>
                <button className="nav__avatar" onClick={() => setDropOpen(o => !o)} aria-label="Account">
                  {user.avatar ? <img src={user.avatar} alt={user.username} /> : <span>{initials}</span>}
                  {user.role === 'owner' && <span className="nav__avatar-badge nav__avatar-badge--owner"><CrownIcon /></span>}
                  {user.role !== 'owner' && user.isPremium && <span className="nav__avatar-badge nav__avatar-badge--premium"><StarIcon /></span>}
                </button>
                {dropOpen && (
                  <div className="nav__drop" role="menu">
                    <div className="nav__drop-header">
                      <span className="nav__drop-name">{user.username}</span>
                      <span className="nav__drop-email">{user.email}</span>
                      <div className="nav__drop-meta">
                        <RoleTag role={user.role} />
                        {user.isPremium && user.role === 'user' && <span className="badge badge-gold">Premium</span>}
                        {user.streak?.current > 0 && <span className="nav__drop-streak"><FlameIcon /> {user.streak.current}</span>}
                      </div>
                    </div>
                    <div className="nav__drop-divider" />
                    <Link to="/profile" className="nav__drop-item" role="menuitem"><UserIcon /> Profile</Link>
                    <Link to="/library" className="nav__drop-item" role="menuitem"><LibraryIcon /> Library</Link>
                    <Link to="/lists" className="nav__drop-item" role="menuitem"><ListIcon /> My Lists</Link>
                    <Link to="/achievements" className="nav__drop-item" role="menuitem"><MedalIcon /> Achievements</Link>
                    <Link to="/rankings" className="nav__drop-item" role="menuitem"><TrophyIcon /> Rankings</Link>
                    {(user.role === 'admin' || user.role === 'owner') && (
                      <Link to="/admin" className="nav__drop-item" role="menuitem"><ShieldIcon /> Admin Panel</Link>
                    )}
                    <div className="nav__drop-divider" />
                    <button className="nav__drop-item nav__drop-item--danger" onClick={logout} role="menuitem"><LogoutIcon /> Sign out</button>
                  </div>
                )}
              </div>
            ) : (
              <div className="nav__auth">
                <Link to="/login" className="btn btn-ghost btn-sm">Sign in</Link>
                <Link to="/register" className="btn btn-primary btn-sm">Get started</Link>
              </div>
            )}
          </div>
        </div>
      </nav>

      {cmdkOpen && <CommandPalette onClose={() => setCmdkOpen(false)} />}
    </>
  );
}

// Small inline badge that fits properly next to text — fixes the previous
// oversized crown emoji that didn't line up with the "Owner"/"Admin"/"Member"
// label. Icon is sized via CSS to match the text's line-height exactly.
function RoleTag({ role }) {
  const config = {
    owner: { label: 'Owner',  Icon: CrownIcon,  className: 'role-tag--owner' },
    admin: { label: 'Admin',  Icon: ShieldIcon, className: 'role-tag--admin' },
    user:  { label: 'Member', Icon: StarIcon,   className: 'role-tag--member' },
  };
  const { label, Icon, className } = config[role] || config.user;
  return (
    <span className={`role-tag ${className}`}>
      <Icon /> {label}
    </span>
  );
}
