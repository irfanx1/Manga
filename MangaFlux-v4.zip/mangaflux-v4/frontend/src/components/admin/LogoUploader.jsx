import { useRef, useState } from 'react';
import api from '../../utils/api';
import { useSettings } from '../../context/SettingsContext';
import { useToast } from '../../context/ToastContext';

const UploadIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M10 13V3M6 7l4-4 4 4M4 14v2a1 1 0 001 1h10a1 1 0 001-1v-2"/></svg>;
const TrashIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M4 6h12M8 6V4h4v2M6 6l1 10h6l1-10"/></svg>;

const MAX_FILE_BYTES = 1.5 * 1024 * 1024;

export default function LogoUploader() {
  const { settings, reloadSettings } = useSettings();
  const showToast = useToast();
  const [preview, setPreview] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [siteName, setSiteName] = useState(settings.siteName || 'MangaFlux');
  const [savingName, setSavingName] = useState(false);
  const fileRef = useRef(null);

  const handleFile = (file) => {
    if (!file) return;
    if (!file.type.startsWith('image/')) { showToast('Please choose an image file.', 'error'); return; }
    if (file.size > MAX_FILE_BYTES) { showToast('Image is too large — please use one under 1.5MB.', 'error'); return; }

    const reader = new FileReader();
    reader.onload = () => setPreview(reader.result);
    reader.readAsDataURL(file);
  };

  const upload = async () => {
    if (!preview) return;
    setUploading(true);
    try {
      await api.post('/settings/logo', { dataUrl: preview });
      await reloadSettings();
      setPreview(null);
      showToast('Logo updated', 'success');
    } catch (err) { showToast(err.message || 'Failed to upload logo', 'error'); }
    finally { setUploading(false); }
  };

  const removeLogo = async () => {
    try {
      await api.delete('/settings/logo');
      await reloadSettings();
      showToast('Logo removed — using default', 'success');
    } catch (err) { showToast(err.message || 'Failed to remove logo', 'error'); }
  };

  const saveSiteName = async () => {
    if (!siteName.trim()) return;
    setSavingName(true);
    try {
      await api.patch('/settings', { siteName: siteName.trim() });
      await reloadSettings();
      showToast('Site name updated', 'success');
    } catch (err) { showToast(err.message || 'Failed to update', 'error'); }
    finally { setSavingName(false); }
  };

  return (
    <div className="logo-uploader">
      <div className="logo-uploader__section">
        <span className="theme-draft__label">Site name</span>
        <div className="logo-uploader__name-row">
          <input className="input" value={siteName} onChange={e => setSiteName(e.target.value)} maxLength={40} />
          <button className="btn btn-secondary btn-sm" onClick={saveSiteName} disabled={savingName || siteName === settings.siteName}>
            {savingName ? <span className="spinner" /> : 'Save'}
          </button>
        </div>
      </div>

      <div className="logo-uploader__section">
        <span className="theme-draft__label">Logo</span>
        <div className="logo-uploader__current">
          <div className="logo-uploader__preview">
            {preview || settings.logoUrl
              ? <img src={preview || settings.logoUrl} alt="Logo" />
              : <div className="logo-uploader__placeholder" />}
          </div>
          <div className="logo-uploader__actions">
            <input ref={fileRef} type="file" accept="image/*" hidden onChange={e => handleFile(e.target.files?.[0])} />
            <button className="btn btn-secondary btn-sm" onClick={() => fileRef.current?.click()}><UploadIcon /> Choose image</button>
            {settings.logoUrl && !preview && (
              <button className="btn btn-ghost btn-sm" onClick={removeLogo} style={{ color: '#f87171' }}><TrashIcon /> Remove</button>
            )}
          </div>
        </div>

        {preview && (
          <div className="logo-uploader__confirm">
            <button className="btn btn-primary btn-sm" onClick={upload} disabled={uploading}>{uploading ? <span className="spinner" /> : 'Save logo'}</button>
            <button className="btn btn-ghost btn-sm" onClick={() => setPreview(null)}>Cancel</button>
          </div>
        )}

        <p className="logo-uploader__hint">Square images work best (e.g. 256×256px). Max 1.5MB. PNG with transparency recommended.</p>
      </div>
    </div>
  );
}
