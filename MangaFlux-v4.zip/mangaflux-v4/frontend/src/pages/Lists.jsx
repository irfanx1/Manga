import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import './Lists.css';

const ListIcon = () => <svg width="36" height="36" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M6 5h10M6 10h10M6 15h10M3 5h.01M3 10h.01M3 15h.01"/></svg>;
const PlusIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M10 4v12M4 10h12"/></svg>;
const HeartIcon = ({ filled }) => <svg viewBox="0 0 20 20" fill={filled ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="1.7"><path d="M10 17.3S3 13 3 7.8C3 5.2 5 3.3 7.4 3.3c1.4 0 2.6.7 3.4 1.8.8-1.1 2-1.8 3.4-1.8 2.4 0 4.4 1.9 4.4 4.5 0 5.2-7 9.5-7 9.5z"/></svg>;
const LockIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="9" width="12" height="8" rx="1.5"/><path d="M6 9V6a4 4 0 018 0v3"/></svg>;
const TrashIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M4 6h12M8 6V4h4v2M6 6l1 10h6l1-10"/></svg>;
const XIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M5 5l10 10M15 5 5 15"/></svg>;

function ListCard({ list, onDelete, mine }) {
  const covers = (list.manga || []).slice(0, 4);
  return (
    <div className="list-card">
      <Link to={`/lists/${list.slug}`} className="list-card__covers">
        {covers.length > 0 ? covers.map((m, i) => (
          <div key={m._id || i} className="list-card__cover">
            {m.coverImage ? <img src={m.coverImage} alt="" /> : <div className="list-card__cover-blank" />}
          </div>
        )) : <div className="list-card__empty-covers"><ListIcon /></div>}
      </Link>
      <Link to={`/lists/${list.slug}`} className="list-card__info">
        <div className="list-card__title-row">
          <h3 className="list-card__title clamp-1">{list.name}</h3>
          {!list.isPublic && <LockIcon />}
        </div>
        <p className="list-card__meta">{list.manga?.length || 0} titles {list.user && `· by ${list.user.username}`}</p>
      </Link>
      {mine && (
        <button className="list-card__delete" onClick={() => onDelete(list._id)}><TrashIcon /></button>
      )}
    </div>
  );
}

export default function Lists() {
  const { user } = useAuth();
  const showToast = useToast();
  const [tab, setTab] = useState('discover');
  const [discoverLists, setDiscoverLists] = useState([]);
  const [myLists, setMyLists] = useState([]);
  const [loading, setLoading] = useState(true);
  const [createOpen, setCreateOpen] = useState(false);
  const [form, setForm] = useState({ name: '', description: '', isPublic: true });
  const [creating, setCreating] = useState(false);

  const loadDiscover = () => api.get('/lists/discover').then(d => setDiscoverLists(d.lists || []));
  const loadMine = () => user ? api.get('/lists/mine').then(d => setMyLists(d.lists || [])) : Promise.resolve();

  useEffect(() => {
    setLoading(true);
    Promise.all([loadDiscover(), loadMine()]).finally(() => setLoading(false));
  }, [user]);

  const createList = async (e) => {
    e.preventDefault();
    if (!form.name.trim()) return;
    setCreating(true);
    try {
      const res = await api.post('/lists', form);
      setMyLists(l => [{ ...res.list, manga: [] }, ...l]);
      setForm({ name: '', description: '', isPublic: true });
      setCreateOpen(false);
      setTab('mine');
      showToast('List created', 'success');
    } catch (err) { showToast(err.message || 'Failed to create list', 'error'); }
    finally { setCreating(false); }
  };

  const deleteList = async (id) => {
    try {
      await api.delete(`/lists/${id}`);
      setMyLists(l => l.filter(x => x._id !== id));
      showToast('List deleted', 'success');
    } catch (err) { showToast(err.message || 'Failed to delete', 'error'); }
  };

  return (
    <div className="page container lists-page">
      <div className="lists-head">
        <span className="lists-head__icon"><ListIcon /></span>
        <div>
          <p className="section-label">Collections</p>
          <h1 className="section-title">Reading Lists</h1>
        </div>
        {user && <button className="btn btn-primary lists-head__create" onClick={() => setCreateOpen(true)}><PlusIcon /> New list</button>}
      </div>

      <div className="lists-tabs">
        <button className={`lists-tab ${tab === 'discover' ? 'active' : ''}`} onClick={() => setTab('discover')}>Discover</button>
        {user && <button className={`lists-tab ${tab === 'mine' ? 'active' : ''}`} onClick={() => setTab('mine')}>My Lists ({myLists.length})</button>}
      </div>

      {loading ? (
        <div className="spinner-page"><div className="spinner spinner-lg" /></div>
      ) : tab === 'discover' ? (
        discoverLists.length === 0 ? (
          <div className="empty"><ListIcon /><h3>No public lists yet</h3><p>Be the first to create and share a reading list.</p></div>
        ) : (
          <div className="lists-grid">{discoverLists.map(l => <ListCard key={l._id} list={l} />)}</div>
        )
      ) : (
        myLists.length === 0 ? (
          <div className="empty"><ListIcon /><h3>You haven't made any lists</h3><p>Group your favorite manga into shareable collections.</p><button className="btn btn-primary" onClick={() => setCreateOpen(true)}>Create your first list</button></div>
        ) : (
          <div className="lists-grid">{myLists.map(l => <ListCard key={l._id} list={l} mine onDelete={deleteList} />)}</div>
        )
      )}

      {createOpen && (
        <div className="list-modal-overlay" onClick={e => { if (e.target === e.currentTarget) setCreateOpen(false); }}>
          <div className="list-modal scale-in">
            <div className="list-modal__head">
              <span>Create a new list</span>
              <button className="btn-icon" onClick={() => setCreateOpen(false)}><XIcon /></button>
            </div>
            <form onSubmit={createList} className="list-modal__form">
              <div className="admin-field">
                <label>List name</label>
                <input className="input" placeholder="e.g. Best Isekai of 2026" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} maxLength={60} required autoFocus />
              </div>
              <div className="admin-field">
                <label>Description (optional)</label>
                <textarea className="input" rows={3} placeholder="What's this list about?" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} maxLength={300} />
              </div>
              <label className="list-modal__public">
                <input type="checkbox" checked={form.isPublic} onChange={e => setForm({ ...form, isPublic: e.target.checked })} />
                <span>Make this list public — others can discover and view it</span>
              </label>
              <button type="submit" className="btn btn-primary" disabled={creating || !form.name.trim()}>{creating ? <span className="spinner" /> : 'Create list'}</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
