import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from '../utils/api';
import './UserPages.css';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import MangaCard from '../components/manga/MangaCard';

const HeartIcon = () => <svg width="36" height="36" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M10 17.3S3 13 3 7.8C3 5.2 5 3.3 7.4 3.3c1.4 0 2.6.7 3.4 1.8.8-1.1 2-1.8 3.4-1.8 2.4 0 4.4 1.9 4.4 4.5 0 5.2-7 9.5-7 9.5z"/></svg>;
const ClockIcon = () => <svg width="36" height="36" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.5"><circle cx="10" cy="10" r="8"/><path d="M10 6v4l3 2" strokeLinecap="round"/></svg>;
const BookIcon = ({ size = 18 }) => <svg width={size} height={size} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M4 3h9a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z"/><path d="M7 7h4M7 10h4"/></svg>;
const StarIcon = ({ size = 18 }) => <svg width={size} height={size} viewBox="0 0 20 20" fill="currentColor"><path d="M10 1l2.39 4.84 5.34.78-3.87 3.77.91 5.33L10 13.27l-4.77 2.45.91-5.33L2.27 6.62l5.34-.78L10 1z"/></svg>;
const FlameIcon = ({ size = 18 }) => <svg width={size} height={size} viewBox="0 0 20 20" fill="currentColor"><path d="M10 1c1 3-3 4-3 7a3 3 0 006 0c1 1 2 2.5 2 4.5a5 5 0 11-10 0C5 8 8 6 10 1z"/></svg>;
const ShieldIcon = ({ size = 18 }) => <svg width={size} height={size} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M10 2L4 5v5c0 4.4 2.6 7.6 6 8.9C14.4 17.6 17 14.4 17 10V5L10 2z"/></svg>;
const TrophyIcon = ({ size = 18 }) => <svg width={size} height={size} viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M6 4h8v3a4 4 0 01-8 0V4z"/><path d="M6 5H4a1 1 0 00-1 1v1a3 3 0 003 3M14 5h2a1 1 0 011 1v1a3 3 0 01-3 3M8 14h4M10 11v3M7 17h6"/></svg>;
const ChevronIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M7.5 5l5 5-5 5"/></svg>;
const CrownIcon = ({ size = 18 }) => <svg width={size} height={size} viewBox="0 0 20 20" fill="currentColor"><path d="M2 7l3 3 5-5 5 5 3-3-1.5 9h-13L2 7z"/></svg>;
const BellIcon = () => <svg width="18" height="18" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M5 8a5 5 0 0110 0c0 2.5 1 4 1.5 5H3.5C4 12 5 10.5 5 8z"/><path d="M8 16a2 2 0 004 0"/></svg>;

function PageShell({ title, Icon, sub, children }) {
  return (
    <div className="page container user-page">
      <div className="user-page__head">
        <span className="user-page__icon"><Icon /></span>
        <div><h1 className="user-page__title">{title}</h1>{sub && <p className="user-page__sub">{sub}</p>}</div>
      </div>
      {children}
    </div>
  );
}

/* ── LIBRARY ── */
export function Library() {
  const { user } = useAuth();
  const [manga, setManga] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    if (!user.bookmarks?.length) { setLoading(false); return; }
    api.get('/manga?limit=100').then(data => {
      const ids = new Set(user.bookmarks.map(String));
      setManga((data.manga || []).filter(m => ids.has(String(m._id))));
    }).finally(() => setLoading(false));
  }, [user]);

  return (
    <PageShell title="My Library" Icon={HeartIcon} sub={`${manga.length} saved titles`}>
      {loading ? <div className="spinner-page"><div className="spinner spinner-lg" /></div>
      : manga.length === 0 ? (
        <div className="empty"><HeartIcon /><h3>Nothing saved yet</h3><p>Bookmark manga from any page to build your library.</p><Link to="/explore" className="btn btn-primary">Discover manga</Link></div>
      ) : (
        <div className="user-grid">{manga.map(m => <MangaCard key={m._id} manga={m} />)}</div>
      )}
    </PageShell>
  );
}

/* ── HISTORY ── */
export function History() {
  const { user } = useAuth();
  if (!user) return null;
  const history = [...(user.readHistory || [])].reverse();

  return (
    <PageShell title="Reading History" Icon={ClockIcon} sub={`${history.length} entries`}>
      {history.length === 0 ? (
        <div className="empty"><BookIcon size={36} /><h3>No history yet</h3><p>Start reading to track your progress.</p><Link to="/" className="btn btn-primary">Browse manga</Link></div>
      ) : (
        <div className="history-list">
          {history.map((h, i) => (
            <div key={i} className="history-item">
              <span className="history-item__icon"><BookIcon size={16} /></span>
              <div className="history-item__info">
                <div className="history-item__ch">Chapter {h.chapter?.number ?? '?'}</div>
                <div className="history-item__date">{new Date(h.readAt).toLocaleString()}</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </PageShell>
  );
}

/* ── PROFILE ── */
export function Profile() {
  const { user, logout, isAdmin, refreshUser } = useAuth();
  const showToast = useToast();
  const navigate = useNavigate();
  const [savingPrefs, setSavingPrefs] = useState(false);
  if (!user) return null;

  const daysJoined = Math.max(0, Math.floor((Date.now() - new Date(user.createdAt)) / 86400000));
  const roleConfig = {
    owner: { color: 'var(--warning)', label: 'Owner', Icon: CrownIcon },
    admin: { color: 'var(--accent-hi)', label: 'Admin', Icon: ShieldIcon },
    user:  { color: 'var(--success)', label: 'Member', Icon: StarIcon },
  };
  const role = roleConfig[user.role] || roleConfig.user;

  const menuItems = [
    { Icon: HeartIcon,  label: 'My Library',      sub: 'Saved manga & bookmarks',     to: '/library' },
    { Icon: ClockIcon,  label: 'Reading History', sub: 'Continue where you left off', to: '/history' },
    { Icon: TrophyIcon, label: 'Rankings',         sub: 'See the top read titles',     to: '/rankings' },
    { Icon: FlameIcon,  label: 'Premium',          sub: 'Upgrade for ad-free reading', to: '/premium' },
    isAdmin && { Icon: ShieldIcon, label: 'Admin Panel', sub: 'Manage content & users', to: '/admin' },
  ].filter(Boolean);

  const toggleNotify = async () => {
    setSavingPrefs(true);
    try {
      await api.patch('/auth/me', { preferences: { ...user.preferences, notifyNewChapters: !user.preferences?.notifyNewChapters } });
      await refreshUser();
      showToast('Preference updated', 'success');
    } catch (err) { showToast(err.message || 'Failed to update', 'error'); }
    finally { setSavingPrefs(false); }
  };

  return (
    <div className="page container user-page">
      <div className="profile-header">
        <div className="profile-avatar">{user.avatar ? <img src={user.avatar} alt={user.username} /> : <span>{user.username[0].toUpperCase()}</span>}</div>
        <div className="profile-info">
          <h1 className="profile-name">{user.username}</h1>
          <p className="profile-email">{user.email}</p>
          <span className="profile-role" style={{ color: role.color, background: 'var(--surface-2)', borderColor: 'var(--border-2)' }}>
            <role.Icon size={12} /> {role.label}
          </span>
        </div>
      </div>

      {user.streak?.current > 0 && (
        <div className="streak-banner">
          <span className="streak-banner__icon"><FlameIcon size={22} /></span>
          <div className="streak-banner__text">
            <strong>{user.streak.current}-day reading streak</strong>
            <span>Longest streak: {user.streak.longest} days · {user.stats?.xp || 0} XP earned</span>
          </div>
        </div>
      )}

      <div className="profile-stats">
        {[
          { val: user.bookmarks?.length || 0, label: 'Bookmarks', Icon: HeartIcon },
          { val: user.stats?.chaptersRead || user.readHistory?.length || 0, label: 'Chapters read', Icon: BookIcon },
          { val: daysJoined, label: 'Days active', Icon: ClockIcon },
        ].map(s => (
          <div key={s.label} className="profile-stat">
            <span className="profile-stat__icon"><s.Icon size={18} /></span>
            <span className="profile-stat__val">{s.val.toLocaleString()}</span>
            <span className="profile-stat__label">{s.label}</span>
          </div>
        ))}
      </div>

      <div className="profile-pref-row">
        <span className="profile-pref-row__icon"><BellIcon /></span>
        <div className="profile-pref-row__text">
          <strong>New chapter notifications</strong>
          <span>Get notified when manga you've bookmarked updates</span>
        </div>
        <button className={`toggle ${user.preferences?.notifyNewChapters ? 'on' : ''}`} onClick={toggleNotify} disabled={savingPrefs} aria-label="Toggle notifications" />
      </div>

      <div className="profile-menu">
        {menuItems.map(item => (
          <Link key={item.to} to={item.to} className="profile-menu-item">
            <span className="profile-menu-item__icon"><item.Icon /></span>
            <div className="profile-menu-item__text"><span className="profile-menu-item__label">{item.label}</span><span className="profile-menu-item__sub">{item.sub}</span></div>
            <span className="profile-menu-item__arrow"><ChevronIcon /></span>
          </Link>
        ))}
        <button className="profile-signout" onClick={() => { logout(); navigate('/'); }}>Sign out</button>
      </div>
    </div>
  );
}
