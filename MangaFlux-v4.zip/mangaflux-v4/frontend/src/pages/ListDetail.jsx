import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import MangaCard from '../components/manga/MangaCard';
import './Lists.css';

const HeartIcon = ({ filled }) => <svg viewBox="0 0 20 20" fill={filled ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="1.7"><path d="M10 17.3S3 13 3 7.8C3 5.2 5 3.3 7.4 3.3c1.4 0 2.6.7 3.4 1.8.8-1.1 2-1.8 3.4-1.8 2.4 0 4.4 1.9 4.4 4.5 0 5.2-7 9.5-7 9.5z"/></svg>;
const LockIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="9" width="12" height="8" rx="1.5"/><path d="M6 9V6a4 4 0 018 0v3"/></svg>;
const ListIcon = () => <svg width="36" height="36" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M6 5h10M6 10h10M6 15h10M3 5h.01M3 10h.01M3 15h.01"/></svg>;

export default function ListDetail() {
  const { slug } = useParams();
  const { user } = useAuth();
  const showToast = useToast();
  const [list, setList] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    api.get(`/lists/${slug}`).then(d => setList(d.list)).catch(() => setList(null)).finally(() => setLoading(false));
  }, [slug]);

  const toggleLike = async () => {
    if (!user) { showToast('Sign in to like lists.', 'info'); return; }
    try {
      const res = await api.post(`/lists/${list._id}/like`);
      setList(l => ({ ...l, likedByMe: res.liked, likeCount: res.likeCount }));
    } catch (err) { showToast(err.message, 'error'); }
  };

  if (loading) return <div className="spinner-page"><div className="spinner spinner-lg" /></div>;
  if (!list) return (
    <div className="page" style={{ paddingTop: 120, textAlign: 'center' }}>
      <p style={{ color: 'var(--text-muted)' }}>This list doesn't exist or is private.</p>
    </div>
  );

  return (
    <div className="page container lists-page">
      <div className="list-detail-head">
        <span className="lists-head__icon"><ListIcon /></span>
        <div className="list-detail-head__text">
          <div className="list-detail-head__title-row">
            <h1 className="section-title">{list.name}</h1>
            {!list.isPublic && <LockIcon />}
          </div>
          {list.description && <p className="list-detail-head__desc">{list.description}</p>}
          <p className="list-detail-head__by">
            {list.user && <>by <strong>{list.user.username}</strong> · </>}{list.manga?.length || 0} titles
          </p>
        </div>
        <button className={`btn btn-secondary list-detail-head__like ${list.likedByMe ? 'active' : ''}`} onClick={toggleLike}>
          <HeartIcon filled={list.likedByMe} /> {list.likeCount || 0}
        </button>
      </div>

      {list.manga?.length === 0 ? (
        <div className="empty"><ListIcon /><h3>This list is empty</h3><p>No manga have been added yet.</p></div>
      ) : (
        <div className="user-grid">{(list.manga || []).map(m => <MangaCard key={m._id} manga={m} />)}</div>
      )}
    </div>
  );
}
