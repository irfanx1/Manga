import { useEffect, useState } from 'react';
import api from '../utils/api';
import { useToast } from '../context/ToastContext';
import './Achievements.css';

const MedalIcon = () => <svg width="40" height="40" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"><circle cx="10" cy="12.5" r="4.5"/><path d="M7.5 8.5L5 2h3l2 5 2-5h3l-2.5 6.5"/></svg>;
const LockIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="9" width="12" height="8" rx="1.5"/><path d="M6 9V6a4 4 0 018 0v3"/></svg>;

const TIER_COLORS = {
  bronze:   { fg: '#cd7f32', bg: 'rgba(205,127,50,0.12)', border: 'rgba(205,127,50,0.3)' },
  silver:   { fg: '#c0c0c8', bg: 'rgba(192,192,200,0.12)', border: 'rgba(192,192,200,0.3)' },
  gold:     { fg: 'var(--warning)', bg: 'var(--warning-lo)', border: 'color-mix(in srgb, var(--warning) 30%, transparent)' },
  platinum: { fg: 'var(--accent-hi)', bg: 'var(--accent-lo)', border: 'var(--accent-border)' },
};

export default function Achievements() {
  const showToast = useToast();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/achievements').then(d => {
      setData(d);
      d.newlyUnlocked?.forEach(a => showToast(`Achievement unlocked: ${a.label}`, 'success', 5000));
    }).finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="spinner-page"><div className="spinner spinner-lg" /></div>;
  if (!data) return null;

  return (
    <div className="page container achievements-page">
      <div className="achievements-head">
        <span className="achievements-head__icon"><MedalIcon /></span>
        <div>
          <p className="section-label">Progress</p>
          <h1 className="section-title">Achievements</h1>
          <p className="achievements-head__count">{data.unlockedCount} / {data.totalCount} unlocked</p>
        </div>
      </div>

      <div className="achievements-progress">
        <div className="achievements-progress__bar"><div style={{ width: `${(data.unlockedCount / data.totalCount) * 100}%` }} /></div>
      </div>

      <div className="achievements-grid">
        {data.achievements.map(a => {
          const colors = TIER_COLORS[a.tier];
          return (
            <div key={a.id} className={`achievement-card ${a.unlocked ? 'unlocked' : 'locked'}`}>
              <span className="achievement-card__icon" style={a.unlocked ? { background: colors.bg, borderColor: colors.border, color: colors.fg } : {}}>
                {a.unlocked ? <MedalIcon /> : <LockIcon />}
              </span>
              <div className="achievement-card__text">
                <div className="achievement-card__top">
                  <span className="achievement-card__label">{a.label}</span>
                  <span className="achievement-card__tier" style={a.unlocked ? { color: colors.fg } : {}}>{a.tier}</span>
                </div>
                <p className="achievement-card__desc">{a.description}</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
