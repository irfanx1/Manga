import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import api from '../utils/api';
import MangaCard, { MangaCardSkeleton } from '../components/manga/MangaCard';
import './Explore.css';

const GENRES   = ['Action','Adventure','Comedy','Drama','Fantasy','Horror','Mystery','Romance','Sci-Fi','Slice of Life','Sports','Supernatural','Thriller','Isekai','Psychological','Shounen','Seinen'];
const TYPES    = ['manga','manhwa','manhua','webtoon'];
const STATUSES = ['ongoing','completed','hiatus'];
const SORTS = [
  { value: '-lastUpdated', label: 'Latest' },
  { value: '-views',       label: 'Popular' },
  { value: '-rating',      label: 'Top rated' },
  { value: 'title',        label: 'A–Z' },
];
const CURRENT_YEAR = new Date().getFullYear();

const FilterIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M3 5h14M6 10h8M8.5 15h3"/></svg>;
const XIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M5 5l10 10M15 5 5 15"/></svg>;
const SearchOffIcon = () => <svg width="42" height="42" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><circle cx="10" cy="10" r="6"/><path d="M14.5 14.5L20 20" strokeLinecap="round"/></svg>;
const ChevronDownIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 7.5l5 5 5-5"/></svg>;

const DEFAULT_FILTERS = {
  genres: [], type: '', status: '', sort: '-views',
  yearFrom: '', yearTo: '', minChapters: '', maxChapters: '',
};

export default function Explore() {
  const [params] = useSearchParams();
  const [manga, setManga]   = useState([]);
  const [total, setTotal]   = useState(0);
  const [page, setPage]     = useState(1);
  const [loading, setLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(true);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [filters, setFilters] = useState({
    ...DEFAULT_FILTERS,
    genres: params.get('genre') ? [params.get('genre')] : [],
    type: params.get('type') || '',
    sort: params.get('sort') || '-views',
  });

  const fetchManga = async (p = 1, reset = false) => {
    setLoading(true);
    try {
      const q = new URLSearchParams({
        page: p, limit: 18,
        ...(filters.genres.length ? { genres: filters.genres.join(',') } : {}),
        ...Object.fromEntries(Object.entries(filters).filter(([k, v]) => k !== 'genres' && v)),
      });
      const data = await api.get(`/manga?${q}`);
      setManga(prev => reset ? (data.manga || []) : [...prev, ...(data.manga || [])]);
      setTotal(data.total || 0);
      setPage(p);
    } finally { setLoading(false); }
  };

  useEffect(() => { fetchManga(1, true); }, [filters]);

  const setFilter = (key, val) => setFilters(f => ({ ...f, [key]: f[key] === val ? '' : val }));
  const toggleGenre = (g) => setFilters(f => ({
    ...f, genres: f.genres.includes(g) ? f.genres.filter(x => x !== g) : [...f.genres, g],
  }));
  const clearAll = () => setFilters(DEFAULT_FILTERS);

  const activeCount = filters.genres.length + [filters.type, filters.status, filters.yearFrom, filters.yearTo, filters.minChapters, filters.maxChapters].filter(Boolean).length;

  return (
    <div className="page container explore-page">
      <div className="explore-head">
        <div>
          <p className="section-label">Discover</p>
          <h1 className="section-title">Browse</h1>
          <p className="explore-count">{total.toLocaleString()} titles</p>
        </div>
        <button className="btn btn-secondary" onClick={() => setShowFilters(s => !s)}>
          <FilterIcon /> Filters {activeCount > 0 && <span className="filter-count">{activeCount}</span>}
        </button>
      </div>

      {showFilters && (
        <div className="explore-filters">
          {activeCount > 0 && <button className="btn btn-ghost btn-sm clear-btn" onClick={clearAll}><XIcon /> Clear all</button>}

          <FilterGroup label="Sort by" options={SORTS} value={filters.sort} onChange={v => setFilters(f => ({ ...f, sort: v }))} />
          <FilterGroup label="Type" options={TYPES.map(t => ({ value: t, label: t }))} value={filters.type} onChange={v => setFilter('type', v)} />
          <FilterGroup label="Status" options={STATUSES.map(s => ({ value: s, label: s }))} value={filters.status} onChange={v => setFilter('status', v)} />

          <div className="filter-group">
            <div className="filter-group__label">Genres {filters.genres.length > 0 && `(${filters.genres.length} selected)`}</div>
            <div className="filter-chips">
              {GENRES.map(g => (
                <button key={g} className={`filter-chip ${filters.genres.includes(g) ? 'active' : ''}`} onClick={() => toggleGenre(g)}>{g}</button>
              ))}
            </div>
          </div>

          <button className="explore-advanced-toggle" onClick={() => setShowAdvanced(s => !s)}>
            <span>Advanced filters</span>
            <span className={`explore-advanced-toggle__chevron ${showAdvanced ? 'open' : ''}`}><ChevronDownIcon /></span>
          </button>

          {showAdvanced && (
            <div className="explore-advanced">
              <div className="explore-range-group">
                <label>Release year</label>
                <div className="explore-range-inputs">
                  <input type="number" className="input" placeholder="From" min={1950} max={CURRENT_YEAR} value={filters.yearFrom} onChange={e => setFilters(f => ({ ...f, yearFrom: e.target.value }))} />
                  <span>–</span>
                  <input type="number" className="input" placeholder="To" min={1950} max={CURRENT_YEAR} value={filters.yearTo} onChange={e => setFilters(f => ({ ...f, yearTo: e.target.value }))} />
                </div>
              </div>
              <div className="explore-range-group">
                <label>Chapter count</label>
                <div className="explore-range-inputs">
                  <input type="number" className="input" placeholder="Min" min={0} value={filters.minChapters} onChange={e => setFilters(f => ({ ...f, minChapters: e.target.value }))} />
                  <span>–</span>
                  <input type="number" className="input" placeholder="Max" min={0} value={filters.maxChapters} onChange={e => setFilters(f => ({ ...f, maxChapters: e.target.value }))} />
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      <div className="explore-grid">
        {loading && manga.length === 0
          ? Array(12).fill(0).map((_, i) => <MangaCardSkeleton key={i} />)
          : manga.map(m => <MangaCard key={m._id} manga={m} />)
        }
      </div>

      {!loading && manga.length === 0 && (
        <div className="empty">
          <SearchOffIcon />
          <h3>No manga found</h3>
          <p>Try adjusting your filters to see more results.</p>
          <button className="btn btn-secondary btn-sm" onClick={clearAll}>Clear filters</button>
        </div>
      )}

      {manga.length < total && manga.length > 0 && (
        <div className="explore-load-more">
          <button className="btn btn-secondary btn-lg" style={{ width: '100%' }} onClick={() => fetchManga(page + 1)} disabled={loading}>
            {loading ? <span className="spinner" /> : `Load more (${manga.length}/${total})`}
          </button>
        </div>
      )}
    </div>
  );
}

function FilterGroup({ label, options, value, onChange }) {
  return (
    <div className="filter-group">
      <div className="filter-group__label">{label}</div>
      <div className="filter-chips">
        {options.map(o => (
          <button key={o.value} className={`filter-chip ${value === o.value ? 'active' : ''}`} onClick={() => onChange(o.value)}>{o.label}</button>
        ))}
      </div>
    </div>
  );
}
