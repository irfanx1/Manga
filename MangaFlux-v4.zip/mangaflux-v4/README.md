# MangaFlux v4 — Polish Pass + Feature Expansion

A ground-up visual and functional overhaul, now in its 4th iteration. This
pass fixes specific UI/UX rough edges that were called out directly, fixes a
mobile scrolling bug, and adds a real feature set: custom branding, an
achievement system, reading lists, and advanced search.

## What's new in v4

### Fixed: mobile scrolling — buttons unreachable below long forms (e.g. Admin → Add Manga, on phone screens)
Root cause: `html`/`body`/`#root` had no explicit `height`/`overflow-y` rules.
On most desktop browsers this silently works anyway, but several mobile
WebViews (notably Android WebView, which is what Termux-adjacent browsers
use) clip content at the viewport boundary instead of growing the scrollable
area once content — or the on-screen keyboard — pushes layout taller than
the visible viewport. This affected every long form and several modals
(Create List, Add Manga), not just the one you spotted.

Fixed by giving `html`/`body`/`#root` explicit height + `overflow-y: auto`
rules, and adding `overflow-y: auto` to the two modal overlays (Command
Palette, Create List) that center their content and could otherwise clip a
submit button below the fold on a short viewport.

### Fixed: navbar logo
- Replaced the gradient placeholder with **real custom logo upload** — Admin → Branding tab. Upload any image, it's converted to a data URL and stored server-side (no extra file-hosting setup needed), with a 1.5MB size cap
- Site name is also editable from the same tab
- The logo + site name in the navbar are now a plain, **non-interactive label** — no click handler, no hover highlight, no focus ring, and clicking it does nothing and goes nowhere. Use the "Home" nav link for actual navigation, exactly as requested

### Fixed: oversized crown icon next to "Owner"/role badges
Root cause: the `CrownIcon` component (used for the owner badge) was missing
the `size` prop that its sibling icons (`StarIcon`, `ShieldIcon`, etc.) all
accept — so `<CrownIcon size={12} />` silently did nothing and the SVG
rendered at an oversized default. Fixed the component to accept `size`
properly, and backed it with explicit CSS sizing in every context it
appears (navbar avatar badge, navbar dropdown, profile page) so it can't
balloon again even if a future call site forgets the prop.

### New: Achievements system
17 unlockable badges across reading streaks, chapters read, bookmarks,
lists created, comments posted, and time-of-day reading (Night Owl / Early
Bird). Bronze/Silver/Gold/Platinum tiers. A celebratory toast fires the
moment a new one unlocks. Accessible from the navbar dropdown and a
dedicated `/achievements` page with a progress bar.

### New: Reading Lists / Collections
Create custom named collections of manga, mark them public or private,
add/remove manga directly from any manga's detail page via a new
"Add to list" picker, and discover other users' public lists on `/lists`.
Public lists can be liked and shared via a stable slug URL.

### New: Advanced search filters
Explore page now supports multi-genre selection (was single-genre before),
plus an "Advanced filters" expandable section for release-year range and
chapter-count range. All filters combine and are reflected in the result
count live.

### New: Custom branding (Admin → Branding)
Upload your own logo image and rename the site from the admin panel — no
code changes needed. Falls back to the default icon+text logo if no custom
logo is set.

---

## Carried over from earlier passes
## What's new in this pass

### Fixed: scraper showing "processed: 25, errors: 0" but adding zero chapters
The previous run summary only tracked manga-level success/failure. A manga
record could save successfully (so it counted as "processed") even when
**every chapter page-fetch silently failed** — which is exactly what was
happening, because MangaDex's `/at-home/server/{id}` endpoint (used to fetch
actual page images) has a separate, stricter rate limit than the main API,
and the old retry/backoff timing wasn't tuned for it.

Fixed by:
- Separate, longer retry/backoff specifically for the page-fetch endpoint (5 retries, 3s base delay, vs. 4 retries/2s elsewhere)
- Real per-stage counters: chapters attempted, added, skipped (already existed), failed at page-fetch, failed for other reasons
- A `failureSamples` array with up to 10 concrete reasons (e.g. `HTTP 429`, `no-files-in-response`) surfaced in both the server console and a new **"Last run result"** panel in Admin → Scraper
- An explicit console warning + on-screen banner when chapters added = 0 but chapters were attempted, telling you it's almost certainly rate-limiting and to retry shortly

### Fixed: admin login confusion ("already registered" / logs into wrong account)
This wasn't a bug in the matching logic — it was a missing-information problem.
On first boot, the server **silently** creates an owner account using
`ADMIN_EMAIL`/`ADMIN_PASSWORD` from `.env` (or defaults). If you didn't know
this account already existed and tried to register with that same email
expecting to create your own admin login, you'd correctly get "already
registered" — then logging in with credentials you registered separately
correctly gave you a normal member account, because that's what it was.

Fixed by:
- The owner-creation banner is now impossible to miss: a bordered console block printing the exact email/password, plus the same info written to `backend/OWNER_CREDENTIALS.txt` (gitignored) so it's never lost in scrollback
- If a normal account already exists with the reserved admin email (e.g. you registered before ever booting the server with that email), the server **promotes that existing account to owner** instead of throwing a duplicate-key error and leaving the site with no owner at all
- New **"Make admin" / "Remove admin"** buttons in Admin → Users (owner-only), so you can promote your own real account to admin directly instead of having to use the bootstrap owner account at all
- `.env.example` now explicitly warns that `ADMIN_EMAIL` is reserved and shouldn't be used to register through the website

### Visual identity — replaced entirely
- **New fonts**: Plus Jakarta Sans (UI) + Lexend (headings) replace the old Syne pairing — sharper, more "real product," less decorative
- **Live theme engine**: every color in the app is a CSS variable fed from the database, not hardcoded. Swapping themes changes the *entire* site instantly, including text, borders, accents, and badge colors
- Corner-radius and font are also part of the theme (sharp/soft/round; 4 font choices)
- Removed every leftover emoji, stray "Syne" reference, and old hardcoded color variable from the previous pass

### Theme customizer (Admin → Theme tab) — your main ask
- **5 built-in presets**: Violet Night, Crimson Manga, Ocean Depth, Emerald Forest, Pure Light (a real light mode)
- **Live preview**: editing colors updates the whole site immediately for you, before saving — nobody else sees it until you activate
- **Full custom control**: a color picker for every semantic color (background, surface, text, accent, success/warning/danger, etc.), not just a few presets
- Duplicate any preset as a starting point, edit, save as a new custom theme, delete custom themes you don't want
- Only one theme is "active" (live for all visitors) at a time — switch any time from the admin panel

### New features
- **Rankings / leaderboard page** — Today / This week / This month / All-time tabs, podium for top 3, ranked list below, accessible from the navbar, bottom nav, and profile menu
- **Advanced reader settings** — brightness slider (40–130%), zoom (70–180%), and reading direction (vertical scroll / page LTR / page RTL for manga-style right-to-left), all persisted locally and restored next session
- **Comments** — per-manga comment threads with likes, edit, delete, and role badges (admin/owner/premium shown inline). Moderation: admins/owners can delete any comment
- **Notifications** — bell icon in the navbar with unread badge; users get notified when a manga they've bookmarked gets a new chapter; mark-as-read, mark-all-read, clear-all
- **Reading streaks & XP** — daily streak counter (current + longest) and XP shown on the profile and in the navbar dropdown; increments automatically as you read chapters
- **Continue Reading rail** — home page now shows a personalized row of in-progress manga with a progress bar baked into the card
- **Command palette (⌘K / Ctrl+K)** — instant fuzzy search overlay from anywhere in the app, keyboard-navigable
- **Related manga** — manga detail page now suggests similar titles based on shared genres
- **Resume reading** — manga detail page's primary action becomes "Resume Ch. X" instead of "Start reading" once you've made progress

### Carried over from the previous hardening pass (still in place)
- JWT_SECRET boot validation (server refuses to start with a missing/weak secret instead of crashing requests silently)
- Case-insensitive login, generic non-enumerable auth errors, banned-user checks
- Fixed MangaDex scraper param serialization (bracket-style query params), retry/backoff on rate-limits and timeouts, collision-safe slug generation

## Setup

### Backend
```bash
cd backend
npm install
cp .env.example .env
# Edit .env — set JWT_SECRET (required) and ADMIN_PASSWORD
npm run dev
```

Generate a secret:
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

### Frontend
```bash
cd frontend
npm install
npm start
```

Runs on `http://localhost:3000`, proxying API calls to `http://localhost:5000`.

### First login
A default **owner** account is created on first boot from `ADMIN_EMAIL` / `ADMIN_PASSWORD` in `.env` (defaults to `admin@mangaflux.com` / `admin123` — change immediately).

### Setting your theme
Go to **Admin Panel → Theme**. Click any preset to preview it live, adjust colors with the pickers, then **Save & activate** to push it to everyone. Built-in presets are seeded automatically on first boot.

### Populating manga
**Admin Panel → Scraper → Run now** pulls the first batch from MangaDex (1–3 minutes). Runs automatically 8s after every boot and every 6 hours after.
