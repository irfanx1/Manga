# MangaFlux v3 — Full Redesign + Feature Pack

A ground-up visual and functional overhaul. This is not a re-skin — fonts, the
entire color system, and a stack of real features have been rebuilt.

## What's new in this pass

### Visual identity — replaced entirely
- **New fonts**: Plus Jakarta Sans (UI) + Lexend (headings) replace the old Syne pairing — sharper, more "real product," less decorative
- **Live theme engine**: every color in the app is a CSS variable fed from the database, not hardcoded. Swapping themes changes the *entire* site instantly, including text, borders, accents, and badge colors
- Corner-radius and font are also part of the theme (sharp/soft/round; 4 font choices)
- Removed every leftover emoji, stray "Syne" reference, and old hardcoded color variable from the previous pass

### Theme customizer (Admin → Theme tab) — your main ask
- **5 built-in presets**: Violet Night, Crimson Manga, Ocean Depth, Emerald Forest, Pure Light (a real light mode)
- **Live preview**: editing colors updates the whole site immediately for you, before saving — nobody else sees it until you activate
- **Full custom control**: a color picker for every semantic color (background, surface, text, accent, success/warning/danger, etc.), not just a few presets
- Duplicate any preset as a starting point, edit, save as a new custom theme, delete custom themes you don't want
- Only one theme is "active" (live for all visitors) at a time — switch any time from the admin panel

### New features
- **Rankings / leaderboard page** — Today / This week / This month / All-time tabs, podium for top 3, ranked list below, accessible from the navbar, bottom nav, and profile menu
- **Advanced reader settings** — brightness slider (40–130%), zoom (70–180%), and reading direction (vertical scroll / page LTR / page RTL for manga-style right-to-left), all persisted locally and restored next session
- **Comments** — per-manga comment threads with likes, edit, delete, and role badges (admin/owner/premium shown inline). Moderation: admins/owners can delete any comment
- **Notifications** — bell icon in the navbar with unread badge; users get notified when a manga they've bookmarked gets a new chapter; mark-as-read, mark-all-read, clear-all
- **Reading streaks & XP** — daily streak counter (current + longest) and XP shown on the profile and in the navbar dropdown; increments automatically as you read chapters
- **Continue Reading rail** — home page now shows a personalized row of in-progress manga with a progress bar baked into the card
- **Command palette (⌘K / Ctrl+K)** — instant fuzzy search overlay from anywhere in the app, keyboard-navigable
- **Related manga** — manga detail page now suggests similar titles based on shared genres
- **Resume reading** — manga detail page's primary action becomes "Resume Ch. X" instead of "Start reading" once you've made progress

### Carried over from the previous hardening pass (still in place)
- JWT_SECRET boot validation (server refuses to start with a missing/weak secret instead of crashing requests silently)
- Case-insensitive login, generic non-enumerable auth errors, banned-user checks
- Fixed MangaDex scraper param serialization (bracket-style query params), retry/backoff on rate-limits and timeouts, collision-safe slug generation

## Setup

### Backend
```bash
cd backend
npm install
cp .env.example .env
# Edit .env — set JWT_SECRET (required) and ADMIN_PASSWORD
npm run dev
```

Generate a secret:
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

### Frontend
```bash
cd frontend
npm install
npm start
```

Runs on `http://localhost:3000`, proxying API calls to `http://localhost:5000`.

### First login
A default **owner** account is created on first boot from `ADMIN_EMAIL` / `ADMIN_PASSWORD` in `.env` (defaults to `admin@mangaflux.com` / `admin123` — change immediately).

### Setting your theme
Go to **Admin Panel → Theme**. Click any preset to preview it live, adjust colors with the pickers, then **Save & activate** to push it to everyone. Built-in presets are seeded automatically on first boot.

### Populating manga
**Admin Panel → Scraper → Run now** pulls the first batch from MangaDex (1–3 minutes). Runs automatically 8s after every boot and every 6 hours after.
