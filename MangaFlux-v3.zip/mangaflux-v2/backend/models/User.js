const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  username:    { type: String, required: true, unique: true, trim: true, minlength: 3, maxlength: 30 },
  email:       { type: String, required: true, unique: true, lowercase: true, trim: true },
  password:    { type: String, required: true, minlength: 6, select: false },
  avatar:      { type: String, default: '' },
  role:        { type: String, enum: ['user', 'admin', 'owner'], default: 'user' },
  isPremium:   { type: Boolean, default: false },
  premiumUntil:{ type: Date, default: null },

  bookmarks:   [{ type: mongoose.Schema.Types.ObjectId, ref: 'Manga' }],
  following:   [{ type: mongoose.Schema.Types.ObjectId, ref: 'Manga' }],

  readHistory: [{
    manga:   { type: mongoose.Schema.Types.ObjectId, ref: 'Manga' },
    chapter: { type: mongoose.Schema.Types.ObjectId, ref: 'Chapter' },
    page:    { type: Number, default: 1 },
    readAt:  { type: Date, default: Date.now }
  }],

  // Per-manga progress so "continue reading" can resume mid-chapter
  progress: [{
    manga:        { type: mongoose.Schema.Types.ObjectId, ref: 'Manga' },
    chapterNumber:{ type: Number },
    page:         { type: Number, default: 1 },
    updatedAt:    { type: Date, default: Date.now },
  }],

  // Reading streak
  streak: {
    current:   { type: Number, default: 0 },
    longest:   { type: Number, default: 0 },
    lastReadAt:{ type: Date, default: null },
  },

  // XP / stats for profile + leaderboard
  stats: {
    chaptersRead: { type: Number, default: 0 },
    xp:           { type: Number, default: 0 },
  },

  preferences: {
    readingMode:      { type: String, enum: ['scroll', 'page'], default: 'scroll' },
    readingDirection: { type: String, enum: ['ltr', 'rtl', 'vertical'], default: 'vertical' },
    brightness:       { type: Number, default: 100, min: 30, max: 130 },
    zoom:             { type: Number, default: 100, min: 60, max: 200 },
    theme:            { type: String, default: 'dark' },
    notifyNewChapters:{ type: Boolean, default: true },
  },

  notifications: [{
    type:    { type: String, enum: ['new_chapter', 'system', 'comment_reply'], default: 'system' },
    message: String,
    manga:   { type: mongoose.Schema.Types.ObjectId, ref: 'Manga' },
    read:    { type: Boolean, default: false },
    createdAt: { type: Date, default: Date.now },
  }],

  isActive:  { type: Boolean, default: true },
  isBanned:  { type: Boolean, default: false },
  lastSeen:  { type: Date, default: Date.now },
}, { timestamps: true });

userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

userSchema.methods.comparePassword = async function(password) {
  return bcrypt.compare(password, this.password);
};

// Call whenever a chapter is completed — updates streak + xp
userSchema.methods.registerRead = function() {
  const now = new Date();
  const last = this.streak.lastReadAt;
  const oneDay = 86400000;

  if (!last) {
    this.streak.current = 1;
  } else {
    const gap = new Date(now).setHours(0,0,0,0) - new Date(last).setHours(0,0,0,0);
    if (gap === oneDay) this.streak.current += 1;
    else if (gap > oneDay) this.streak.current = 1;
    // gap === 0 → same day, streak unchanged
  }
  this.streak.longest = Math.max(this.streak.longest, this.streak.current);
  this.streak.lastReadAt = new Date();
  this.stats.chaptersRead += 1;
  this.stats.xp += 10;
};

userSchema.methods.toJSON = function() {
  const obj = this.toObject();
  delete obj.password;
  return obj;
};

module.exports = mongoose.model('User', userSchema);
