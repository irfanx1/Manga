const mongoose = require('mongoose');

const colorFields = {
  bg:        { type: String, default: '#0a0a12' },
  bgElevated:{ type: String, default: '#12121e' },
  surface:   { type: String, default: '#171727' },
  border:    { type: String, default: 'rgba(255,255,255,0.08)' },
  text:      { type: String, default: '#f5f5fb' },
  textMuted: { type: String, default: '#8b8ba8' },
  accent:    { type: String, default: '#8b5cf6' },
  accentHi:  { type: String, default: '#a78bfa' },
  accent2:   { type: String, default: '#06b6d4' },
  success:   { type: String, default: '#22c55e' },
  warning:   { type: String, default: '#f59e0b' },
  danger:    { type: String, default: '#ef4444' },
};

const themeSchema = new mongoose.Schema({
  name:      { type: String, required: true, trim: true },
  isPreset:  { type: Boolean, default: false },   // built-in presets, not user-deletable
  isActive:  { type: Boolean, default: false },    // the one live on the site
  colors:    colorFields,
  radius:    { type: String, enum: ['sharp', 'soft', 'round'], default: 'soft' },
  font:      { type: String, enum: ['jakarta', 'inter', 'manrope', 'sora'], default: 'jakarta' },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
}, { timestamps: true });

// Only one theme may be active at a time
themeSchema.statics.setActive = async function (id) {
  const Theme = this;
  await Theme.updateMany({}, { isActive: false });
  const theme = await Theme.findByIdAndUpdate(id, { isActive: true }, { new: true });
  return theme;
};

module.exports = mongoose.model('Theme', themeSchema);
