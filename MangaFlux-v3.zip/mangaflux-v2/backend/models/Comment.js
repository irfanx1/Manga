const mongoose = require('mongoose');

const commentSchema = new mongoose.Schema({
  manga:    { type: mongoose.Schema.Types.ObjectId, ref: 'Manga', required: true },
  chapter:  { type: mongoose.Schema.Types.ObjectId, ref: 'Chapter', default: null }, // null = manga-level comment
  user:     { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  body:     { type: String, required: true, trim: true, maxlength: 1000 },
  parent:   { type: mongoose.Schema.Types.ObjectId, ref: 'Comment', default: null },
  likes:    [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  isEdited: { type: Boolean, default: false },
  isDeleted:{ type: Boolean, default: false },
}, { timestamps: true });

commentSchema.index({ manga: 1, chapter: 1, createdAt: -1 });

module.exports = mongoose.model('Comment', commentSchema);
