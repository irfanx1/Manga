const express = require('express');
const Theme = require('../models/Theme');
const { protect, restrictTo } = require('../middleware/auth');
const router = express.Router();

const BUILT_IN_PRESETS = [
  {
    name: 'Violet Night', isPreset: true,
    colors: { bg:'#0a0a12', bgElevated:'#12121e', surface:'#171727', border:'rgba(255,255,255,0.08)',
      text:'#f5f5fb', textMuted:'#8b8ba8', accent:'#8b5cf6', accentHi:'#a78bfa', accent2:'#06b6d4',
      success:'#22c55e', warning:'#f59e0b', danger:'#ef4444' },
    radius: 'soft', font: 'jakarta',
  },
  {
    name: 'Crimson Manga', isPreset: true,
    colors: { bg:'#0d0a0a', bgElevated:'#171010', surface:'#1f1414', border:'rgba(255,255,255,0.08)',
      text:'#fbf5f5', textMuted:'#a88b8b', accent:'#e11d48', accentHi:'#fb7185', accent2:'#f59e0b',
      success:'#22c55e', warning:'#f59e0b', danger:'#ef4444' },
    radius: 'sharp', font: 'sora',
  },
  {
    name: 'Ocean Depth', isPreset: true,
    colors: { bg:'#08111a', bgElevated:'#0e1c29', surface:'#142634', border:'rgba(255,255,255,0.08)',
      text:'#f0f7fb', textMuted:'#7fa3b8', accent:'#0ea5e9', accentHi:'#38bdf8', accent2:'#a78bfa',
      success:'#22c55e', warning:'#f59e0b', danger:'#ef4444' },
    radius: 'round', font: 'manrope',
  },
  {
    name: 'Emerald Forest', isPreset: true,
    colors: { bg:'#0a120e', bgElevated:'#0f1c15', surface:'#15281d', border:'rgba(255,255,255,0.08)',
      text:'#f3fbf6', textMuted:'#84a896', accent:'#10b981', accentHi:'#34d399', accent2:'#f59e0b',
      success:'#22c55e', warning:'#f59e0b', danger:'#ef4444' },
    radius: 'soft', font: 'inter',
  },
  {
    name: 'Pure Light', isPreset: true,
    colors: { bg:'#f7f7fb', bgElevated:'#ffffff', surface:'#f0f0f7', border:'rgba(0,0,0,0.08)',
      text:'#15151f', textMuted:'#6b6b85', accent:'#7c3aed', accentHi:'#6d28d9', accent2:'#0891b2',
      success:'#16a34a', warning:'#d97706', danger:'#dc2626' },
    radius: 'soft', font: 'jakarta',
  },
];

// Seed built-in presets once if none exist
async function ensurePresets() {
  const count = await Theme.countDocuments({ isPreset: true });
  if (count === 0) {
    const created = await Theme.insertMany(BUILT_IN_PRESETS);
    const anyActive = await Theme.findOne({ isActive: true });
    if (!anyActive) await Theme.setActive(created[0]._id);
  }
}
ensurePresets().catch(e => console.error('[Theme] Preset seed failed:', e.message));

// ── Public: get active theme ─────────────────────────────────────────────────
router.get('/active', async (req, res) => {
  try {
    let theme = await Theme.findOne({ isActive: true });
    if (!theme) {
      await ensurePresets();
      theme = await Theme.findOne({ isActive: true });
    }
    res.json({ theme });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── Public: list all themes (for picker previews) ────────────────────────────
router.get('/', async (req, res) => {
  try {
    const themes = await Theme.find().sort({ isPreset: -1, createdAt: 1 });
    res.json({ themes });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── Admin: create custom theme ────────────────────────────────────────────────
router.post('/', protect, restrictTo('admin', 'owner'), async (req, res) => {
  try {
    const { name, colors, radius, font } = req.body;
    if (!name?.trim()) return res.status(400).json({ message: 'Theme name is required' });
    const theme = await Theme.create({
      name: name.trim(), colors, radius, font,
      isPreset: false, createdBy: req.user._id,
    });
    res.status(201).json({ theme });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// ── Admin: update a theme's colors ────────────────────────────────────────────
router.patch('/:id', protect, restrictTo('admin', 'owner'), async (req, res) => {
  try {
    const { name, colors, radius, font } = req.body;
    const update = {};
    if (name !== undefined)   update.name = name;
    if (colors !== undefined) update.colors = colors;
    if (radius !== undefined) update.radius = radius;
    if (font !== undefined)   update.font = font;

    const theme = await Theme.findByIdAndUpdate(req.params.id, update, { new: true, runValidators: true });
    if (!theme) return res.status(404).json({ message: 'Theme not found' });
    res.json({ theme });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// ── Admin: activate a theme site-wide ─────────────────────────────────────────
router.post('/:id/activate', protect, restrictTo('admin', 'owner'), async (req, res) => {
  try {
    const theme = await Theme.setActive(req.params.id);
    if (!theme) return res.status(404).json({ message: 'Theme not found' });
    res.json({ theme });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── Admin: delete a custom theme (not presets, not the active one) ───────────
router.delete('/:id', protect, restrictTo('admin', 'owner'), async (req, res) => {
  try {
    const theme = await Theme.findById(req.params.id);
    if (!theme) return res.status(404).json({ message: 'Theme not found' });
    if (theme.isPreset) return res.status(403).json({ message: 'Built-in presets cannot be deleted' });
    if (theme.isActive) return res.status(400).json({ message: 'Cannot delete the currently active theme' });
    await theme.deleteOne();
    res.json({ message: 'Deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
