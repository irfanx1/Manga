const express = require('express');
const Comment = require('../models/Comment');
const Manga   = require('../models/Manga');
const { protect, optionalAuth, restrictTo } = require('../middleware/auth');
const router = express.Router();

// ── List comments for a manga (or a specific chapter) ────────────────────────
router.get('/manga/:mangaId', optionalAuth, async (req, res) => {
  try {
    const { chapter } = req.query;
    const query = { manga: req.params.mangaId, isDeleted: false };
    query.chapter = chapter || null;

    const comments = await Comment.find(query)
      .sort('-createdAt')
      .limit(200)
      .populate('user', 'username avatar role isPremium')
      .lean();

    const userId = req.user?._id?.toString();
    const shaped = comments.map(c => ({
      ...c,
      likeCount: c.likes?.length || 0,
      likedByMe: userId ? c.likes?.some(l => l.toString() === userId) : false,
      likes: undefined,
    }));

    res.json({ comments: shaped, total: shaped.length });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── Post a comment ───────────────────────────────────────────────────────────
router.post('/manga/:mangaId', protect, async (req, res) => {
  try {
    const { body, chapter, parent } = req.body;
    if (!body?.trim()) return res.status(400).json({ message: 'Comment cannot be empty' });
    if (body.length > 1000) return res.status(400).json({ message: 'Comment is too long (max 1000 characters)' });

    const manga = await Manga.findById(req.params.mangaId).select('_id');
    if (!manga) return res.status(404).json({ message: 'Manga not found' });

    const comment = await Comment.create({
      manga: req.params.mangaId,
      chapter: chapter || null,
      parent: parent || null,
      user: req.user._id,
      body: body.trim(),
    });
    await comment.populate('user', 'username avatar role isPremium');
    res.status(201).json({ comment });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// ── Edit own comment ──────────────────────────────────────────────────────────
router.patch('/:id', protect, async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id);
    if (!comment || comment.isDeleted) return res.status(404).json({ message: 'Comment not found' });
    if (comment.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'You can only edit your own comments' });
    }
    if (!req.body.body?.trim()) return res.status(400).json({ message: 'Comment cannot be empty' });

    comment.body = req.body.body.trim();
    comment.isEdited = true;
    await comment.save();
    res.json({ comment });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// ── Delete (own comment or admin) ────────────────────────────────────────────
router.delete('/:id', protect, async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id);
    if (!comment) return res.status(404).json({ message: 'Comment not found' });
    const isOwn = comment.user.toString() === req.user._id.toString();
    const isMod = ['admin', 'owner'].includes(req.user.role);
    if (!isOwn && !isMod) return res.status(403).json({ message: 'Not allowed' });

    comment.isDeleted = true;
    comment.body = '[deleted]';
    await comment.save();
    res.json({ message: 'Deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── Like / unlike ─────────────────────────────────────────────────────────────
router.post('/:id/like', protect, async (req, res) => {
  try {
    const comment = await Comment.findById(req.params.id);
    if (!comment) return res.status(404).json({ message: 'Comment not found' });

    const idx = comment.likes.findIndex(l => l.toString() === req.user._id.toString());
    if (idx === -1) comment.likes.push(req.user._id);
    else comment.likes.splice(idx, 1);

    await comment.save();
    res.json({ liked: idx === -1, likeCount: comment.likes.length });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
