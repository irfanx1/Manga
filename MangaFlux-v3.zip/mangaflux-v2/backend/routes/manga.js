const express = require('express');
const Manga   = require('../models/Manga');
const Chapter = require('../models/Chapter');
const User    = require('../models/User');
const { protect, restrictTo, optionalAuth } = require('../middleware/auth');
const router = express.Router();

// ── List / search manga ──────────────────────────────────────────────────────
router.get('/', optionalAuth, async (req, res) => {
  try {
    const {
      page = 1, limit = 20,
      genre, status, type, sort = '-lastUpdated',
      search, featured, isPremium
    } = req.query;

    const safeLimit = Math.min(Number(limit) || 20, 100);
    const safePage  = Math.max(Number(page) || 1, 1);

    const query = { isPublished: true };
    if (genre)     query.genres  = { $in: [genre] };
    if (status)    query.status  = status;
    if (type)      query.type    = type;
    if (featured)  query.featured   = true;
    if (isPremium) query.isPremium  = isPremium === 'true';
    if (search)    query.$text = { $search: search };

    const [total, manga] = await Promise.all([
      Manga.countDocuments(query),
      Manga.find(query)
        .sort(sort)
        .limit(safeLimit)
        .skip((safePage - 1) * safeLimit)
        .select('title coverImage type status genres rating views bookmarkCount chapterCount latestChapter lastUpdated slug featured isPremium'),
    ]);

    res.json({ manga, total, page: safePage, pages: Math.ceil(total / safeLimit) });
  } catch (err) {
    console.error('[Manga] List error:', err.message);
    res.status(500).json({ message: 'Failed to load manga list' });
  }
});

// ── Rankings / leaderboard ───────────────────────────────────────────────────
// period: today | week | month | all
router.get('/rankings/:period', async (req, res) => {
  try {
    const { period } = req.params;
    const validPeriods = ['today', 'week', 'month', 'all'];
    if (!validPeriods.includes(period)) return res.status(400).json({ message: 'Invalid period' });

    // We don't have time-bucketed view counters in this schema version, so we
    // approximate "today/week/month" momentum using lastUpdated recency combined
    // with views, and fall back to pure views for "all".
    let sort = '-views';
    let query = { isPublished: true };
    const now = Date.now();
    if (period === 'today') query.lastUpdated = { $gte: new Date(now - 86400000) };
    if (period === 'week')  query.lastUpdated = { $gte: new Date(now - 7 * 86400000) };
    if (period === 'month') query.lastUpdated = { $gte: new Date(now - 30 * 86400000) };

    let manga = await Manga.find(query).sort(sort).limit(50)
      .select('title coverImage type status genres rating views bookmarkCount chapterCount slug');

    // If a recency window returns too few results, backfill with all-time top views
    if (manga.length < 10 && period !== 'all') {
      const backfill = await Manga.find({ isPublished: true }).sort('-views').limit(50)
        .select('title coverImage type status genres rating views bookmarkCount chapterCount slug');
      const seen = new Set(manga.map(m => m._id.toString()));
      manga = [...manga, ...backfill.filter(m => !seen.has(m._id.toString()))].slice(0, 50);
    }

    res.json({ period, manga });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── Single manga by slug ─────────────────────────────────────────────────────
router.get('/:slug', optionalAuth, async (req, res) => {
  try {
    const manga = await Manga.findOne({ slug: req.params.slug, isPublished: true });
    if (!manga) return res.status(404).json({ message: 'Manga not found' });

    Manga.findByIdAndUpdate(manga._id, { $inc: { views: 1 } }).exec().catch(() => {});

    const chapters = await Chapter.find({ manga: manga._id, isPublished: true })
      .sort('-number')
      .select('number title views uploadedAt createdAt');

    // Related manga — same primary genre, excluding self
    const related = manga.genres?.length
      ? await Manga.find({
          _id: { $ne: manga._id },
          genres: { $in: manga.genres },
          isPublished: true,
        }).sort('-views').limit(8).select('title coverImage type status rating slug')
      : [];

    let myProgress = null;
    if (req.user) {
      const u = await User.findById(req.user._id).select('progress');
      myProgress = u.progress.find(p => p.manga.toString() === manga._id.toString()) || null;
    }

    res.json({ manga, chapters, related, myProgress });
  } catch (err) {
    console.error('[Manga] Detail error:', err.message);
    res.status(500).json({ message: 'Failed to load manga' });
  }
});

// ── Single chapter ───────────────────────────────────────────────────────────
router.get('/:slug/chapter/:number', optionalAuth, async (req, res) => {
  try {
    const manga = await Manga.findOne({ slug: req.params.slug })
      .select('title slug coverImage');
    if (!manga) return res.status(404).json({ message: 'Manga not found' });

    const num = Number(req.params.number);
    if (Number.isNaN(num)) return res.status(400).json({ message: 'Invalid chapter number' });

    const chapter = await Chapter.findOne({ manga: manga._id, number: num });
    if (!chapter) return res.status(404).json({ message: 'Chapter not found' });

    Chapter.findByIdAndUpdate(chapter._id, { $inc: { views: 1 } }).exec().catch(() => {});

    if (req.user) {
      const user = await User.findById(req.user._id);
      user.readHistory.push({ manga: manga._id, chapter: chapter._id, readAt: new Date() });
      if (user.readHistory.length > 200) user.readHistory = user.readHistory.slice(-200);

      const pIdx = user.progress.findIndex(p => p.manga.toString() === manga._id.toString());
      const progressEntry = { manga: manga._id, chapterNumber: num, page: 1, updatedAt: new Date() };
      if (pIdx === -1) user.progress.push(progressEntry);
      else user.progress[pIdx] = progressEntry;

      user.registerRead();
      user.lastSeen = new Date();
      await user.save();
    }

    const [prev, next] = await Promise.all([
      Chapter.findOne({ manga: manga._id, number: { $lt: num } }).sort('-number').select('number title'),
      Chapter.findOne({ manga: manga._id, number: { $gt: num } }).sort('number').select('number title'),
    ]);

    res.json({ manga, chapter, prev, next });
  } catch (err) {
    console.error('[Manga] Chapter error:', err.message);
    res.status(500).json({ message: 'Failed to load chapter' });
  }
});

// ── Update reading progress (page-level, without full chapter load) ──────────
router.post('/:id/progress', protect, async (req, res) => {
  try {
    const { chapterNumber, page } = req.body;
    const user = await User.findById(req.user._id);
    const idx = user.progress.findIndex(p => p.manga.toString() === req.params.id);
    const entry = { manga: req.params.id, chapterNumber, page: page || 1, updatedAt: new Date() };
    if (idx === -1) user.progress.push(entry);
    else user.progress[idx] = entry;
    await user.save();
    res.json({ message: 'ok' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── Create manga (admin) ─────────────────────────────────────────────────────
router.post('/', protect, restrictTo('admin', 'owner'), async (req, res) => {
  try {
    if (!req.body.title?.trim()) return res.status(400).json({ message: 'Title is required' });
    const manga = await Manga.create(req.body);
    res.status(201).json({ manga });
  } catch (err) {
    res.status(400).json({ message: err.message || 'Failed to create manga' });
  }
});

// ── Update manga (admin) ─────────────────────────────────────────────────────
router.patch('/:id', protect, restrictTo('admin', 'owner'), async (req, res) => {
  try {
    const manga = await Manga.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!manga) return res.status(404).json({ message: 'Manga not found' });
    res.json({ manga });
  } catch (err) {
    res.status(500).json({ message: err.message || 'Update failed' });
  }
});

// ── Delete manga (admin) ─────────────────────────────────────────────────────
router.delete('/:id', protect, restrictTo('admin', 'owner'), async (req, res) => {
  try {
    const manga = await Manga.findByIdAndDelete(req.params.id);
    if (!manga) return res.status(404).json({ message: 'Manga not found' });
    await Chapter.deleteMany({ manga: req.params.id });
    res.json({ message: 'Deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── Add chapter (admin) — also fans out "new chapter" notifications ──────────
router.post('/:id/chapters', protect, restrictTo('admin', 'owner'), async (req, res) => {
  try {
    const chapter = await Chapter.create({ ...req.body, manga: req.params.id });
    const manga = await Manga.findByIdAndUpdate(req.params.id, {
      $inc: { chapterCount: 1 },
      $max: { latestChapter: chapter.number },
      lastUpdated: new Date(),
    }, { new: true });

    // Notify everyone who bookmarked/follows this manga and has it enabled
    User.updateMany(
      { bookmarks: req.params.id, 'preferences.notifyNewChapters': true },
      { $push: { notifications: {
        $each: [{ type: 'new_chapter', message: `New chapter ${chapter.number} of "${manga.title}" is out`, manga: req.params.id }],
        $slice: -50,
      }}}
    ).exec().catch(e => console.error('[Notify] fan-out failed:', e.message));

    res.status(201).json({ chapter });
  } catch (err) {
    if (err.code === 11000) return res.status(409).json({ message: 'That chapter number already exists' });
    res.status(400).json({ message: err.message });
  }
});

module.exports = router;
