const express = require('express');
const User = require('../models/User');
const { protect } = require('../middleware/auth');
const router = express.Router();

// ── List notifications ────────────────────────────────────────────────────────
router.get('/', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select('notifications').populate('notifications.manga', 'title slug coverImage');
    const sorted = [...user.notifications].sort((a, b) => b.createdAt - a.createdAt).slice(0, 50);
    const unreadCount = user.notifications.filter(n => !n.read).length;
    res.json({ notifications: sorted, unreadCount });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── Mark one as read ──────────────────────────────────────────────────────────
router.patch('/:id/read', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    const n = user.notifications.find(x => x._id.toString() === req.params.id);
    if (!n) return res.status(404).json({ message: 'Notification not found' });
    n.read = true;
    await user.save();
    res.json({ message: 'ok' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── Mark all as read ───────────────────────────────────────────────────────────
router.patch('/read-all', protect, async (req, res) => {
  try {
    await User.updateOne(
      { _id: req.user._id },
      { $set: { 'notifications.$[].read': true } }
    );
    res.json({ message: 'ok' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── Clear all ──────────────────────────────────────────────────────────────────
router.delete('/', protect, async (req, res) => {
  try {
    await User.findByIdAndUpdate(req.user._id, { $set: { notifications: [] } });
    res.json({ message: 'ok' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
