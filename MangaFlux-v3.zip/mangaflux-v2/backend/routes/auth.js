const express = require('express');
const jwt     = require('jsonwebtoken');
const User    = require('../models/User');
const { protect } = require('../middleware/auth');
const router  = express.Router();

const signToken = (id) =>
  jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '30d',
  });

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// ── Register ─────────────────────────────────────────────────────────────────
router.post('/register', async (req, res) => {
  try {
    let { username, email, password } = req.body;
    username = (username || '').trim();
    email    = (email || '').trim().toLowerCase();

    if (!username || !email || !password)
      return res.status(400).json({ message: 'All fields are required' });
    if (username.length < 3)
      return res.status(400).json({ message: 'Username must be at least 3 characters' });
    if (!EMAIL_RE.test(email))
      return res.status(400).json({ message: 'Please enter a valid email address' });
    if (password.length < 6)
      return res.status(400).json({ message: 'Password must be at least 6 characters' });

    // Case-insensitive uniqueness check (email is stored lowercase; username compared loosely)
    const exists = await User.findOne({
      $or: [{ email }, { username: new RegExp(`^${username.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i') }],
    });
    if (exists) {
      const field = exists.email === email ? 'email' : 'username';
      return res.status(409).json({ message: `That ${field} is already in use` });
    }

    const user = await User.create({ username, email, password });
    const token = signToken(user._id);
    res.status(201).json({ token, user });
  } catch (err) {
    if (err.code === 11000) {
      return res.status(409).json({ message: 'Username or email already in use' });
    }
    console.error('[Auth] Register error:', err.message);
    res.status(500).json({ message: 'Registration failed. Please try again.' });
  }
});

// ── Login ─────────────────────────────────────────────────────────────────────
router.post('/login', async (req, res) => {
  try {
    let { email, password } = req.body;
    email = (email || '').trim().toLowerCase();

    if (!email || !password)
      return res.status(400).json({ message: 'Email and password are required' });

    // Explicitly select password since schema has select:false
    const user = await User.findOne({ email }).select('+password');

    // Always run comparePassword-equivalent timing even on missing user to reduce
    // user-enumeration timing signal, then return a generic message either way.
    const valid = user ? await user.comparePassword(password) : false;
    if (!user || !valid) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }
    if (user.isBanned) {
      return res.status(403).json({ message: 'This account has been suspended. Contact support.' });
    }

    // Fire-and-forget lastSeen update — don't block the response on it
    User.findByIdAndUpdate(user._id, { lastSeen: new Date() }).exec().catch(() => {});

    const token = signToken(user._id);
    res.json({ token, user: user.toJSON() });
  } catch (err) {
    console.error('[Auth] Login error:', err.message);
    res.status(500).json({ message: 'Login failed. Please try again.' });
  }
});

// ── Get current user ──────────────────────────────────────────────────────────
router.get('/me', protect, async (req, res) => {
  res.json({ user: req.user });
});

// ── Update profile ────────────────────────────────────────────────────────────
router.patch('/me', protect, async (req, res) => {
  try {
    const allowed = ['username', 'avatar', 'preferences'];
    const updates = {};
    allowed.forEach(f => { if (req.body[f] !== undefined) updates[f] = req.body[f]; });
    const user = await User.findByIdAndUpdate(req.user._id, updates, { new: true, runValidators: true });
    res.json({ user });
  } catch (err) {
    res.status(400).json({ message: err.message || 'Update failed' });
  }
});

// ── Toggle bookmark ───────────────────────────────────────────────────────────
router.post('/bookmark/:mangaId', protect, async (req, res) => {
  try {
    const user  = await User.findById(req.user._id);
    const Manga = require('../models/Manga');
    const idx   = user.bookmarks.findIndex(b => b.toString() === req.params.mangaId);

    if (idx === -1) {
      user.bookmarks.push(req.params.mangaId);
      Manga.findByIdAndUpdate(req.params.mangaId, { $inc: { bookmarkCount: 1 } }).exec().catch(() => {});
    } else {
      user.bookmarks.splice(idx, 1);
      Manga.findByIdAndUpdate(req.params.mangaId, { $inc: { bookmarkCount: -1 } }).exec().catch(() => {});
    }
    await user.save();
    res.json({ bookmarked: idx === -1, bookmarks: user.bookmarks });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── Delete account ────────────────────────────────────────────────────────────
router.delete('/me', protect, async (req, res) => {
  try {
    await User.findByIdAndDelete(req.user._id);
    res.json({ message: 'Account deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
