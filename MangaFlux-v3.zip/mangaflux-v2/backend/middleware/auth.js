const jwt  = require('jsonwebtoken');
const User = require('../models/User');

function getToken(req) {
  const header = req.headers.authorization;
  if (header?.startsWith('Bearer ')) return header.split(' ')[1];
  return null;
}

exports.protect = async (req, res, next) => {
  try {
    const token = getToken(req);
    if (!token) return res.status(401).json({ message: 'Not authenticated' });

    if (!process.env.JWT_SECRET) {
      console.error('[Auth] JWT_SECRET is not set. Check your .env file.');
      return res.status(500).json({ message: 'Server auth misconfiguration' });
    }

    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (err) {
      const message = err.name === 'TokenExpiredError'
        ? 'Session expired — please sign in again'
        : 'Invalid session — please sign in again';
      return res.status(401).json({ message });
    }

    const user = await User.findById(decoded.id).select('-password');
    if (!user) return res.status(401).json({ message: 'Account no longer exists' });
    if (user.isBanned) return res.status(403).json({ message: 'Account suspended. Contact support.' });

    req.user = user;
    next();
  } catch (err) {
    console.error('[Auth] Unexpected error:', err.message);
    res.status(401).json({ message: 'Authentication failed' });
  }
};

exports.restrictTo = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user?.role))
    return res.status(403).json({ message: 'Access denied' });
  next();
};

exports.optionalAuth = async (req, res, next) => {
  try {
    const token = getToken(req);
    if (token && process.env.JWT_SECRET) {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = await User.findById(decoded.id).select('-password');
    }
  } catch (_) {
    // Optional auth — silently proceed unauthenticated on any token issue
  }
  next();
};
