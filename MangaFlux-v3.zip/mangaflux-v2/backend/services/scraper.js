const cron = require('node-cron');
const { scrapeManga } = require('../scrapers/mangadex');

let scraperJob = null;
let isRunning  = false;
let lastRun    = null;
let lastError  = null;
let lastResult = null;

function start() {
  if (scraperJob) return;
  // Every 6 hours
  scraperJob = cron.schedule('0 */6 * * *', async () => {
    if (isRunning) return console.log('[ScraperService] Already running, skip.');
    await _run();
  });
  console.log('[ScraperService] Started — auto-runs every 6 hours');

  // Also run once on boot after a short delay, so the DB isn't empty on first launch
  setTimeout(async () => {
    if (!isRunning) {
      console.log('[ScraperService] Running initial scrape on boot...');
      await _run();
    }
  }, 8000);
}

function stop() {
  if (scraperJob) {
    scraperJob.stop();
    scraperJob = null;
    console.log('[ScraperService] Stopped');
  }
}

async function runNow(source = 'mangadex') {
  if (isRunning) {
    console.log('[ScraperService] Already running');
    return { ok: false, message: 'Already running' };
  }
  return _run(source);
}

async function _run(source = 'mangadex') {
  isRunning = true;
  lastRun = new Date();
  lastError = null;
  try {
    let result;
    if (source === 'mangadex') result = await scrapeManga();
    else throw new Error(`Unknown scraper source: ${source}`);

    lastResult = result;
    if (!result?.ok) lastError = result?.reason || 'Scrape returned no data';
    return result;
  } catch (e) {
    lastError = e.message;
    console.error('[ScraperService] Error:', e);
    return { ok: false, message: e.message };
  } finally {
    isRunning = false;
  }
}

function getStatus() {
  return { isRunning, lastRun, lastError, lastResult, scheduled: !!scraperJob };
}

module.exports = { start, stop, runNow, getStatus };
