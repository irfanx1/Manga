import { Link } from 'react-router-dom';
import './Terms.css';

function LegalHeader({ title, updated }) {
  return (
    <div className="legal-hero">
      <Link to="/" className="legal-logo">
        <span className="legal-logo__mark" />
        MangaFlux
      </Link>
      <h1 className="legal-title">{title}</h1>
      <p className="legal-updated">Last updated: {updated}</p>
    </div>
  );
}

export function Terms() {
  const sections = ['Acceptance', 'Use of Service', 'Content', 'Prohibited Conduct', 'Premium', 'Termination', 'Disclaimers', 'Contact'];
  return (
    <div className="page legal-page">
      <LegalHeader title="Terms of Service" updated="June 2026" />
      <div className="container legal-body">
        <div className="legal-toc">
          {sections.map((s, i) => <a key={s} href={`#s${i + 1}`} className="legal-toc__link">{i + 1}. {s}</a>)}
        </div>

        <Section id="s1" title="1. Acceptance of Terms">
          <p>By accessing or using MangaFlux ("Service", "we", "our"), you agree to be bound by these Terms of Service. If you disagree with any part of these terms, you may not access the Service.</p>
          <p>We reserve the right to modify these Terms at any time. Registered users will be notified of significant changes via email. Continued use after changes constitutes acceptance.</p>
        </Section>

        <Section id="s2" title="2. Use of Service">
          <p>MangaFlux provides access to manga, manhwa, and manhua content sourced from legitimate APIs (including MangaDex) and user-submitted content. You may access the Service for personal, non-commercial use only.</p>
          <p>You must be at least 13 years old to use this Service. Users under 18 must have parental consent. You are responsible for maintaining the security of your account credentials.</p>
        </Section>

        <Section id="s3" title="3. Content">
          <p>Content on MangaFlux is sourced from third-party APIs and may be subject to separate copyright and licensing terms. We make no claim of ownership over third-party content. Rights holders who believe content infringes their copyright may contact us at dmca@mangaflux.com.</p>
          <p>User-generated content (comments, reviews) remains your property. By posting, you grant MangaFlux a non-exclusive, royalty-free license to use, display, and distribute such content within the Service.</p>
        </Section>

        <Section id="s4" title="4. Prohibited Conduct">
          <ul>
            <li>Scraping, crawling, or systematically downloading content without written permission</li>
            <li>Sharing account credentials or allowing unauthorized access to your account</li>
            <li>Circumventing any technical measures protecting the Service</li>
            <li>Uploading or transmitting malicious code, viruses, or harmful software</li>
            <li>Harassing, threatening, or abusing other users or staff</li>
            <li>Creating multiple accounts to circumvent bans or limitations</li>
            <li>Using automated bots to interact with the Service</li>
          </ul>
        </Section>

        <Section id="s5" title="5. Premium Subscription">
          <p>MangaFlux offers a Premium subscription providing enhanced features including ad-free reading, HD quality images, offline mode, and early chapter access. Premium subscriptions are billed monthly or annually.</p>
          <p>You may cancel your subscription at any time. Cancellation takes effect at the end of the current billing period. Refunds are available within 7 days of initial purchase or renewal if premium-exclusive content has not been accessed.</p>
          <p>We reserve the right to modify premium features or pricing with 30 days' notice to active subscribers.</p>
        </Section>

        <Section id="s6" title="6. Termination">
          <p>We may suspend or terminate your account at our sole discretion, without notice, for conduct that we believe violates these Terms or is harmful to other users, us, third parties, or the public. You may delete your account at any time from your profile settings.</p>
        </Section>

        <Section id="s7" title="7. Disclaimers">
          <p>The Service is provided "as is" without warranties of any kind. We do not guarantee uninterrupted access, data accuracy, or that the Service will meet your specific requirements. To the maximum extent permitted by applicable law, MangaFlux shall not be liable for any indirect, incidental, or consequential damages arising from your use of the Service.</p>
        </Section>

        <Section id="s8" title="8. Contact Us">
          <p>For questions about these Terms, please contact us at:</p>
          <div className="legal-contact">
            <p>legal@mangaflux.com</p>
            <p>mangaflux.com/contact</p>
          </div>
        </Section>
      </div>
    </div>
  );
}

export function Privacy() {
  return (
    <div className="page legal-page">
      <LegalHeader title="Privacy Policy" updated="June 2026" />
      <div className="container legal-body">
        <Section title="Information We Collect">
          <p>We collect information you provide directly (username, email, password on registration), information generated by your use of the Service (reading history, bookmarks, preferences), and technical data (IP address, browser type, device info) via server logs.</p>
        </Section>
        <Section title="How We Use Your Information">
          <ul>
            <li>To provide, maintain, and improve the Service</li>
            <li>To personalize your reading recommendations</li>
            <li>To send service-related notifications (you may opt out)</li>
            <li>To detect and prevent fraud or abuse</li>
            <li>To comply with legal obligations</li>
          </ul>
        </Section>
        <Section title="Data Sharing">
          <p>We do not sell your personal information. We may share data with trusted service providers (hosting, analytics) bound by confidentiality agreements, or disclose data when required by law.</p>
        </Section>
        <Section title="Your Rights">
          <p>You have the right to access, correct, or delete your personal data. Premium subscribers may export their reading data. Contact privacy@mangaflux.com to exercise these rights.</p>
        </Section>
        <Section title="Cookies">
          <p>We use essential cookies for authentication and session management. Non-essential cookies can be disabled in your browser settings, though this may affect Service functionality.</p>
        </Section>
        <Section title="Contact">
          <div className="legal-contact"><p>privacy@mangaflux.com</p></div>
        </Section>
      </div>
    </div>
  );
}

function Section({ id, title, children }) {
  return (
    <section id={id} className="legal-section">
      <h2 className="legal-section__title">{title}</h2>
      <div className="legal-section__body">{children}</div>
    </section>
  );
}
