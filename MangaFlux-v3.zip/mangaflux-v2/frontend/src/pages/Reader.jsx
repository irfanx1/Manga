import { useEffect, useState, useRef, useCallback } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import './Reader.css';

const ChevronLeftIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M12.5 16L6 9.5 12.5 3"/></svg>;
const SettingsIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><circle cx="10" cy="10" r="2.5"/><path d="M10 2v2.5M10 15.5V18M3.5 5.5l1.8 1.8M14.7 12.7l1.8 1.8M2 10h2.5M15.5 10H18M3.5 14.5l1.8-1.8M14.7 7.3l1.8-1.8"/></svg>;
const SunIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"><circle cx="10" cy="10" r="3.5"/><path d="M10 2v2M10 16v2M3.5 3.5l1.5 1.5M15 15l1.5 1.5M2 10h2M16 10h2M3.5 16.5l1.5-1.5M15 5l1.5-1.5"/></svg>;
const ZoomIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"><circle cx="8.5" cy="8.5" r="5.5"/><path d="M13.5 13.5 18 18M7 8.5h3"/></svg>;
const DirectionIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h14M3 10h10M3 14h14"/></svg>;
const XIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M5 5l10 10M15 5 5 15"/></svg>;
const InboxIcon = () => <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M3 12l3-7h12l3 7v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6z"/><path d="M3 12h6l1 2h4l1-2h6"/></svg>;

const DIRECTIONS = [
  { id: 'vertical', label: 'Vertical scroll' },
  { id: 'ltr',       label: 'Page · Left to right' },
  { id: 'rtl',       label: 'Page · Right to left (manga)' },
];

export default function Reader() {
  const { slug, number } = useParams();
  const { user, refreshUser } = useAuth();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [uiVisible, setUiVisible] = useState(true);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(0);
  const [loadedImages, setLoadedImages] = useState({});

  const [direction, setDirection]   = useState(() => localStorage.getItem('mf_direction') || 'vertical');
  const [brightness, setBrightness] = useState(() => Number(localStorage.getItem('mf_brightness')) || 100);
  const [zoom, setZoom]             = useState(() => Number(localStorage.getItem('mf_zoom')) || 100);

  const hideTimer = useRef(null);

  useEffect(() => {
    setLoading(true);
    setCurrentPage(0);
    setLoadedImages({});
    api.get(`/manga/${slug}/chapter/${number}`).then(setData).finally(() => {
      setLoading(false);
      refreshUser(); // pick up streak/xp changes from the backend
    });
    window.scrollTo(0, 0);
  }, [slug, number]);

  const showUI = useCallback(() => {
    setUiVisible(true);
    clearTimeout(hideTimer.current);
    hideTimer.current = setTimeout(() => setUiVisible(false), 3500);
  }, []);

  useEffect(() => { showUI(); return () => clearTimeout(hideTimer.current); }, [showUI]);

  useEffect(() => { localStorage.setItem('mf_direction', direction); }, [direction]);
  useEffect(() => { localStorage.setItem('mf_brightness', brightness); }, [brightness]);
  useEffect(() => { localStorage.setItem('mf_zoom', zoom); }, [zoom]);

  if (loading) return (
    <div className="reader-loading"><div className="spinner spinner-lg" /><p>Loading chapter…</p></div>
  );
  if (!data) return <div className="reader-error">Chapter not found.</div>;

  const { manga, chapter, prev, next } = data;
  const pages = chapter.pages || [];
  const isPaged = direction !== 'vertical';

  const imgStyle = { filter: `brightness(${brightness}%)`, transform: `scale(${zoom / 100})` };

  const goNextPage = () => setCurrentPage(p => Math.min(pages.length - 1, p + 1));
  const goPrevPage = () => setCurrentPage(p => Math.max(0, p - 1));

  return (
    <div className="reader" onClick={showUI} onTouchStart={showUI}>
      <div className={`reader-topbar ${uiVisible ? 'visible' : ''}`}>
        <Link to={`/manga/${slug}`} className="reader-back" onClick={e => e.stopPropagation()} aria-label="Back to details"><ChevronLeftIcon /></Link>
        <div className="reader-info">
          <div className="reader-info__title">{manga.title}</div>
          <div className="reader-info__chapter">Chapter {chapter.number}{chapter.title ? ` · ${chapter.title}` : ''}</div>
        </div>
        <button className="reader-mode-btn" onClick={e => { e.stopPropagation(); setSettingsOpen(s => !s); }} aria-label="Reader settings"><SettingsIcon /></button>
      </div>

      {settingsOpen && (
        <div className="reader-settings" onClick={e => e.stopPropagation()}>
          <div className="reader-settings__head">
            <span>Reader settings</span>
            <button className="btn-icon" onClick={() => setSettingsOpen(false)}><XIcon /></button>
          </div>

          <div className="reader-settings__group">
            <label><DirectionIcon /> Reading direction</label>
            <div className="reader-settings__chips">
              {DIRECTIONS.map(d => (
                <button key={d.id} className={`reader-chip ${direction === d.id ? 'active' : ''}`} onClick={() => setDirection(d.id)}>{d.label}</button>
              ))}
            </div>
          </div>

          <div className="reader-settings__group">
            <label><SunIcon /> Brightness — {brightness}%</label>
            <input type="range" min={40} max={130} value={brightness} onChange={e => setBrightness(Number(e.target.value))} className="reader-slider" />
          </div>

          <div className="reader-settings__group">
            <label><ZoomIcon /> Zoom — {zoom}%</label>
            <input type="range" min={70} max={180} value={zoom} onChange={e => setZoom(Number(e.target.value))} className="reader-slider" />
          </div>
        </div>
      )}

      {!isPaged ? (
        <div className="reader-scroll">
          {pages.length > 0 ? (
            pages.map((p, i) => (
              <div key={i} className="reader-page">
                {!loadedImages[i] && <div className="reader-page__skel skel" />}
                <img
                  src={p.imageUrl} alt={`Page ${p.pageNumber}`} loading="lazy" style={loadedImages[i] ? imgStyle : { opacity: 0, position: 'absolute' }}
                  onLoad={() => setLoadedImages(l => ({ ...l, [i]: true }))}
                />
              </div>
            ))
          ) : (
            <div className="reader-empty"><InboxIcon /><h3>No pages available</h3><p>Pages may still be fetching from the source. Try again shortly.</p></div>
          )}
          {next && (
            <div className="reader-next" onClick={e => e.stopPropagation()}>
              <p className="reader-next__label">End of Chapter {chapter.number}</p>
              <Link to={`/manga/${slug}/chapter/${next.number}`} className="btn btn-primary btn-lg">Next chapter</Link>
            </div>
          )}
        </div>
      ) : (
        <div className="reader-paged">
          {pages[currentPage] ? (
            <img src={pages[currentPage].imageUrl} alt={`Page ${currentPage + 1}`} className="reader-paged__img" style={imgStyle} />
          ) : (
            <div className="reader-empty"><InboxIcon /><p>No pages</p></div>
          )}
          <div className="reader-tap-zones" onClick={e => e.stopPropagation()}>
            <button className="reader-tap reader-tap--left" onClick={direction === 'rtl' ? goNextPage : goPrevPage} aria-label="Previous page" />
            <button className="reader-tap reader-tap--right" onClick={direction === 'rtl' ? goPrevPage : goNextPage} aria-label="Next page" />
          </div>
        </div>
      )}

      <div className={`reader-bottombar ${uiVisible ? 'visible' : ''}`} onClick={e => e.stopPropagation()}>
        <div className="reader-nav-row">
          {prev ? <Link to={`/manga/${slug}/chapter/${prev.number}`} className="btn btn-secondary btn-sm">← Ch. {prev.number}</Link> : <span />}
          {isPaged && pages.length > 0 && (
            <div className="reader-page-counter"><span className="reader-page-counter__current">{currentPage + 1}</span><span className="reader-page-counter__sep">/</span><span className="reader-page-counter__total">{pages.length}</span></div>
          )}
          {next ? <Link to={`/manga/${slug}/chapter/${next.number}`} className="btn btn-secondary btn-sm">Ch. {next.number} →</Link> : <span />}
        </div>
        {isPaged && pages.length > 1 && (
          <input type="range" min={0} max={pages.length - 1} value={currentPage} onChange={e => setCurrentPage(Number(e.target.value))} className="reader-scrubber" />
        )}
      </div>
    </div>
  );
}
