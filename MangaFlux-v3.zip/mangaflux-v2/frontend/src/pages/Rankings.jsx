import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../utils/api';
import './Rankings.css';

const PERIODS = [
  { id: 'today', label: 'Today' },
  { id: 'week',  label: 'This week' },
  { id: 'month', label: 'This month' },
  { id: 'all',   label: 'All time' },
];

const TrophyIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M6 4h8v3a4 4 0 01-8 0V4z"/><path d="M6 5H4a1 1 0 00-1 1v1a3 3 0 003 3M14 5h2a1 1 0 011 1v1a3 3 0 01-3 3M8 14h4M10 11v3M7 17h6"/></svg>;
const EyeIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M1 10S4 4 10 4s9 6 9 6-3 6-9 6-9-6-9-6z"/><circle cx="10" cy="10" r="2.5"/></svg>;
const StarIcon = () => <svg viewBox="0 0 20 20" fill="currentColor"><path d="M10 1l2.39 4.84 5.34.78-3.87 3.77.91 5.33L10 13.27l-4.77 2.45.91-5.33L2.27 6.62l5.34-.78L10 1z"/></svg>;
const CrownIcon = () => <svg viewBox="0 0 20 20" fill="currentColor"><path d="M2 7l3 3 5-5 5 5 3-3-1.5 9h-13L2 7z"/></svg>;

export default function Rankings() {
  const [period, setPeriod] = useState('today');
  const [manga, setManga]   = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    api.get(`/manga/rankings/${period}`).then(d => setManga(d.manga || [])).finally(() => setLoading(false));
  }, [period]);

  const podium = manga.slice(0, 3);
  const rest   = manga.slice(3);

  return (
    <div className="page container rankings-page">
      <div className="rankings-head">
        <span className="rankings-head__icon"><TrophyIcon /></span>
        <div>
          <p className="section-label">Leaderboard</p>
          <h1 className="section-title">Rankings</h1>
        </div>
      </div>

      <div className="rankings-tabs">
        {PERIODS.map(p => (
          <button key={p.id} className={`rankings-tab ${period === p.id ? 'active' : ''}`} onClick={() => setPeriod(p.id)}>{p.label}</button>
        ))}
      </div>

      {loading ? (
        <div className="spinner-page"><div className="spinner spinner-lg" /></div>
      ) : manga.length === 0 ? (
        <div className="empty"><TrophyIcon /><h3>No data yet</h3><p>Check back once more manga has been read in this period.</p></div>
      ) : (
        <>
          {podium.length === 3 && (
            <div className="podium">
              {[podium[1], podium[0], podium[2]].map((m, i) => {
                const rank = [2, 1, 3][i];
                return (
                  <Link key={m._id} to={`/manga/${m.slug}`} className={`podium__item podium__item--${rank}`}>
                    {rank === 1 && <span className="podium__crown"><CrownIcon /></span>}
                    <div className="podium__cover">
                      {m.coverImage ? <img src={m.coverImage} alt={m.title} /> : <div className="podium__placeholder">{m.title[0]}</div>}
                    </div>
                    <span className="podium__rank">#{rank}</span>
                    <span className="podium__title clamp-2">{m.title}</span>
                    <span className="podium__views"><EyeIcon /> {(m.views || 0).toLocaleString()}</span>
                  </Link>
                );
              })}
            </div>
          )}

          <div className="rank-list">
            {rest.map((m, i) => (
              <Link key={m._id} to={`/manga/${m.slug}`} className="rank-item">
                <span className="rank-item__num">{i + 4}</span>
                <div className="rank-item__cover">
                  {m.coverImage ? <img src={m.coverImage} alt="" /> : <div className="rank-item__placeholder">{m.title[0]}</div>}
                </div>
                <div className="rank-item__info">
                  <span className="rank-item__title clamp-1">{m.title}</span>
                  <span className="rank-item__sub">{m.type} · {m.chapterCount || 0} ch</span>
                </div>
                <div className="rank-item__stats">
                  <span><EyeIcon /> {(m.views || 0).toLocaleString()}</span>
                  <span><StarIcon /> {m.rating?.toFixed(1) || 'N/A'}</span>
                </div>
              </Link>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
