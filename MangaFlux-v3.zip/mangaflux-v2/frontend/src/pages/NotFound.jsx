import { Link } from 'react-router-dom';

export default function NotFound() {
  return (
    <div className="page" style={{ minHeight: '70dvh', display: 'flex', alignItems: 'center', justifyContent: 'center', paddingTop: 'var(--nav-h)' }}>
      <div style={{ textAlign: 'center' }}>
        <p style={{ fontFamily: "var(--font-head)", fontSize: 72, fontWeight: 800, color: 'var(--text-3)', letterSpacing: '-0.04em' }}>404</p>
        <h1 style={{ fontSize: 20, fontWeight: 700, marginTop: 8, marginBottom: 8 }}>Page not found</h1>
        <p style={{ fontSize: 14, color: 'var(--text-muted)', marginBottom: 24 }}>The page you're looking for doesn't exist or has moved.</p>
        <Link to="/" className="btn btn-primary">Back to home</Link>
      </div>
    </div>
  );
}
