import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import './Auth.css';

/* ── Icons ── */
const EyeIcon = () => (
  <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round">
    <path d="M1 10S4 4 10 4s9 6 9 6-3 6-9 6-9-6-9-6z"/>
    <circle cx="10" cy="10" r="2.5"/>
  </svg>
);
const EyeOffIcon = () => (
  <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round">
    <path d="M2 2l16 16M6.5 6.6C4.5 7.7 2.8 9.5 1 10c2 2.5 4.7 6 9 6 1.8 0 3.4-.6 4.7-1.5M9 4.1c.3 0 .7-.1 1-.1 5.3 0 8 6 9 6-.6 1-1.6 2.3-2.8 3.3"/>
  </svg>
);
const AlertIcon = () => (
  <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round">
    <circle cx="10" cy="10" r="8"/>
    <path d="M10 6v5M10 14h.01"/>
  </svg>
);
const CheckIcon = () => (
  <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
    <path d="M4 10l4 4 8-8"/>
  </svg>
);

function PasswordStrength({ password }) {
  const score = [
    password.length >= 8,
    /[A-Z]/.test(password),
    /[0-9]/.test(password),
    /[^a-zA-Z0-9]/.test(password),
  ].filter(Boolean).length;

  if (!password) return null;
  const labels = ['Weak', 'Fair', 'Good', 'Strong'];
  const colors = ['#ef4444', '#f59e0b', '#06b6d4', '#4ade80'];

  return (
    <div className="pw-strength">
      <div className="pw-strength__bars">
        {[0,1,2,3].map(i => (
          <div key={i} className="pw-strength__bar" style={{ background: i < score ? colors[score - 1] : 'var(--bg-5)' }} />
        ))}
      </div>
      <span className="pw-strength__label" style={{ color: colors[score - 1] }}>{labels[score - 1]}</span>
    </div>
  );
}

export function Login() {
  const [email, setEmail]       = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [error, setError]       = useState('');
  const [loading, setLoading]   = useState(false);
  const { login } = useAuth();
  const navigate  = useNavigate();
  const location  = useLocation();
  const from = location.state?.from || '/';

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await login(email, password);
      navigate(from, { replace: true });
    } catch (err) {
      setError(typeof err === 'string' ? err : 'Invalid email or password.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-bg" />
      <div className="auth-card fade-up">
        {/* Logo */}
        <Link to="/" className="auth-logo">
          <span className="auth-logo-mark" />
          <span>Manga<b>Flux</b></span>
        </Link>

        <h1 className="auth-title">Welcome back</h1>
        <p className="auth-sub">Sign in to continue your reading journey</p>

        {error && (
          <div className="auth-error" role="alert">
            <AlertIcon />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="auth-form">
          <div className="auth-field">
            <label className="auth-label" htmlFor="email">Email address</label>
            <input
              id="email"
              className="input"
              type="email"
              placeholder="you@example.com"
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
              autoComplete="email"
            />
          </div>

          <div className="auth-field">
            <div className="auth-label-row">
              <label className="auth-label" htmlFor="password">Password</label>
              <a href="#" className="auth-forgot">Forgot password?</a>
            </div>
            <div className="auth-pass-wrap">
              <input
                id="password"
                className="input"
                type={showPass ? 'text' : 'password'}
                placeholder="Enter your password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                required
                autoComplete="current-password"
              />
              <button type="button" className="auth-eye" onClick={() => setShowPass(s => !s)} aria-label="Toggle password">
                {showPass ? <EyeOffIcon /> : <EyeIcon />}
              </button>
            </div>
          </div>

          <button type="submit" className="btn btn-primary btn-lg auth-submit" disabled={loading}>
            {loading ? <span className="spinner" /> : 'Sign in'}
          </button>
        </form>

        <p className="auth-switch">
          Don't have an account? <Link to="/register">Create one</Link>
        </p>
      </div>
    </div>
  );
}

export function Register() {
  const [form, setForm] = useState({ username: '', email: '', password: '' });
  const [showPass, setShowPass] = useState(false);
  const [agreed, setAgreed]     = useState(false);
  const [error, setError]       = useState('');
  const [loading, setLoading]   = useState(false);
  const { register } = useAuth();
  const navigate = useNavigate();

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!agreed) { setError('Please accept the terms to continue.'); return; }
    if (form.password.length < 6) { setError('Password must be at least 6 characters.'); return; }
    setError('');
    setLoading(true);
    try {
      await register(form.username, form.email, form.password);
      navigate('/');
    } catch (err) {
      setError(typeof err === 'string' ? err : 'Registration failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const perks = ['Sync reading progress across devices', 'Build your personal library', 'Get new chapter notifications'];

  return (
    <div className="auth-page auth-page--split">
      <div className="auth-bg" />

      {/* Left panel – desktop only */}
      <div className="auth-panel fade-in">
        <Link to="/" className="auth-logo auth-logo--white">
          <span className="auth-logo-mark" />
          <span>Manga<b>Flux</b></span>
        </Link>
        <h2 className="auth-panel-title">Everything manga,<br />in one place.</h2>
        <p className="auth-panel-sub">Join over 2 million readers discovering new stories every day.</p>
        <ul className="auth-panel-perks">
          {perks.map(p => (
            <li key={p}>
              <span className="auth-panel-check"><CheckIcon /></span>
              <span>{p}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Right card */}
      <div className="auth-card fade-up">
        <Link to="/" className="auth-logo auth-logo--card">
          <span className="auth-logo-mark" />
          <span>Manga<b>Flux</b></span>
        </Link>

        <h1 className="auth-title">Create account</h1>
        <p className="auth-sub">Free forever — no credit card required</p>

        {error && (
          <div className="auth-error" role="alert">
            <AlertIcon />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="auth-form">
          <div className="auth-field">
            <label className="auth-label" htmlFor="username">Username</label>
            <input
              id="username"
              className="input"
              placeholder="yourname"
              value={form.username}
              onChange={e => set('username', e.target.value)}
              required
              minLength={3}
              maxLength={30}
              autoComplete="username"
            />
          </div>

          <div className="auth-field">
            <label className="auth-label" htmlFor="reg-email">Email address</label>
            <input
              id="reg-email"
              className="input"
              type="email"
              placeholder="you@example.com"
              value={form.email}
              onChange={e => set('email', e.target.value)}
              required
              autoComplete="email"
            />
          </div>

          <div className="auth-field">
            <label className="auth-label" htmlFor="reg-password">Password</label>
            <div className="auth-pass-wrap">
              <input
                id="reg-password"
                className="input"
                type={showPass ? 'text' : 'password'}
                placeholder="Min. 6 characters"
                value={form.password}
                onChange={e => set('password', e.target.value)}
                required
                minLength={6}
                autoComplete="new-password"
              />
              <button type="button" className="auth-eye" onClick={() => setShowPass(s => !s)} aria-label="Toggle password">
                {showPass ? <EyeOffIcon /> : <EyeIcon />}
              </button>
            </div>
            <PasswordStrength password={form.password} />
          </div>

          <label className="auth-agree">
            <input
              type="checkbox"
              checked={agreed}
              onChange={e => setAgreed(e.target.checked)}
            />
            <span>
              I agree to the <Link to="/terms" target="_blank">Terms of Service</Link> and{' '}
              <Link to="/privacy" target="_blank">Privacy Policy</Link>
            </span>
          </label>

          <button
            type="submit"
            className="btn btn-primary btn-lg auth-submit"
            disabled={loading || !agreed}
          >
            {loading ? <span className="spinner" /> : 'Create account'}
          </button>
        </form>

        <p className="auth-switch">
          Already have an account? <Link to="/login">Sign in</Link>
        </p>
      </div>
    </div>
  );
}
