import { useEffect, useState, useRef } from 'react';
import { useSearchParams } from 'react-router-dom';
import api from '../utils/api';
import MangaCard, { MangaCardSkeleton } from '../components/manga/MangaCard';
import './Search.css';

const POPULAR = ['Solo Leveling','Attack on Titan','Jujutsu Kaisen','One Piece','Demon Slayer','Chainsaw Man','Tower of God','Naruto','Bleach','Vinland Saga'];

const SearchIcon = () => (
  <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><circle cx="8.5" cy="8.5" r="5.5"/><path d="M13.5 13.5 18 18"/></svg>
);
const XIcon = () => (
  <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M5 5l10 10M15 5 5 15"/></svg>
);
const NoResultsIcon = () => (
  <svg width="42" height="42" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
    <circle cx="10" cy="10" r="6"/><path d="M14.5 14.5L20 20" strokeLinecap="round"/>
  </svg>
);

export default function Search() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [query, setQuery]     = useState(searchParams.get('q') || '');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const inputRef = useRef(null);
  const debounceRef = useRef(null);

  useEffect(() => { inputRef.current?.focus(); }, []);

  useEffect(() => {
    const q = searchParams.get('q');
    if (q) { setQuery(q); doSearch(q); }
  }, [searchParams]);

  const doSearch = async (q) => {
    if (!q?.trim()) return;
    setLoading(true); setSearched(true);
    try {
      const data = await api.get(`/manga?search=${encodeURIComponent(q)}&limit=24`);
      setResults(data.manga || []);
    } finally { setLoading(false); }
  };

  const handleInput = (val) => {
    setQuery(val);
    clearTimeout(debounceRef.current);
    if (val.trim().length >= 2) {
      debounceRef.current = setTimeout(() => { setSearchParams({ q: val }); doSearch(val); }, 400);
    } else { setResults([]); setSearched(false); }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (query.trim()) { setSearchParams({ q: query }); doSearch(query); }
  };

  const clear = () => { setQuery(''); setResults([]); setSearched(false); inputRef.current?.focus(); };

  return (
    <div className="page container search-page">
      <form onSubmit={handleSubmit} className="search-bar">
        <span className="search-bar__icon"><SearchIcon /></span>
        <input
          ref={inputRef}
          className="search-bar__input"
          placeholder="Search by title, author, or genre…"
          value={query}
          onChange={e => handleInput(e.target.value)}
          autoComplete="off"
        />
        {query && (
          <button type="button" className="btn-icon" onClick={clear}><XIcon /></button>
        )}
      </form>

      {!searched && (
        <div className="search-popular">
          <p className="section-label">Popular searches</p>
          <div className="search-chips">
            {POPULAR.map(s => (
              <button key={s} className="search-chip" onClick={() => { setQuery(s); setSearchParams({ q: s }); doSearch(s); }}>
                {s}
              </button>
            ))}
          </div>
        </div>
      )}

      {loading && (
        <div className="search-grid">
          {Array(8).fill(0).map((_, i) => <MangaCardSkeleton key={i} />)}
        </div>
      )}

      {!loading && searched && (
        results.length > 0 ? (
          <>
            <p className="search-result-meta">{results.length} result{results.length !== 1 ? 's' : ''} for "<strong>{query}</strong>"</p>
            <div className="search-grid">
              {results.map(m => <MangaCard key={m._id} manga={m} />)}
            </div>
          </>
        ) : (
          <div className="empty">
            <NoResultsIcon />
            <h3>No results for "{query}"</h3>
            <p>Try a different title, author, or spelling.</p>
          </div>
        )
      )}
    </div>
  );
}
