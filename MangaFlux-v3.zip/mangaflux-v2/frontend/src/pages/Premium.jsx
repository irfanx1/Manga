import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import './Premium.css';

const NoAdsIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6"><circle cx="10" cy="10" r="8"/><path d="M6 6l8 8" strokeLinecap="round"/></svg>;
const ImageIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6"><rect x="2" y="4" width="16" height="12" rx="2"/><circle cx="7" cy="9" r="1.5"/><path d="M2 14l4-4 3 3 5-5 4 4" strokeLinecap="round" strokeLinejoin="round"/></svg>;
const DownloadIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M10 3v10M6 9l4 4 4-4M4 16h12"/></svg>;
const BoltIcon = () => <svg viewBox="0 0 20 20" fill="currentColor"><path d="M11 1L4 11h5l-1 8 7-10H10l1-8z"/></svg>;
const TagIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M9 2H3v6l9 9 6-6-9-9z"/><circle cx="6" cy="5.5" r="1"/></svg>;
const ChatIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M3 4h14v9H8l-4 4v-4H3V4z"/></svg>;
const SparkleIcon = () => <svg viewBox="0 0 20 20" fill="currentColor"><path d="M10 2l1.5 4.5L16 8l-4.5 1.5L10 14l-1.5-4.5L4 8l4.5-1.5L10 2z"/></svg>;

const PERKS = [
  { Icon: NoAdsIcon,    label: 'Ad-free reading',     sub: 'Zero interruptions, pure immersion' },
  { Icon: ImageIcon,    label: 'HD quality images',   sub: 'Crisp, high-resolution chapter pages' },
  { Icon: DownloadIcon, label: 'Offline mode',        sub: 'Download chapters to read anywhere' },
  { Icon: BoltIcon,     label: 'Early access',        sub: 'New chapters before free users' },
  { Icon: TagIcon,      label: '1,000+ exclusives',   sub: 'Premium-only manga and manhwa' },
  { Icon: ChatIcon,     label: 'Community perks',     sub: 'Premium badge, exclusive forums' },
];

const PLANS = [
  { id: 'monthly', label: 'Monthly', price: '$4.99', per: '/month', badge: null },
  { id: 'annual',  label: 'Annual',  price: '$39.99', per: '/year', badge: 'Save 33%', highlight: true },
];

const FAQ = [
  ['Can I cancel anytime?', 'Yes. Cancel at any time from your profile. You keep premium until the end of your billing period.'],
  ['Is there a free trial?', 'New accounts get a 7-day free trial of Premium.'],
  ['What payment methods are supported?', 'We accept all major credit cards, PayPal, and UPI.'],
  ['Are all titles available in Premium?', 'Yes — everything on MangaFlux, plus 1,000+ exclusive titles.'],
];

export default function Premium() {
  const { user } = useAuth();

  return (
    <div className="page container premium-page">
      <div className="premium-hero">
        <div className="premium-hero__glow" />
        <span className="badge badge-gold"><SparkleIcon /> MangaFlux Premium</span>
        <h1 className="premium-hero__title">Read without limits</h1>
        <p className="premium-hero__sub">The best manga reading experience — ad-free, HD, offline, and early access.</p>
      </div>

      <div className="premium-plans">
        {PLANS.map(plan => (
          <div key={plan.id} className={`premium-plan ${plan.highlight ? 'highlight' : ''}`}>
            {plan.badge && <span className="premium-plan__badge">{plan.badge}</span>}
            <div className="premium-plan__label">{plan.label}</div>
            <div className="premium-plan__price">{plan.price}</div>
            <div className="premium-plan__per">{plan.per}</div>
            <Link to={user ? '#' : '/register'} className={`btn ${plan.highlight ? 'btn-primary' : 'btn-secondary'} premium-plan__btn`}>
              {user ? 'Subscribe' : 'Start free trial'}
            </Link>
          </div>
        ))}
      </div>

      <section className="section">
        <p className="section-label">Everything included</p>
        <h2 className="section-title" style={{ marginBottom: 18 }}>What you get</h2>
        <div className="premium-perks">
          {PERKS.map(p => (
            <div key={p.label} className="premium-perk">
              <span className="premium-perk__icon"><p.Icon /></span>
              <div>
                <div className="premium-perk__label">{p.label}</div>
                <div className="premium-perk__sub">{p.sub}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="section premium-faq">
        <p className="section-label">Questions</p>
        <h2 className="section-title" style={{ marginBottom: 18 }}>FAQ</h2>
        {FAQ.map(([q, a]) => (
          <div key={q} className="faq-item">
            <div className="faq-item__q">{q}</div>
            <div className="faq-item__a">{a}</div>
          </div>
        ))}
      </section>

      <p className="premium-footnote">
        By subscribing you agree to our <Link to="/terms">Terms of Service</Link>. Cancel anytime.
      </p>
    </div>
  );
}
