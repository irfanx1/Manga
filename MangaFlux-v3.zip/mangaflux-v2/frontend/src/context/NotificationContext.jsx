import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import api from '../utils/api';
import { useAuth } from './AuthContext';

const NotificationContext = createContext(null);

export function NotificationProvider({ children }) {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount]      = useState(0);

  const load = useCallback(async () => {
    if (!user) { setNotifications([]); setUnreadCount(0); return; }
    try {
      const data = await api.get('/notifications');
      setNotifications(data.notifications || []);
      setUnreadCount(data.unreadCount || 0);
    } catch { /* noop */ }
  }, [user]);

  useEffect(() => {
    load();
    if (!user) return;
    const t = setInterval(load, 60000); // poll every minute
    return () => clearInterval(t);
  }, [load, user]);

  const markRead = async (id) => {
    setNotifications(n => n.map(x => x._id === id ? { ...x, read: true } : x));
    setUnreadCount(c => Math.max(0, c - 1));
    try { await api.patch(`/notifications/${id}/read`); } catch { /* noop */ }
  };

  const markAllRead = async () => {
    setNotifications(n => n.map(x => ({ ...x, read: true })));
    setUnreadCount(0);
    try { await api.patch('/notifications/read-all'); } catch { /* noop */ }
  };

  const clearAll = async () => {
    setNotifications([]);
    setUnreadCount(0);
    try { await api.delete('/notifications'); } catch { /* noop */ }
  };

  return (
    <NotificationContext.Provider value={{ notifications, unreadCount, reload: load, markRead, markAllRead, clearAll }}>
      {children}
    </NotificationContext.Provider>
  );
}

export function useNotifications() {
  const ctx = useContext(NotificationContext);
  if (!ctx) throw new Error('useNotifications must be used within NotificationProvider');
  return ctx;
}
