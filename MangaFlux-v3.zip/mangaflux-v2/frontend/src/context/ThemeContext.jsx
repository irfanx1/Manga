import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import api from '../utils/api';

const ThemeContext = createContext(null);

const RADIUS_PX = { sharp: '4px', soft: '12px', round: '20px' };
const FONT_STACK = {
  jakarta: "'Plus Jakarta Sans', system-ui, sans-serif",
  inter:   "'Inter', system-ui, sans-serif",
  manrope: "'Manrope', system-ui, sans-serif",
  sora:    "'Sora', system-ui, sans-serif",
};

function applyTheme(theme) {
  if (!theme) return;
  const root = document.documentElement.style;
  const c = theme.colors || {};
  root.setProperty('--bg', c.bg);
  root.setProperty('--bg-elevated', c.bgElevated);
  root.setProperty('--surface', c.surface);
  root.setProperty('--border-c', c.border);
  root.setProperty('--text', c.text);
  root.setProperty('--text-muted', c.textMuted);
  root.setProperty('--accent', c.accent);
  root.setProperty('--accent-hi', c.accentHi);
  root.setProperty('--accent-2', c.accent2);
  root.setProperty('--success', c.success);
  root.setProperty('--warning', c.warning);
  root.setProperty('--danger', c.danger);
  root.setProperty('--radius-mode', RADIUS_PX[theme.radius] || '12px');
  document.body.style.fontFamily = FONT_STACK[theme.font] || FONT_STACK.jakarta;
}

export function ThemeProvider({ children }) {
  const [theme, setTheme]     = useState(null);
  const [loading, setLoading] = useState(true);

  const loadTheme = useCallback(async () => {
    try {
      const data = await api.get('/theme/active');
      setTheme(data.theme);
      applyTheme(data.theme);
    } catch {
      // Fall back to whatever defaults are baked into index.css
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadTheme(); }, [loadTheme]);

  // Used by the admin editor to live-preview changes before saving
  const previewTheme = useCallback((draftTheme) => applyTheme(draftTheme), []);
  const resetToActive = useCallback(() => applyTheme(theme), [theme]);

  return (
    <ThemeContext.Provider value={{ theme, loading, reloadTheme: loadTheme, previewTheme, resetToActive }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useTheme must be used within ThemeProvider');
  return ctx;
}
