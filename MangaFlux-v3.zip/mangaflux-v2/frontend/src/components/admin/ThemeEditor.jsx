import { useEffect, useState } from 'react';
import api from '../../utils/api';
import { useTheme } from '../../context/ThemeContext';
import { useToast } from '../../context/ToastContext';

const CheckIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 10l4 4 8-8"/></svg>;
const TrashIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M4 6h12M8 6V4h4v2M6 6l1 10h6l1-10"/></svg>;
const PlusIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M10 4v12M4 10h12"/></svg>;

const COLOR_FIELDS = [
  { key: 'bg',         label: 'Background' },
  { key: 'bgElevated', label: 'Elevated surface' },
  { key: 'surface',    label: 'Surface' },
  { key: 'border',     label: 'Border' },
  { key: 'text',       label: 'Text' },
  { key: 'textMuted',  label: 'Muted text' },
  { key: 'accent',     label: 'Accent' },
  { key: 'accentHi',   label: 'Accent (highlight)' },
  { key: 'accent2',    label: 'Secondary accent' },
  { key: 'success',    label: 'Success' },
  { key: 'warning',    label: 'Warning' },
  { key: 'danger',     label: 'Danger' },
];

const RADII = [
  { id: 'sharp', label: 'Sharp' },
  { id: 'soft',  label: 'Soft' },
  { id: 'round', label: 'Round' },
];

const FONTS = [
  { id: 'jakarta', label: 'Plus Jakarta Sans' },
  { id: 'inter',   label: 'Inter' },
  { id: 'manrope', label: 'Manrope' },
  { id: 'sora',    label: 'Sora' },
];

export default function ThemeEditor() {
  const { theme: activeTheme, reloadTheme, previewTheme, resetToActive } = useTheme();
  const showToast = useToast();
  const [themes, setThemes] = useState([]);
  const [editing, setEditing] = useState(null); // draft theme being edited/previewed
  const [isNew, setIsNew] = useState(false);
  const [newName, setNewName] = useState('My theme');
  const [saving, setSaving] = useState(false);

  const loadThemes = () => api.get('/theme').then(d => setThemes(d.themes || []));
  useEffect(() => { loadThemes(); }, []);

  const startEdit = (theme, asNew = false) => {
    const draft = JSON.parse(JSON.stringify(theme));
    if (asNew) { draft._id = undefined; draft.name = `${theme.name} copy`; draft.isPreset = false; }
    setEditing(draft);
    setIsNew(asNew || !theme._id);
    previewTheme(draft);
  };

  const updateColor = (key, value) => {
    const draft = { ...editing, colors: { ...editing.colors, [key]: value } };
    setEditing(draft);
    previewTheme(draft);
  };

  const updateField = (field, value) => {
    const draft = { ...editing, [field]: value };
    setEditing(draft);
    previewTheme(draft);
  };

  const cancelEdit = () => { setEditing(null); resetToActive(); };

  const activate = async (id) => {
    try {
      await api.post(`/theme/${id}/activate`);
      await reloadTheme();
      await loadThemes();
      showToast('Theme applied site-wide', 'success');
      setEditing(null);
    } catch (err) { showToast(err.message || 'Failed to activate theme', 'error'); }
  };

  const saveDraft = async () => {
    setSaving(true);
    try {
      if (editing._id) {
        const res = await api.patch(`/theme/${editing._id}`, editing);
        showToast('Theme updated', 'success');
        if (res.theme.isActive) { await reloadTheme(); }
      } else {
        const res = await api.post('/theme', { ...editing, name: editing.name || newName });
        showToast('Custom theme created', 'success');
        setEditing(res.theme);
      }
      await loadThemes();
    } catch (err) { showToast(err.message || 'Failed to save theme', 'error'); }
    finally { setSaving(false); }
  };

  const deleteTheme = async (id) => {
    try {
      await api.delete(`/theme/${id}`);
      showToast('Theme deleted', 'success');
      await loadThemes();
    } catch (err) { showToast(err.message || 'Failed to delete theme', 'error'); }
  };

  return (
    <div className="theme-editor">
      {!editing ? (
        <>
          <div className="theme-grid">
            {themes.map(t => (
              <div key={t._id} className={`theme-swatch ${t.isActive ? 'active' : ''}`}>
                <button className="theme-swatch__preview" onClick={() => startEdit(t)} style={{ background: t.colors.bg }}>
                  <span style={{ background: t.colors.accent }} />
                  <span style={{ background: t.colors.accent2 }} />
                  <span style={{ background: t.colors.surface, border: `1px solid ${t.colors.border}` }} />
                  {t.isActive && <span className="theme-swatch__check"><CheckIcon /></span>}
                </button>
                <div className="theme-swatch__row">
                  <span className="theme-swatch__name">{t.name}</span>
                  {t.isPreset && <span className="badge badge-neutral">preset</span>}
                </div>
                <div className="theme-swatch__actions">
                  {!t.isActive && <button className="btn btn-secondary btn-sm" onClick={() => activate(t._id)}>Activate</button>}
                  <button className="btn-icon" onClick={() => startEdit(t, true)} data-tip="Duplicate & edit"><PlusIcon /></button>
                  {!t.isPreset && !t.isActive && (
                    <button className="btn-icon" onClick={() => deleteTheme(t._id)} data-tip="Delete" style={{ color: '#f87171' }}><TrashIcon /></button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </>
      ) : (
        <div className="theme-draft">
          <div className="theme-draft__head">
            <input
              className="input theme-draft__name"
              value={editing.name || ''}
              onChange={e => updateField('name', e.target.value)}
              placeholder="Theme name"
            />
            <div className="theme-draft__head-actions">
              <button className="btn btn-ghost btn-sm" onClick={cancelEdit}>Cancel</button>
              <button className="btn btn-secondary btn-sm" onClick={saveDraft} disabled={saving}>{saving ? <span className="spinner" /> : 'Save'}</button>
              {editing._id && !editing.isActive && (
                <button className="btn btn-primary btn-sm" onClick={() => activate(editing._id)}>Save & activate</button>
              )}
            </div>
          </div>

          <p className="theme-draft__hint">Changes preview live across the whole site right now — only visible to you until you save and activate.</p>

          <div className="theme-draft__section">
            <span className="theme-draft__label">Colors</span>
            <div className="color-grid">
              {COLOR_FIELDS.map(f => (
                <label key={f.key} className="color-field">
                  <input type="color" value={toHex(editing.colors[f.key])} onChange={e => updateColor(f.key, e.target.value)} />
                  <span>{f.label}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="theme-draft__section">
            <span className="theme-draft__label">Corner radius</span>
            <div className="theme-draft__chips">
              {RADII.map(r => <button key={r.id} className={`theme-chip ${editing.radius === r.id ? 'active' : ''}`} onClick={() => updateField('radius', r.id)}>{r.label}</button>)}
            </div>
          </div>

          <div className="theme-draft__section">
            <span className="theme-draft__label">Font</span>
            <div className="theme-draft__chips">
              {FONTS.map(f => <button key={f.id} className={`theme-chip ${editing.font === f.id ? 'active' : ''}`} onClick={() => updateField('font', f.id)}>{f.label}</button>)}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// <input type="color"> requires hex; convert rgba()/named colors defensively
function toHex(color) {
  if (!color) return '#000000';
  if (color.startsWith('#')) return color.length === 7 ? color : '#000000';
  // best-effort fallback for rgba()/named strings the color picker can't read
  const ctx = document.createElement('canvas').getContext('2d');
  ctx.fillStyle = color;
  return ctx.fillStyle.startsWith('#') ? ctx.fillStyle : '#000000';
}
