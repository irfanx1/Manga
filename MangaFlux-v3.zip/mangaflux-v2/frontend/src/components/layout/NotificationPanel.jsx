import { Link } from 'react-router-dom';
import { useNotifications } from '../../context/NotificationContext';

const ChapterIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M4 3h9a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z"/><path d="M7 7h4M7 10h4"/></svg>;
const BellOffIcon = () => <svg width="32" height="32" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M5 8a5 5 0 0110 0c0 2.5 1 4 1.5 5H3.5C4 12 5 10.5 5 8z"/><path d="M8 16a2 2 0 004 0"/></svg>;

function timeAgo(date) {
  const s = (Date.now() - new Date(date)) / 1000;
  if (s < 60) return 'now';
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}

export default function NotificationPanel({ onClose }) {
  const { notifications, unreadCount, markRead, markAllRead, clearAll } = useNotifications();

  return (
    <div className="notif-panel scale-in">
      <div className="notif-panel__head">
        <span>Notifications</span>
        {unreadCount > 0 && <button className="notif-panel__action" onClick={markAllRead}>Mark all read</button>}
      </div>
      <div className="notif-panel__list">
        {notifications.length === 0 ? (
          <div className="notif-panel__empty">
            <BellOffIcon />
            <p>You're all caught up</p>
          </div>
        ) : (
          notifications.map(n => (
            <Link
              key={n._id}
              to={n.manga ? `/manga/${n.manga.slug}` : '#'}
              className={`notif-item ${!n.read ? 'unread' : ''}`}
              onClick={() => { if (!n.read) markRead(n._id); onClose(); }}
            >
              <span className="notif-item__icon"><ChapterIcon /></span>
              <div className="notif-item__body">
                <p>{n.message}</p>
                <span>{timeAgo(n.createdAt)}</span>
              </div>
              {!n.read && <span className="notif-item__dot" />}
            </Link>
          ))
        )}
      </div>
      {notifications.length > 0 && (
        <button className="notif-panel__clear" onClick={clearAll}>Clear all</button>
      )}
    </div>
  );
}
