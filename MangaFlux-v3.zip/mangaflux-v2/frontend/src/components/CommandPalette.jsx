import { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../utils/api';

const SearchIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"><circle cx="8.5" cy="8.5" r="5.5"/><path d="M13.5 13.5 18 18"/></svg>;

export default function CommandPalette({ onClose }) {
  const [query, setQuery]     = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [active, setActive]   = useState(0);
  const inputRef = useRef(null);
  const debounceRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => { inputRef.current?.focus(); }, []);

  const search = useCallback((q) => {
    clearTimeout(debounceRef.current);
    if (!q.trim()) { setResults([]); return; }
    setLoading(true);
    debounceRef.current = setTimeout(async () => {
      try {
        const data = await api.get(`/manga?search=${encodeURIComponent(q)}&limit=8`);
        setResults(data.manga || []);
        setActive(0);
      } finally { setLoading(false); }
    }, 250);
  }, []);

  useEffect(() => { search(query); }, [query, search]);

  const goTo = (manga) => { navigate(`/manga/${manga.slug}`); onClose(); };

  const onKeyDown = (e) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setActive(a => Math.min(a + 1, results.length - 1)); }
    if (e.key === 'ArrowUp')   { e.preventDefault(); setActive(a => Math.max(a - 1, 0)); }
    if (e.key === 'Enter' && results[active]) { e.preventDefault(); goTo(results[active]); }
    if (e.key === 'Escape') onClose();
  };

  return (
    <div className="cmdk-overlay" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="cmdk" onKeyDown={onKeyDown}>
        <div className="cmdk__input-row">
          <SearchIcon />
          <input
            ref={inputRef}
            className="cmdk__input"
            placeholder="Search manga, manhwa, manhua…"
            value={query}
            onChange={e => setQuery(e.target.value)}
          />
          <span className="cmdk__kbd">ESC</span>
        </div>
        <div className="cmdk__list">
          {loading ? (
            <div className="cmdk__empty">Searching…</div>
          ) : results.length === 0 ? (
            query ? <div className="cmdk__empty">No matches for "{query}"</div>
                  : <div className="cmdk__empty">Type to search the catalog</div>
          ) : (
            results.map((m, i) => (
              <div
                key={m._id}
                className={`cmdk__item ${i === active ? 'active' : ''}`}
                onMouseEnter={() => setActive(i)}
                onClick={() => goTo(m)}
              >
                <img src={m.coverImage} alt="" />
                <div>
                  <div className="cmdk__item-title">{m.title}</div>
                  <div className="cmdk__item-sub">{m.type} · {m.chapterCount || 0} chapters</div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
