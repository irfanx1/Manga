import { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import api from '../../utils/api';

const HeartIcon = ({ filled }) => <svg viewBox="0 0 20 20" fill={filled ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="1.7"><path d="M10 17.3S3 13 3 7.8C3 5.2 5 3.3 7.4 3.3c1.4 0 2.6.7 3.4 1.8.8-1.1 2-1.8 3.4-1.8 2.4 0 4.4 1.9 4.4 4.5 0 5.2-7 9.5-7 9.5z"/></svg>;
const TrashIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M4 6h12M8 6V4h4v2M6 6l1 10h6l1-10"/></svg>;
const ChatIcon = () => <svg width="32" height="32" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M3 4h14v9H8l-4 4v-4H3V4z"/></svg>;

function timeAgo(date) {
  const s = (Date.now() - new Date(date)) / 1000;
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  if (s < 2592000) return `${Math.floor(s / 86400)}d ago`;
  return new Date(date).toLocaleDateString();
}

export default function CommentSection({ mangaId, chapterId = null }) {
  const { user } = useAuth();
  const showToast = useToast();
  const [comments, setComments] = useState([]);
  const [body, setBody]         = useState('');
  const [loading, setLoading]   = useState(true);
  const [posting, setPosting]   = useState(false);

  const load = () => {
    const q = chapterId ? `?chapter=${chapterId}` : '';
    api.get(`/comments/manga/${mangaId}${q}`).then(d => setComments(d.comments || [])).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, [mangaId, chapterId]);

  const submit = async (e) => {
    e.preventDefault();
    if (!user) { showToast('Sign in to leave a comment.', 'info'); return; }
    if (!body.trim()) return;
    setPosting(true);
    try {
      const res = await api.post(`/comments/manga/${mangaId}`, { body, chapter: chapterId });
      setComments(c => [{ ...res.comment, likeCount: 0, likedByMe: false }, ...c]);
      setBody('');
    } catch (err) { showToast(err.message || 'Failed to post comment', 'error'); }
    finally { setPosting(false); }
  };

  const toggleLike = async (id) => {
    setComments(cs => cs.map(c => c._id === id ? { ...c, likedByMe: !c.likedByMe, likeCount: c.likeCount + (c.likedByMe ? -1 : 1) } : c));
    try { await api.post(`/comments/${id}/like`); } catch { /* revert silently not critical */ }
  };

  const remove = async (id) => {
    try {
      await api.delete(`/comments/${id}`);
      setComments(cs => cs.filter(c => c._id !== id));
      showToast('Comment deleted', 'success');
    } catch (err) { showToast(err.message || 'Failed to delete', 'error'); }
  };

  return (
    <div className="comments">
      <form className="comments__form" onSubmit={submit}>
        <div className="comments__avatar">{user ? (user.avatar ? <img src={user.avatar} alt="" /> : user.username[0].toUpperCase()) : '?'}</div>
        <div className="comments__input-wrap">
          <textarea
            className="input comments__input"
            placeholder={user ? 'Share your thoughts…' : 'Sign in to comment'}
            value={body}
            onChange={e => setBody(e.target.value)}
            disabled={!user}
            rows={2}
            maxLength={1000}
          />
          <div className="comments__form-row">
            <span className="comments__count">{body.length}/1000</span>
            <button type="submit" className="btn btn-primary btn-sm" disabled={!user || posting || !body.trim()}>
              {posting ? <span className="spinner" /> : 'Post'}
            </button>
          </div>
        </div>
      </form>

      {loading ? (
        <div className="spinner-page" style={{ minHeight: 120 }}><div className="spinner" /></div>
      ) : comments.length === 0 ? (
        <div className="empty"><ChatIcon /><h3>No comments yet</h3><p>Be the first to share your thoughts.</p></div>
      ) : (
        <div className="comments__list">
          {comments.map(c => (
            <div key={c._id} className="comment-item">
              <div className="comment-item__avatar">{c.user?.avatar ? <img src={c.user.avatar} alt="" /> : c.user?.username?.[0]?.toUpperCase()}</div>
              <div className="comment-item__body">
                <div className="comment-item__head">
                  <span className="comment-item__name">{c.user?.username || 'Deleted user'}</span>
                  {c.user?.role !== 'user' && <span className={`badge admin-role-badge admin-role-badge--${c.user?.role}`}>{c.user?.role}</span>}
                  {c.user?.isPremium && <span className="badge badge-gold">Premium</span>}
                  <span className="comment-item__time">{timeAgo(c.createdAt)}{c.isEdited ? ' · edited' : ''}</span>
                </div>
                <p className="comment-item__text">{c.body}</p>
                <div className="comment-item__actions">
                  <button className={`comment-item__like ${c.likedByMe ? 'active' : ''}`} onClick={() => toggleLike(c._id)}>
                    <HeartIcon filled={c.likedByMe} /> {c.likeCount > 0 && c.likeCount}
                  </button>
                  {user && (user._id === c.user?._id || ['admin', 'owner'].includes(user.role)) && (
                    <button className="comment-item__delete" onClick={() => remove(c._id)}><TrashIcon /></button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
