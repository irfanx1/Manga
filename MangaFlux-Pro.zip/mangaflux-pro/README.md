# MangaFlux — Pro Edition

A complete redesign and hardening pass of the MangaFlux manga reading platform.

## What changed

### Design — fully rebuilt, professional UI
- Removed all emoji icons from the navbar, bottom nav, buttons, and every page — replaced with a consistent custom SVG icon set
- New dark theme with a proper design system (CSS variables for color, spacing, radius, shadows)
- New typeface pairing (Inter + Syne) for a distinct, non-generic feel
- Rebuilt navbar: clean logo mark, minimal links, dropdown account menu, dedicated full-screen search modal (was an emoji-laden inline bar)
- Rebuilt bottom mobile nav with animated active-state indicators
- Rebuilt every page: Home (hero carousel, scroll rows, genre marquee), Explore (filter panel), Search, Manga Detail (tabs, sticky header), Reader (scroll + paged modes, auto-hiding UI), Auth (split-panel register, password strength meter), Profile, Library, History, Admin panel, Premium, Terms/Privacy
- Consistent toast notification system replacing ad-hoc alerts
- Skeleton loading states throughout instead of spinners-only

### Login / auth system — fixed
- **Root cause of "login not working":** the server would crash auth requests with an opaque 500 whenever `JWT_SECRET` was missing or left as the example placeholder, because `jwt.sign()` throws synchronously on an undefined secret. The server now validates this on boot and **refuses to start** with a clear terminal message instead of failing silently at request time.
- Login is now case-insensitive on email (previously a mismatch in casing between registration and login could cause "invalid credentials" on a valid account)
- Generic, non-enumerable error messages ("Invalid email or password") instead of leaking whether the email or password was wrong
- Frontend now auto-clears an expired/invalid token on any 401 instead of looping on a dead session
- Banned-user check added at both login and per-request auth-middleware level
- Clearer expired-vs-invalid token messaging from the API

### Scraper — fixed and hardened
- **Root cause of bad/missing scrape results:** axios's default query serializer does not produce the bracket-style params MangaDex's API requires (`order[followedCount]=desc`, `includes[]=...`). Requests were succeeding but silently returning unsorted/unfiltered data. A correct custom param serializer is now used.
- Retries now also cover timeouts and 503s, not just 429 rate-limits
- Duplicate-chapter race conditions (two scrapes overlapping) are now caught and skipped instead of crashing the run
- Slug generation no longer collapses to an empty string for manhwa/manhua titles with non-Latin scripts (was causing duplicate-key crashes) — it now falls back to the source ID and guarantees uniqueness
- Scraper status (admin panel) now reports last result details, not just a running flag

### General hardening
- Input validation on registration (username length, email format, password length)
- Rate limiting tightened specifically on `/api/auth/login` to slow credential stuffing
- All routes wrapped with consistent error messages instead of raw `err.message` leaking internals in some places
- 404 handler added for unmatched API routes

## Setup

### Backend
```bash
cd backend
npm install
cp .env.example .env
# Edit .env — set JWT_SECRET (required) and ADMIN_PASSWORD
npm run dev
```

Generate a secret:
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

### Frontend
```bash
cd frontend
npm install
npm start
```

The app runs on `http://localhost:3000` and proxies API calls to `http://localhost:5000`.

### First login
On first boot, a default **owner** account is created using `ADMIN_EMAIL` / `ADMIN_PASSWORD` from `.env` (defaults to `admin@mangaflux.com` / `admin123` if unset — change this immediately after first login).

### Populating manga
Go to **Admin Panel → Scraper → Run now** to pull the first batch from MangaDex. This takes 1–3 minutes. The scraper also runs automatically 8 seconds after every server boot and every 6 hours after that (toggle in the admin panel).
