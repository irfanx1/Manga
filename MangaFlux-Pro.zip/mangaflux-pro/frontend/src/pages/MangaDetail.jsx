import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import './MangaDetail.css';

const PlayIcon = () => <svg viewBox="0 0 20 20" fill="currentColor"><path d="M5 3.5v13l11-6.5-11-6.5z"/></svg>;
const SkipIcon = () => (
  <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 4l8 6-8 6V4zM15 4v12"/>
  </svg>
);
const HeartIcon = ({ filled }) => (
  <svg viewBox="0 0 20 20" fill={filled ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round">
    <path d="M10 17.3S3 13 3 7.8C3 5.2 5 3.3 7.4 3.3c1.4 0 2.6.7 3.4 1.8.8-1.1 2-1.8 3.4-1.8 2.4 0 4.4 1.9 4.4 4.5 0 5.2-7 9.5-7 9.5z"/>
  </svg>
);
const StarIcon = () => <svg viewBox="0 0 20 20" fill="currentColor"><path d="M10 1l2.39 4.84 5.34.78-3.87 3.77.91 5.33L10 13.27l-4.77 2.45.91-5.33L2.27 6.62l5.34-.78L10 1z"/></svg>;
const EyeIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7"><path d="M1 10S4 4 10 4s9 6 9 6-3 6-9 6-9-6-9-6z"/><circle cx="10" cy="10" r="2.5"/></svg>;
const BookIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M4 3h9a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z"/><path d="M7 7h4M7 10h4"/></svg>;
const ExternalIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M8 4H4v12h12v-4M11 3h6v6M16 4l-7 7"/></svg>;
const ChevronIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M7.5 5l5 5-5 5"/></svg>;
const InboxIcon = () => <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M3 12l3-7h12l3 7v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6z"/><path d="M3 12h6l1 2h4l1-2h6"/></svg>;

export default function MangaDetail() {
  const { slug } = useParams();
  const { user } = useAuth();
  const showToast = useToast();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [bookmarked, setBookmarked] = useState(false);
  const [showAll, setShowAll] = useState(false);
  const [activeTab, setActiveTab] = useState('chapters');

  useEffect(() => {
    setLoading(true);
    api.get(`/manga/${slug}`).then(d => {
      setData(d);
      if (user) setBookmarked(user.bookmarks?.includes(d.manga._id));
    }).finally(() => setLoading(false));
  }, [slug]);

  const toggleBookmark = async () => {
    if (!user) { showToast('Sign in to save manga to your library.', 'info'); return; }
    try {
      const res = await api.post(`/auth/bookmark/${data.manga._id}`);
      setBookmarked(res.bookmarked);
      showToast(res.bookmarked ? 'Added to library' : 'Removed from library', 'success');
    } catch {
      showToast('Something went wrong. Please try again.', 'error');
    }
  };

  if (loading) return (
    <div className="page detail-page">
      <div className="detail-banner skel" style={{ height: 220, borderRadius: 0 }} />
      <div className="container detail-header">
        <div className="detail-cover skel" style={{ width: 110, height: 158 }} />
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 10 }}>
          <div className="skel" style={{ height: 28, width: '80%', borderRadius: 6 }} />
          <div className="skel" style={{ height: 14, width: '50%', borderRadius: 4 }} />
          <div className="skel" style={{ height: 14, width: '60%', borderRadius: 4 }} />
        </div>
      </div>
    </div>
  );

  if (!data) return (
    <div className="page" style={{ paddingTop: 120, textAlign: 'center' }}>
      <p style={{ color: 'var(--text-2)' }}>Manga not found.</p>
    </div>
  );

  const { manga, chapters } = data;
  const displayChapters = showAll ? chapters : chapters.slice(0, 25);
  const firstCh = chapters[chapters.length - 1];
  const latestCh = chapters[0];

  return (
    <div className="page detail-page">
      <div className="detail-banner" style={(manga.bannerImage || manga.coverImage) ? { backgroundImage: `url(${manga.bannerImage || manga.coverImage})` } : {}}>
        <div className="detail-banner__overlay" />
      </div>

      <div className="container">
        <div className="detail-header">
          <div className="detail-cover">
            {manga.coverImage
              ? <img src={manga.coverImage} alt={manga.title} />
              : <div className="detail-cover__placeholder">{manga.title[0]}</div>
            }
          </div>
          <div className="detail-meta">
            <div className="detail-tags">
              <span className="badge badge-accent">{manga.type}</span>
              <span className={`status status-${manga.status}`}>{manga.status}</span>
            </div>
            <h1 className="detail-title">{manga.title}</h1>
            {manga.authors?.length > 0 && <p className="detail-author">by {manga.authors.join(', ')}</p>}
            <div className="detail-stats">
              <span className="detail-stat"><StarIcon /> {manga.rating > 0 ? manga.rating.toFixed(1) : 'N/A'}</span>
              <span className="detail-stat"><EyeIcon /> {(manga.views || 0).toLocaleString()}</span>
              <span className="detail-stat"><BookIcon /> {manga.chapterCount || 0} ch</span>
            </div>
            <div className="detail-actions">
              {firstCh && (
                <Link to={`/manga/${slug}/chapter/${firstCh.number}`} className="btn btn-primary">
                  <PlayIcon /> Start reading
                </Link>
              )}
              {latestCh && latestCh !== firstCh && (
                <Link to={`/manga/${slug}/chapter/${latestCh.number}`} className="btn btn-secondary">
                  <SkipIcon /> Latest
                </Link>
              )}
              <button className={`btn-icon detail-bookmark ${bookmarked ? 'active' : ''}`} onClick={toggleBookmark} aria-label="Bookmark">
                <HeartIcon filled={bookmarked} />
              </button>
            </div>
          </div>
        </div>

        {manga.genres?.length > 0 && (
          <div className="detail-genres">
            {manga.genres.map(g => <Link key={g} to={`/explore?genre=${g}`} className="genre-pill">{g}</Link>)}
          </div>
        )}

        <div className="detail-tabs">
          {['chapters', 'about'].map(t => (
            <button key={t} className={`detail-tab ${activeTab === t ? 'active' : ''}`} onClick={() => setActiveTab(t)}>
              {t === 'chapters' ? `Chapters (${chapters.length})` : 'About'}
            </button>
          ))}
        </div>

        {activeTab === 'about' ? (
          <div className="detail-about">
            {manga.description && <p className="detail-desc">{manga.description}</p>}
            <div className="detail-info-grid">
              {[
                ['Type', manga.type],
                ['Status', manga.status],
                ['Source', manga.source || 'Manual'],
                ['Updated', manga.lastUpdated ? new Date(manga.lastUpdated).toLocaleDateString() : '—'],
              ].map(([k, v]) => (
                <div key={k} className="detail-info-item">
                  <span className="detail-info-item__label">{k}</span>
                  <span className="detail-info-item__value">{v}</span>
                </div>
              ))}
            </div>
            {manga.sourceUrl && (
              <a href={manga.sourceUrl} target="_blank" rel="noopener noreferrer" className="btn btn-secondary btn-sm" style={{ marginTop: 18 }}>
                <ExternalIcon /> View source
              </a>
            )}
          </div>
        ) : (
          <div className="chapter-wrap">
            <div className="chapter-list">
              {displayChapters.map(ch => (
                <Link key={ch._id} to={`/manga/${slug}/chapter/${ch.number}`} className="chapter-item">
                  <div className="chapter-item__left">
                    <span className="chapter-item__num">Chapter {ch.number}</span>
                    {ch.title && <span className="chapter-item__title">{ch.title}</span>}
                  </div>
                  <div className="chapter-item__right">
                    <span className="chapter-item__date">{new Date(ch.uploadedAt || ch.createdAt).toLocaleDateString()}</span>
                    <ChevronIcon />
                  </div>
                </Link>
              ))}
            </div>
            {chapters.length > 25 && (
              <button className="btn btn-secondary" style={{ width: '100%', marginTop: 14 }} onClick={() => setShowAll(!showAll)}>
                {showAll ? 'Show less' : `Show all ${chapters.length} chapters`}
              </button>
            )}
            {chapters.length === 0 && (
              <div className="empty">
                <InboxIcon />
                <h3>No chapters yet</h3>
                <p>Check back soon — new chapters are added regularly.</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
