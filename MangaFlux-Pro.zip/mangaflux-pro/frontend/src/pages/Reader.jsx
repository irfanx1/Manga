import { useEffect, useState, useRef, useCallback } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../utils/api';
import './Reader.css';

const ChevronLeftIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M12.5 16L6 9.5 12.5 3"/></svg>;
const ScrollModeIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="2" width="12" height="16" rx="1.5"/><path d="M7 6h6M7 9.5h6M7 13h3"/></svg>;
const PageModeIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="4" width="7" height="12" rx="1"/><rect x="11" y="4" width="7" height="12" rx="1"/></svg>;
const InboxIcon = () => <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M3 12l3-7h12l3 7v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6z"/><path d="M3 12h6l1 2h4l1-2h6"/></svg>;

export default function Reader() {
  const { slug, number } = useParams();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [uiVisible, setUiVisible] = useState(true);
  const [mode, setMode] = useState(() => localStorage.getItem('mf_reader_mode') || 'scroll');
  const [currentPage, setCurrentPage] = useState(0);
  const [loadedImages, setLoadedImages] = useState({});
  const hideTimer = useRef(null);
  const containerRef = useRef(null);

  useEffect(() => {
    setLoading(true);
    setCurrentPage(0);
    setLoadedImages({});
    api.get(`/manga/${slug}/chapter/${number}`).then(setData).finally(() => setLoading(false));
    window.scrollTo(0, 0);
  }, [slug, number]);

  const showUI = useCallback(() => {
    setUiVisible(true);
    clearTimeout(hideTimer.current);
    hideTimer.current = setTimeout(() => setUiVisible(false), 3500);
  }, []);

  useEffect(() => {
    showUI();
    return () => clearTimeout(hideTimer.current);
  }, [showUI]);

  const toggleMode = () => {
    const next = mode === 'scroll' ? 'page' : 'scroll';
    setMode(next);
    localStorage.setItem('mf_reader_mode', next);
  };

  if (loading) return (
    <div className="reader-loading">
      <div className="spinner spinner-lg" />
      <p>Loading chapter…</p>
    </div>
  );
  if (!data) return <div className="reader-error">Chapter not found.</div>;

  const { manga, chapter, prev, next } = data;
  const pages = chapter.pages || [];

  return (
    <div className="reader" onClick={showUI} onTouchStart={showUI}>
      <div className={`reader-topbar ${uiVisible ? 'visible' : ''}`}>
        <Link to={`/manga/${slug}`} className="reader-back" onClick={e => e.stopPropagation()} aria-label="Back to details">
          <ChevronLeftIcon />
        </Link>
        <div className="reader-info">
          <div className="reader-info__title">{manga.title}</div>
          <div className="reader-info__chapter">Chapter {chapter.number}{chapter.title ? ` · ${chapter.title}` : ''}</div>
        </div>
        <button className="reader-mode-btn" onClick={e => { e.stopPropagation(); toggleMode(); }} title="Toggle reading mode" data-tip={mode === 'scroll' ? 'Switch to page mode' : 'Switch to scroll mode'}>
          {mode === 'scroll' ? <PageModeIcon /> : <ScrollModeIcon />}
        </button>
      </div>

      {mode === 'scroll' ? (
        <div className="reader-scroll" ref={containerRef}>
          {pages.length > 0 ? (
            pages.map((p, i) => (
              <div key={i} className="reader-page">
                {!loadedImages[i] && <div className="reader-page__skel skel" />}
                <img
                  src={p.imageUrl}
                  alt={`Page ${p.pageNumber}`}
                  loading="lazy"
                  onLoad={() => setLoadedImages(l => ({ ...l, [i]: true }))}
                  style={loadedImages[i] ? {} : { opacity: 0, position: 'absolute' }}
                />
              </div>
            ))
          ) : (
            <div className="reader-empty">
              <InboxIcon />
              <h3>No pages available</h3>
              <p>Pages may still be fetching from the source. Try again shortly.</p>
            </div>
          )}
          {next && (
            <div className="reader-next" onClick={e => e.stopPropagation()}>
              <p className="reader-next__label">End of Chapter {chapter.number}</p>
              <Link to={`/manga/${slug}/chapter/${next.number}`} className="btn btn-primary btn-lg">Next chapter</Link>
            </div>
          )}
        </div>
      ) : (
        <div className="reader-paged">
          {pages[currentPage] ? (
            <img src={pages[currentPage].imageUrl} alt={`Page ${currentPage + 1}`} className="reader-paged__img" />
          ) : (
            <div className="reader-empty"><InboxIcon /><p>No pages</p></div>
          )}
          <div className="reader-tap-zones" onClick={e => e.stopPropagation()}>
            <button className="reader-tap reader-tap--left" onClick={() => setCurrentPage(p => Math.max(0, p - 1))} aria-label="Previous page" />
            <button className="reader-tap reader-tap--right" onClick={() => setCurrentPage(p => Math.min(pages.length - 1, p + 1))} aria-label="Next page" />
          </div>
        </div>
      )}

      <div className={`reader-bottombar ${uiVisible ? 'visible' : ''}`} onClick={e => e.stopPropagation()}>
        <div className="reader-nav-row">
          {prev ? <Link to={`/manga/${slug}/chapter/${prev.number}`} className="btn btn-secondary btn-sm">← Ch. {prev.number}</Link> : <span />}
          {mode === 'page' && pages.length > 0 && (
            <div className="reader-page-counter">
              <span className="reader-page-counter__current">{currentPage + 1}</span>
              <span className="reader-page-counter__sep">/</span>
              <span className="reader-page-counter__total">{pages.length}</span>
            </div>
          )}
          {next ? <Link to={`/manga/${slug}/chapter/${next.number}`} className="btn btn-secondary btn-sm">Ch. {next.number} →</Link> : <span />}
        </div>
        {mode === 'page' && pages.length > 1 && (
          <input
            type="range" min={0} max={pages.length - 1} value={currentPage}
            onChange={e => setCurrentPage(Number(e.target.value))}
            className="reader-scrubber"
          />
        )}
      </div>
    </div>
  );
}
