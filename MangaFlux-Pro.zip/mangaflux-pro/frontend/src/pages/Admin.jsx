import { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import './Admin.css';

const ShieldIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M10 2L4 5v5c0 4.4 2.6 7.6 6 8.9C14.4 17.6 17 14.4 17 10V5L10 2z"/></svg>;
const GridIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7"><rect x="3" y="3" width="6" height="6" rx="1"/><rect x="11" y="3" width="6" height="6" rx="1"/><rect x="3" y="11" width="6" height="6" rx="1"/><rect x="11" y="11" width="6" height="6" rx="1"/></svg>;
const BotIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="7" width="12" height="9" rx="2"/><path d="M10 7V4M7 4h6M7.5 11v1.5M12.5 11v1.5"/></svg>;
const PlusIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M10 4v12M4 10h12"/></svg>;
const UsersIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><circle cx="7" cy="6.5" r="3"/><path d="M1.5 17c0-3.3 2.5-5.5 5.5-5.5s5.5 2.2 5.5 5.5M14 4a3 3 0 010 6M17.5 17c0-2.6-1.6-4.6-3.8-5.3"/></svg>;
const RefreshIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M16 8a6 6 0 10-1.5 4M16 4v4h-4"/></svg>;
const EyeIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6"><path d="M1 10S4 4 10 4s9 6 9 6-3 6-9 6-9-6-9-6z"/><circle cx="10" cy="10" r="2.5"/></svg>;
const StarIcon = () => <svg viewBox="0 0 20 20" fill="currentColor"><path d="M10 1l2.39 4.84 5.34.78-3.87 3.77.91 5.33L10 13.27l-4.77 2.45.91-5.33L2.27 6.62l5.34-.78L10 1z"/></svg>;
const CrownIcon = () => <svg viewBox="0 0 20 20" fill="currentColor"><path d="M2 7l3 3 5-5 5 5 3-3-1.5 9h-13L2 7z"/></svg>;
const GlobeIcon = () => <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7"><circle cx="10" cy="10" r="8"/><path d="M2 10h16M10 2c2.5 2.2 2.5 13.8 0 16M10 2c-2.5 2.2-2.5 13.8 0 16"/></svg>;

const TABS = [
  { id: 'dashboard', label: 'Dashboard', Icon: GridIcon },
  { id: 'scraper',   label: 'Scraper',   Icon: BotIcon },
  { id: 'manga',     label: 'Add Manga', Icon: PlusIcon },
  { id: 'users',     label: 'Users',     Icon: UsersIcon },
];

export default function Admin() {
  const { user, isAdmin } = useAuth();
  const navigate = useNavigate();
  const showToast = useToast();
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [tab, setTab] = useState('dashboard');
  const [scraperStatus, setScraperStatus] = useState(null);
  const [scraperRunning, setScraperRunning] = useState(false);
  const [mangaForm, setMangaForm] = useState({ title: '', description: '', coverImage: '', bannerImage: '', type: 'manga', status: 'ongoing', genres: '', authors: '' });
  const [userSearch, setUserSearch] = useState('');

  const loadStats = useCallback(() => api.get('/admin/stats').then(setStats).catch(() => {}), []);
  const loadScraperStatus = useCallback(() => api.get('/admin/scraper/status').then(setScraperStatus).catch(() => {}), []);
  const loadUsers = useCallback((search = '') => api.get(`/admin/users?search=${encodeURIComponent(search)}`).then(d => setUsers(d.users || [])), []);

  useEffect(() => {
    if (!isAdmin) { navigate('/'); return; }
    loadStats();
  }, [isAdmin]);

  useEffect(() => {
    if (tab === 'scraper') {
      loadScraperStatus();
      const t = setInterval(loadScraperStatus, 5000);
      return () => clearInterval(t);
    }
    if (tab === 'users') loadUsers(userSearch);
  }, [tab]);

  const toggleScraper = async (val) => {
    try {
      await api.post('/admin/scraper/toggle', { enabled: val });
      showToast(val ? 'Auto scraper enabled' : 'Auto scraper disabled', 'success');
      loadScraperStatus();
    } catch (err) { showToast(err.message, 'error'); }
  };

  const runScraper = async () => {
    if (scraperRunning) return;
    setScraperRunning(true);
    showToast('Scraper started — running in background', 'info', 5000);
    try {
      await api.post('/admin/scraper/run', { source: 'mangadex' });
    } catch (err) {
      showToast(err.message || 'Failed to start scraper', 'error');
    } finally {
      setTimeout(() => { setScraperRunning(false); loadStats(); loadScraperStatus(); }, 3000);
    }
  };

  const addManga = async (e) => {
    e.preventDefault();
    try {
      await api.post('/manga', {
        ...mangaForm,
        genres:  mangaForm.genres.split(',').map(g => g.trim()).filter(Boolean),
        authors: mangaForm.authors.split(',').map(a => a.trim()).filter(Boolean),
      });
      showToast('Manga added successfully', 'success');
      setMangaForm({ title: '', description: '', coverImage: '', bannerImage: '', type: 'manga', status: 'ongoing', genres: '', authors: '' });
      loadStats();
    } catch (err) { showToast(err.message || 'Failed to add manga', 'error'); }
  };

  const banUser = async (id, ban) => {
    try {
      await api.patch(`/admin/users/${id}/ban`, { isBanned: ban });
      showToast(ban ? 'User banned' : 'User unbanned', 'success');
      loadUsers(userSearch);
    } catch (err) { showToast(err.message, 'error'); }
  };

  return (
    <div className="page container admin-page">
      <div className="admin-head">
        <span className="admin-head__icon"><ShieldIcon /></span>
        <div>
          <h1 className="admin-head__title">Admin Panel</h1>
          <p className="admin-head__sub">
            {user?.role === 'owner' ? <><CrownIcon /> Owner access</> : 'Admin access'}
          </p>
        </div>
      </div>

      <div className="admin-tabs">
        {TABS.map(t => (
          <button key={t.id} className={`admin-tab ${tab === t.id ? 'active' : ''}`} onClick={() => setTab(t.id)}>
            <t.Icon /> {t.label}
          </button>
        ))}
      </div>

      {tab === 'dashboard' && (
        <div className="admin-content">
          {stats ? (
            <>
              <div className="admin-stat-grid">
                {[
                  { val: stats.users,       label: 'Total users',  Icon: UsersIcon, color: 'var(--accent-hi)' },
                  { val: stats.manga,       label: 'Manga titles', Icon: GridIcon,  color: 'var(--cyan)' },
                  { val: stats.chapters,    label: 'Chapters',     Icon: PlusIcon,  color: '#4ade80' },
                  { val: stats.activeToday, label: 'Active today', Icon: StarIcon,  color: 'var(--gold)' },
                ].map(s => (
                  <div key={s.label} className="admin-stat-card">
                    <span className="admin-stat-card__icon" style={{ color: s.color }}><s.Icon /></span>
                    <span className="admin-stat-card__val">{(s.val || 0).toLocaleString()}</span>
                    <span className="admin-stat-card__label">{s.label}</span>
                  </div>
                ))}
              </div>

              <div className="admin-section-head">
                <h2 className="admin-section-title">Top manga by views</h2>
                <button className="btn btn-secondary btn-sm" onClick={loadStats}><RefreshIcon /> Refresh</button>
              </div>
              <div className="admin-list">
                {(stats.topManga || []).map((m, i) => (
                  <div key={m._id} className="admin-list-item">
                    <span className="admin-list-item__rank">#{i + 1}</span>
                    {m.coverImage && <img src={m.coverImage} className="admin-list-item__cover" alt="" />}
                    <span className="admin-list-item__title">{m.title}</span>
                    <div className="admin-list-item__meta">
                      <span><EyeIcon /> {(m.views || 0).toLocaleString()}</span>
                      <span><StarIcon /> {m.rating?.toFixed(1) || 'N/A'}</span>
                    </div>
                  </div>
                ))}
              </div>

              <h2 className="admin-section-title" style={{ marginTop: 28 }}>Recently added</h2>
              <div className="admin-list">
                {(stats.recentManga || []).map(m => (
                  <div key={m._id} className="admin-list-item">
                    <span className="admin-list-item__rank admin-list-item__rank--date">{new Date(m.createdAt).toLocaleDateString()}</span>
                    <span className="admin-list-item__title">{m.title}</span>
                    <span className="badge badge-neutral">{m.source}</span>
                  </div>
                ))}
              </div>
            </>
          ) : <div className="spinner-page"><div className="spinner spinner-lg" /></div>}
        </div>
      )}

      {tab === 'scraper' && (
        <div className="admin-content">
          <h2 className="admin-section-title">Auto scraper</h2>

          {scraperStatus && (
            <div className={`scraper-status ${scraperStatus.isRunning ? 'running' : ''}`}>
              <span className="scraper-status__dot" />
              <span>{scraperStatus.isRunning ? 'Scraper is currently running…' : 'Scraper is idle'}</span>
              {scraperStatus.lastRun && (
                <span className="scraper-status__time">Last run: {new Date(scraperStatus.lastRun).toLocaleString()}</span>
              )}
            </div>
          )}

          <div className="card">
            <div className="scraper-source">
              <span className="scraper-source__icon"><GlobeIcon /></span>
              <div className="scraper-source__info">
                <strong>MangaDex API</strong>
                <span>Official public API — no key required, rate-limit safe</span>
              </div>
              <span className="badge badge-green">Active</span>
            </div>

            <div className="divider" />

            <div className="scraper-row">
              <div>
                <div className="scraper-row__label">Auto-scraping schedule</div>
                <div className="scraper-row__sub">Fetches the top 25 manga every 6 hours, plus once on server boot</div>
              </div>
              <button className={`toggle ${scraperStatus?.scheduled ? 'on' : ''}`} onClick={() => toggleScraper(!scraperStatus?.scheduled)} aria-label="Toggle scheduled scraping" />
            </div>

            <div className="divider" />

            <div className="scraper-row">
              <div>
                <div className="scraper-row__label">Manual run</div>
                <div className="scraper-row__sub">Scrape the latest content right now (runs in background)</div>
              </div>
              <button className="btn btn-primary btn-sm" onClick={runScraper} disabled={scraperRunning || scraperStatus?.isRunning}>
                {scraperRunning || scraperStatus?.isRunning ? <span className="spinner" /> : 'Run now'}
              </button>
            </div>

            <div className="divider" />

            <div className="scraper-info-grid">
              {[
                ['Source', 'MangaDex (api.mangadex.org)'],
                ['Schedule', 'Every 6 hours via node-cron'],
                ['Batch size', '25 manga · 10 chapters each'],
                ['Languages', 'English'],
                ['Content rating', 'Safe + Suggestive'],
                ['Images', 'Data-saver CDN (faster delivery)'],
                ['Boot scrape', 'Runs automatically 8s after startup'],
                ['Retry policy', '3 retries with backoff on rate-limit/timeout'],
              ].map(([k, v]) => (
                <div key={k} className="scraper-info-item">
                  <span className="scraper-info-item__key">{k}</span>
                  <span className="scraper-info-item__val">{v}</span>
                </div>
              ))}
            </div>

            <div className="scraper-tip">
              <strong>First-time setup:</strong> click <em>Run now</em> to populate your database. This takes roughly 1–3 minutes — check the server console for progress logs.
              {scraperStatus?.lastError && (
                <div className="scraper-tip__error">Last error: {scraperStatus.lastError}</div>
              )}
            </div>
          </div>
        </div>
      )}

      {tab === 'manga' && (
        <div className="admin-content">
          <h2 className="admin-section-title">Add manga manually</h2>
          <form onSubmit={addManga} className="admin-form">
            <div className="admin-field">
              <label>Title *</label>
              <input className="input" placeholder="Manga title" required value={mangaForm.title} onChange={e => setMangaForm({ ...mangaForm, title: e.target.value })} />
            </div>
            <div className="admin-field">
              <label>Cover image URL</label>
              <input className="input" placeholder="https://…" value={mangaForm.coverImage} onChange={e => setMangaForm({ ...mangaForm, coverImage: e.target.value })} />
            </div>
            <div className="admin-field">
              <label>Banner image URL (optional)</label>
              <input className="input" placeholder="https://…" value={mangaForm.bannerImage} onChange={e => setMangaForm({ ...mangaForm, bannerImage: e.target.value })} />
            </div>
            <div className="admin-row">
              <div className="admin-field">
                <label>Type</label>
                <select className="input" value={mangaForm.type} onChange={e => setMangaForm({ ...mangaForm, type: e.target.value })}>
                  {['manga', 'manhwa', 'manhua', 'webtoon'].map(t => <option key={t}>{t}</option>)}
                </select>
              </div>
              <div className="admin-field">
                <label>Status</label>
                <select className="input" value={mangaForm.status} onChange={e => setMangaForm({ ...mangaForm, status: e.target.value })}>
                  {['ongoing', 'completed', 'hiatus', 'cancelled'].map(s => <option key={s}>{s}</option>)}
                </select>
              </div>
            </div>
            <div className="admin-field">
              <label>Genres (comma separated)</label>
              <input className="input" placeholder="Action, Fantasy, Romance" value={mangaForm.genres} onChange={e => setMangaForm({ ...mangaForm, genres: e.target.value })} />
            </div>
            <div className="admin-field">
              <label>Authors (comma separated)</label>
              <input className="input" placeholder="Author name" value={mangaForm.authors} onChange={e => setMangaForm({ ...mangaForm, authors: e.target.value })} />
            </div>
            <div className="admin-field">
              <label>Description</label>
              <textarea className="input" rows={4} placeholder="Brief description…" value={mangaForm.description} onChange={e => setMangaForm({ ...mangaForm, description: e.target.value })} />
            </div>
            <button type="submit" className="btn btn-primary"><PlusIcon /> Add manga</button>
          </form>
        </div>
      )}

      {tab === 'users' && (
        <div className="admin-content">
          <div className="admin-section-head">
            <h2 className="admin-section-title">Users ({users.length})</h2>
            <input className="input" style={{ width: 200, height: 36 }} placeholder="Search users…" value={userSearch} onChange={e => { setUserSearch(e.target.value); loadUsers(e.target.value); }} />
          </div>
          {users.length === 0 ? (
            <div className="spinner-page"><div className="spinner spinner-lg" /></div>
          ) : (
            <div className="admin-user-list">
              {users.map(u => (
                <div key={u._id} className="admin-user-item">
                  <span className="admin-user-item__avatar">{u.username?.[0]?.toUpperCase()}</span>
                  <div className="admin-user-item__info">
                    <div className="admin-user-item__name">
                      {u.username}
                      <span className={`badge admin-role-badge admin-role-badge--${u.role}`}>{u.role}</span>
                      {u.isBanned && <span className="badge badge-red">banned</span>}
                      {u.isPremium && <span className="badge badge-gold">premium</span>}
                    </div>
                    <div className="admin-user-item__email">{u.email}</div>
                  </div>
                  {u.role !== 'owner' && (
                    <button className={`btn btn-sm ${u.isBanned ? 'btn-primary' : 'btn-secondary'}`} onClick={() => banUser(u._id, !u.isBanned)} style={!u.isBanned ? { color: '#f87171', borderColor: 'rgba(239,68,68,0.3)' } : {}}>
                      {u.isBanned ? 'Unban' : 'Ban'}
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
