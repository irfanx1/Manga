import { useEffect, useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import api from '../utils/api';
import MangaCard, { MangaCardSkeleton } from '../components/manga/MangaCard';
import './Home.css';

const GENRES = ['Action','Adventure','Comedy','Drama','Fantasy','Horror','Mystery','Romance','Sci-Fi','Slice of Life','Sports','Supernatural','Thriller','Isekai','Psychological'];

const ChevronLeft = () => (
  <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12.5 15l-5-5 5-5"/></svg>
);
const ChevronRight = () => (
  <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M7.5 5l5 5-5 5"/></svg>
);
const StarIcon = () => (
  <svg viewBox="0 0 20 20" fill="currentColor"><path d="M10 1l2.39 4.84 5.34.78-3.87 3.77.91 5.33L10 13.27l-4.77 2.45.91-5.33L2.27 6.62l5.34-.78L10 1z"/></svg>
);
const EyeIcon = () => (
  <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7"><path d="M1 10S4 4 10 4s9 6 9 6-3 6-9 6-9-6-9-6z"/><circle cx="10" cy="10" r="2.5"/></svg>
);
const PlayIcon = () => (
  <svg viewBox="0 0 20 20" fill="currentColor"><path d="M5 3.5v13l11-6.5-11-6.5z"/></svg>
);

function ScrollRow({ title, sub, items, loading, to }) {
  const trackRef = useRef(null);
  const scroll = (dir) => {
    trackRef.current?.scrollBy({ left: dir * 600, behavior: 'smooth' });
  };
  return (
    <section className="row">
      <div className="row__head">
        <div>
          <p className="row__sub">{sub}</p>
          <h2 className="row__title">{title}</h2>
        </div>
        <div className="row__actions">
          {to && <Link to={to} className="row__see-all">See all</Link>}
          <button className="btn-icon" onClick={() => scroll(-1)} aria-label="Scroll left"><ChevronLeft /></button>
          <button className="btn-icon" onClick={() => scroll(1)} aria-label="Scroll right"><ChevronRight /></button>
        </div>
      </div>
      <div className="row__track" ref={trackRef}>
        {loading
          ? Array(8).fill(0).map((_, i) => <div key={i} className="row__item"><MangaCardSkeleton /></div>)
          : items.map(m => <div key={m._id} className="row__item"><MangaCard manga={m} /></div>)
        }
      </div>
    </section>
  );
}

export default function Home() {
  const [featured, setFeatured]   = useState([]);
  const [latest, setLatest]       = useState([]);
  const [popular, setPopular]     = useState([]);
  const [topRated, setTopRated]   = useState([]);
  const [heroIdx, setHeroIdx]     = useState(0);
  const [loading, setLoading]     = useState(true);

  useEffect(() => {
    setLoading(true);
    Promise.all([
      api.get('/manga?sort=-views&limit=6'),
      api.get('/manga?sort=-lastUpdated&limit=12'),
      api.get('/manga?sort=-views&limit=12'),
      api.get('/manga?sort=-rating&limit=12'),
    ]).then(([feat, lat, pop, top]) => {
      setFeatured(feat.manga || []);
      setLatest(lat.manga || []);
      setPopular(pop.manga || []);
      setTopRated(top.manga || []);
    }).finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (!featured.length) return;
    const t = setInterval(() => setHeroIdx(i => (i + 1) % featured.length), 6000);
    return () => clearInterval(t);
  }, [featured]);

  const hero = featured[heroIdx];

  return (
    <div className="page home">
      {/* ── HERO ── */}
      <section className="hero">
        {hero?.bannerImage || hero?.coverImage ? (
          <div className="hero__bg" style={{ backgroundImage: `url(${hero.bannerImage || hero.coverImage})` }} />
        ) : <div className="hero__bg hero__bg--default" />}
        <div className="hero__scrim" />

        <div className="container hero__content">
          {hero ? (
            <>
              <div className="hero__left fade-up">
                <div className="hero__tags">
                  <span className="badge badge-accent">{hero.type}</span>
                  <span className={`status status-${hero.status}`}>{hero.status}</span>
                </div>
                <h1 className="hero__title">{hero.title}</h1>
                <p className="hero__desc clamp-3">{hero.description || 'No description available.'}</p>
                <div className="hero__stats">
                  <span className="hero__stat"><StarIcon /> {hero.rating ? hero.rating.toFixed(1) : 'N/A'}</span>
                  <span className="hero__stat"><EyeIcon /> {(hero.views || 0).toLocaleString()}</span>
                  <span className="hero__stat">{hero.chapterCount || 0} chapters</span>
                </div>
                <div className="hero__btns">
                  <Link to={`/manga/${hero.slug}`} className="btn btn-primary btn-lg">
                    <PlayIcon /> Start reading
                  </Link>
                  <Link to="/explore" className="btn btn-secondary btn-lg">Browse all</Link>
                </div>
              </div>

              <div className="hero__right">
                <div className="hero__cover-glow" />
                <img src={hero.coverImage} alt={hero.title} className="hero__cover" />
              </div>
            </>
          ) : (
            <div className="hero__left">
              <div className="skel" style={{ height: 38, width: 360, borderRadius: 8, marginBottom: 14 }} />
              <div className="skel" style={{ height: 16, width: 480, borderRadius: 6, marginBottom: 8 }} />
              <div className="skel" style={{ height: 16, width: 400, borderRadius: 6 }} />
            </div>
          )}
        </div>

        {featured.length > 1 && (
          <div className="hero__dots">
            {featured.map((_, i) => (
              <button key={i} className={`hero__dot ${i === heroIdx ? 'active' : ''}`} onClick={() => setHeroIdx(i)} aria-label={`Slide ${i + 1}`} />
            ))}
          </div>
        )}
      </section>

      {/* ── GENRE STRIP ── */}
      <div className="genre-strip">
        <div className="genre-strip__track">
          {[...GENRES, ...GENRES].map((g, i) => (
            <Link key={i} to={`/explore?genre=${g}`} className="genre-strip__pill">{g}</Link>
          ))}
        </div>
      </div>

      <div className="container">
        <ScrollRow title="Latest updates" sub="Fresh chapters" items={latest} loading={loading} to="/explore?sort=-lastUpdated" />
        <ScrollRow title="Most popular" sub="Trending now" items={popular} loading={loading} to="/explore?sort=-views" />
        <ScrollRow title="Top rated" sub="Reader favorites" items={topRated} loading={loading} to="/explore?sort=-rating" />

        {/* ── GENRE GRID ── */}
        <section className="section">
          <div className="section-label">Discover</div>
          <h2 className="section-title" style={{ marginBottom: 16 }}>Browse by genre</h2>
          <div className="genre-grid">
            {GENRES.slice(0, 10).map(g => (
              <Link key={g} to={`/explore?genre=${g}`} className="genre-tile">
                <span>{g}</span>
                <ChevronRight />
              </Link>
            ))}
          </div>
        </section>

        {/* ── PREMIUM BANNER ── */}
        <Link to="/premium" className="promo-banner">
          <div className="promo-banner__glow" />
          <div className="promo-banner__content">
            <span className="badge badge-gold">Premium</span>
            <h3>Read without limits</h3>
            <p>Ad-free chapters, HD pages, and early access to new releases.</p>
          </div>
          <span className="btn btn-primary promo-banner__btn">Upgrade now</span>
        </Link>
      </div>
    </div>
  );
}
