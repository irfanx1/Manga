import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import './BottomNav.css';

const HomeIcon = ({ filled }) => (
  <svg viewBox="0 0 20 20" fill={filled ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 10L10 3l7 7M5 8.5V17h4v-4h2v4h4V8.5" />
  </svg>
);
const CompassIcon = ({ filled }) => (
  <svg viewBox="0 0 20 20" fill={filled ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="1.7">
    <circle cx="10" cy="10" r="8" />
    {!filled && <path d="M13.2 6.8 11 11 6.8 13.2 9 9l4.2-2.2z" strokeLinecap="round" strokeLinejoin="round"/>}
  </svg>
);
const BookIcon = ({ filled }) => (
  <svg viewBox="0 0 20 20" fill={filled ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 3h9a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z" />
    <path d="M7 7h4M7 10h4" />
  </svg>
);
const UserIcon = ({ filled }) => (
  <svg viewBox="0 0 20 20" fill={filled ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="1.7">
    <circle cx="10" cy="7" r="3.5" />
    <path d="M3 18c0-4 3.1-6.5 7-6.5s7 2.5 7 6.5" strokeLinecap="round" />
  </svg>
);

export default function BottomNav() {
  const { user } = useAuth();
  const { pathname } = useLocation();

  if (pathname.includes('/chapter/')) return null;

  const items = [
    { to: '/',        label: 'Home',    Icon: HomeIcon,    match: p => p === '/' },
    { to: '/explore', label: 'Browse',  Icon: CompassIcon, match: p => p.startsWith('/explore') || p.startsWith('/search') },
    { to: '/library', label: 'Library', Icon: BookIcon,    match: p => p === '/library' || p === '/history', auth: true },
    { to: user ? '/profile' : '/login', label: user ? 'Profile' : 'Sign in', Icon: UserIcon, match: p => p === '/profile' || p === '/login' },
  ];

  return (
    <nav className="bnav">
      {items.map(({ to, label, Icon, match, auth }) => {
        if (auth && !user) return null;
        const active = match(pathname);
        return (
          <Link key={to} to={to} className={`bnav__item ${active ? 'active' : ''}`}>
            <span className="bnav__icon"><Icon filled={active} /></span>
            <span className="bnav__label">{label}</span>
          </Link>
        );
      })}
    </nav>
  );
}
