import { useState, useRef, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import './Navbar.css';

/* ── Icons ─────────────────────────────────────────────────── */
const SearchIcon = () => (
  <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
    <circle cx="8.5" cy="8.5" r="5.5" /><path d="M13.5 13.5 18 18" />
  </svg>
);
const UserIcon = () => (
  <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7">
    <circle cx="10" cy="7" r="3.5" /><path d="M3 18c0-4 3.1-6.5 7-6.5s7 2.5 7 6.5" strokeLinecap="round" />
  </svg>
);
const LogoutIcon = () => (
  <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7">
    <path d="M13 3h4v14h-4M8 14l4-4-4-4M12 10H3" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);
const ShieldIcon = () => (
  <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7">
    <path d="M10 2L4 5v5c0 4.4 2.6 7.6 6 8.9C14.4 17.6 17 14.4 17 10V5L10 2z" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);
const LibraryIcon = () => (
  <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.7">
    <path d="M4 4h4v12H4zM8 6h4v10H8zM12 3h4v13h-4z" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);
const StarIcon = () => (
  <svg viewBox="0 0 20 20" fill="currentColor">
    <path d="M10 1l2.39 4.84 5.34.78-3.87 3.77.91 5.33L10 13.27l-4.77 2.45.91-5.33L2.27 6.62l5.34-.78L10 1z"/>
  </svg>
);
const XIcon = () => (
  <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M5 5l10 10M15 5 5 15" strokeLinecap="round"/>
  </svg>
);

export default function Navbar() {
  const { user, logout } = useAuth();
  const location  = useLocation();
  const navigate  = useNavigate();
  const [query, setQuery]       = useState('');
  const [dropOpen, setDropOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const dropRef   = useRef(null);
  const searchRef = useRef(null);
  const inputRef  = useRef(null);

  const isReader = location.pathname.includes('/chapter/');
  if (isReader) return null;

  const handleSearch = (e) => {
    e?.preventDefault();
    const q = query.trim();
    if (!q) return;
    navigate(`/search?q=${encodeURIComponent(q)}`);
    setQuery('');
    setSearchOpen(false);
  };

  const openSearch = () => {
    setSearchOpen(true);
    setTimeout(() => inputRef.current?.focus(), 50);
  };

  useEffect(() => {
    if (!dropOpen) return;
    const handler = (e) => { if (!dropRef.current?.contains(e.target)) setDropOpen(false); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [dropOpen]);

  useEffect(() => { setDropOpen(false); setSearchOpen(false); }, [location.pathname]);

  const initials = user?.username?.[0]?.toUpperCase() || 'U';

  return (
    <>
      <nav className="nav">
        <div className="nav__inner">
          {/* Logo */}
          <Link to="/" className="nav__logo">
            <span className="nav__logo-mark" />
            <span className="nav__logo-text">Manga<span>Flux</span></span>
          </Link>

          {/* Desktop links */}
          <ul className="nav__links">
            <li><Link to="/" className={`nav__link ${location.pathname === '/' ? 'active' : ''}`}>Home</Link></li>
            <li><Link to="/explore" className={`nav__link ${location.pathname.startsWith('/explore') ? 'active' : ''}`}>Browse</Link></li>
            {user && <li><Link to="/library" className={`nav__link ${location.pathname === '/library' ? 'active' : ''}`}>Library</Link></li>}
          </ul>

          {/* Right actions */}
          <div className="nav__actions">
            {/* Search icon */}
            <button className="btn-icon" onClick={openSearch} aria-label="Search">
              <SearchIcon />
            </button>

            {user ? (
              <div className="nav__user" ref={dropRef}>
                <button className="nav__avatar" onClick={() => setDropOpen(o => !o)} aria-label="Account">
                  {user.avatar
                    ? <img src={user.avatar} alt={user.username} />
                    : <span>{initials}</span>
                  }
                  {user.isPremium && <span className="nav__avatar-premium"><StarIcon /></span>}
                </button>

                {dropOpen && (
                  <div className="nav__drop" role="menu">
                    <div className="nav__drop-header">
                      <span className="nav__drop-name">{user.username}</span>
                      <span className="nav__drop-email">{user.email}</span>
                      {user.isPremium && <span className="badge badge-gold" style={{marginTop:6}}>Premium</span>}
                    </div>
                    <div className="nav__drop-divider" />
                    <Link to="/profile" className="nav__drop-item" role="menuitem">
                      <UserIcon /> Profile
                    </Link>
                    <Link to="/library" className="nav__drop-item" role="menuitem">
                      <LibraryIcon /> Library
                    </Link>
                    {(user.role === 'admin' || user.role === 'owner') && (
                      <Link to="/admin" className="nav__drop-item" role="menuitem">
                        <ShieldIcon /> Admin Panel
                      </Link>
                    )}
                    <div className="nav__drop-divider" />
                    <button className="nav__drop-item nav__drop-item--danger" onClick={logout} role="menuitem">
                      <LogoutIcon /> Sign out
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="nav__auth">
                <Link to="/login" className="btn btn-ghost btn-sm">Sign in</Link>
                <Link to="/register" className="btn btn-primary btn-sm">Get started</Link>
              </div>
            )}
          </div>
        </div>
      </nav>

      {/* Search overlay */}
      {searchOpen && (
        <div className="search-overlay" onClick={(e) => { if (e.target === e.currentTarget) setSearchOpen(false); }}>
          <div className="search-modal">
            <form className="search-modal__form" onSubmit={handleSearch}>
              <span className="search-modal__icon"><SearchIcon /></span>
              <input
                ref={inputRef}
                className="search-modal__input"
                placeholder="Search manga, manhwa, manhua…"
                value={query}
                onChange={e => setQuery(e.target.value)}
              />
              {query && (
                <button type="button" className="btn-icon" onClick={() => setQuery('')}>
                  <XIcon />
                </button>
              )}
            </form>
            <p className="search-modal__hint">Press Enter to search · Esc to close</p>
          </div>
        </div>
      )}
    </>
  );
}
