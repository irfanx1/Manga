import { Link } from 'react-router-dom';
import './MangaCard.css';

export default function MangaCard({ manga, size = 'md' }) {
  if (!manga) return null;
  return (
    <Link to={`/manga/${manga.slug}`} className={`mcard mcard--${size}`}>
      <div className="mcard__cover">
        {manga.coverImage
          ? <img src={manga.coverImage} alt={manga.title} loading="lazy" decoding="async" />
          : <div className="mcard__placeholder"><span>{manga.title?.[0]}</span></div>
        }
        <div className="mcard__overlay">
          <span className="mcard__ch">Ch.{manga.latestChapter ?? '—'}</span>
        </div>
        {manga.featured && <span className="mcard__badge badge badge-gold">Hot</span>}
        {manga.status === 'completed' && <span className="mcard__badge badge badge-cyan">Done</span>}
      </div>
      <div className="mcard__info">
        <h3 className="mcard__title clamp-2">{manga.title}</h3>
        <p className="mcard__meta">
          <span className={`status status-${manga.status}`}>{manga.type}</span>
          <span className="mcard__sep">·</span>
          <span>{manga.chapterCount ?? 0} ch</span>
        </p>
      </div>
    </Link>
  );
}

export function MangaCardSkeleton() {
  return (
    <div className="mcard">
      <div className="mcard__cover skel" style={{ aspectRatio: '2/3' }} />
      <div className="mcard__info">
        <div className="skel" style={{ height: 13, borderRadius: 4, marginBottom: 7 }} />
        <div className="skel" style={{ height: 11, width: '55%', borderRadius: 4 }} />
      </div>
    </div>
  );
}
