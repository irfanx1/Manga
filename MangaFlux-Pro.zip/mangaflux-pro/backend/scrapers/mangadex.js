const axios = require('axios');
const Manga = require('../models/Manga');
const Chapter = require('../models/Chapter');

const BASE = 'https://api.mangadex.org';
const COVERS = 'https://uploads.mangadex.org/covers';

/**
 * MangaDex expects bracket-style array/object query params, e.g.
 *   order[followedCount]=desc
 *   includes[]=cover_art&includes[]=author
 * Axios's default paramsSerializer does NOT produce this format for nested
 * objects (it stringifies them as [object Object]) and serializes arrays as
 * repeated keys without brackets — both silently break MangaDex filtering
 * and sorting (requests still succeed, but return unsorted/unfiltered data).
 * This custom serializer fixes that.
 */
function serializeParams(params) {
  const parts = [];
  const add = (key, value) => parts.push(`${encodeURIComponent(key)}=${encodeURIComponent(value)}`);

  for (const [key, val] of Object.entries(params)) {
    if (val === undefined || val === null) continue;
    if (Array.isArray(val)) {
      val.forEach(v => add(`${key}[]`, v));
    } else if (typeof val === 'object') {
      for (const [subKey, subVal] of Object.entries(val)) {
        add(`${key}[${subKey}]`, subVal);
      }
    } else {
      add(key, val);
    }
  }
  return parts.join('&');
}

// Retry wrapper — MangaDex rate-limits at ~5 req/s
async function apiGet(url, params = {}, retries = 3) {
  for (let i = 0; i < retries; i++) {
    try {
      const res = await axios.get(url, {
        params,
        paramsSerializer: serializeParams,
        timeout: 15000,
        headers: { 'User-Agent': 'MangaFlux/2.0 (contact@mangaflux.com)' },
      });
      return res.data;
    } catch (e) {
      const status = e.response?.status;
      if (status === 429 || status === 503) {
        const wait = (i + 1) * 2000;
        console.log(`[MangaDex] ${status === 429 ? 'Rate limited' : 'Service unavailable'}. Retrying in ${wait}ms (attempt ${i + 1}/${retries})...`);
        await sleep(wait);
        continue;
      }
      if (e.code === 'ECONNABORTED' || e.code === 'ETIMEDOUT') {
        console.log(`[MangaDex] Request timed out. Retrying (attempt ${i + 1}/${retries})...`);
        await sleep(1500);
        continue;
      }
      console.error(`[MangaDex] ${url} failed:`, e.message);
      return null;
    }
  }
  console.error(`[MangaDex] ${url} failed after ${retries} retries.`);
  return null;
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function fetchPopularManga(limit = 25) {
  const data = await apiGet(`${BASE}/manga`, {
    limit,
    order: { followedCount: 'desc' },
    includes: ['cover_art', 'author', 'artist'],
    availableTranslatedLanguage: ['en'],
    contentRating: ['safe', 'suggestive'],
    hasAvailableChapters: 'true',
  });
  return data?.data || [];
}

async function fetchChapters(mangadexId, limit = 10) {
  const data = await apiGet(`${BASE}/chapter`, {
    manga: mangadexId,
    limit,
    translatedLanguage: ['en'],
    order: { chapter: 'desc' },
    contentRating: ['safe', 'suggestive'],
    includes: ['scanlation_group'],
  });
  return data?.data || [];
}

async function fetchChapterPages(chapterId) {
  const data = await apiGet(`${BASE}/at-home/server/${chapterId}`);
  if (!data) return [];
  const { baseUrl, chapter } = data;
  const files = chapter.dataSaver || chapter.data;
  const folder = chapter.dataSaver ? 'data-saver' : 'data';
  return (files || []).map((file, i) => ({
    pageNumber: i + 1,
    imageUrl: `${baseUrl}/${folder}/${chapter.hash}/${file}`,
  }));
}

function extractCover(manga) {
  const rel = manga.relationships?.find(r => r.type === 'cover_art');
  if (rel?.attributes?.fileName)
    return `${COVERS}/${manga.id}/${rel.attributes.fileName}.512.jpg`;
  return '';
}

function extractAuthors(manga, type = 'author') {
  return manga.relationships?.filter(r => r.type === type)
    .map(r => r.attributes?.name || '').filter(Boolean) || [];
}

async function scrapeManga(limit = 25) {
  console.log('[Scraper] ── Starting MangaDex scrape ──');
  const mangaList = await fetchPopularManga(limit);
  if (!mangaList.length) {
    console.log('[Scraper] No manga returned. Check network connectivity or MangaDex status (https://status.mangadex.org).');
    return { ok: false, processed: 0, errors: 0, reason: 'empty-response' };
  }

  let ok = 0, skipped = 0, newChaptersTotal = 0;

  for (const item of mangaList) {
    try {
      const attrs = item.attributes;
      const title = attrs.title?.en
        || attrs.title?.['ja-ro']
        || attrs.altTitles?.find(t => t.en)?.en
        || Object.values(attrs.title || {})[0]
        || `Untitled (${item.id.slice(0, 6)})`;

      const coverImage = extractCover(item);
      const authors  = extractAuthors(item, 'author');
      const artists  = extractAuthors(item, 'artist');

      const type = attrs.originalLanguage === 'ko' ? 'manhwa'
                 : attrs.originalLanguage === 'zh' || attrs.originalLanguage === 'zh-hk' ? 'manhua'
                 : 'manga';

      const status = attrs.status === 'completed' ? 'completed'
                   : attrs.status === 'hiatus'    ? 'hiatus'
                   : attrs.status === 'cancelled' ? 'cancelled'
                   : 'ongoing';

      const genres = attrs.tags
        ?.filter(t => t.attributes?.group === 'genre')
        .map(t => t.attributes?.name?.en)
        .filter(Boolean) || [];

      const mangaData = {
        title,
        description: attrs.description?.en?.slice(0, 2000) || '',
        coverImage, type, status, genres, authors, artists,
        source: 'mangadex', sourceId: item.id,
        sourceUrl: `https://mangadex.org/title/${item.id}`,
        lastUpdated: new Date(),
      };

      // Upsert by sourceId — avoids duplicates on repeated scrapes
      let manga = await Manga.findOne({ sourceId: item.id });
      if (manga) {
        Object.assign(manga, mangaData);
        await manga.save();
      } else {
        const slug = await Manga.generateUniqueSlug(title, item.id);
        manga = await Manga.create({ ...mangaData, slug });
      }

      const chapters = await fetchChapters(item.id, 10);
      await sleep(300); // polite delay between manga

      let newChs = 0;
      for (const ch of chapters) {
        const chNum = parseFloat(ch.attributes?.chapter);
        if (Number.isNaN(chNum)) continue;

        const exists = await Chapter.findOne({ manga: manga._id, number: chNum });
        if (exists) continue;

        await sleep(400); // polite delay between page fetches
        const pages = await fetchChapterPages(ch.id);
        if (!pages.length) continue;

        try {
          await Chapter.create({
            manga: manga._id,
            number: chNum,
            title: ch.attributes?.title || `Chapter ${chNum}`,
            pages,
            source: 'mangadex',
            sourceId: ch.id,
            sourceUrl: `https://mangadex.org/chapter/${ch.id}`,
          });
        } catch (chErr) {
          if (chErr.code === 11000) continue; // race-condition duplicate, safe to skip
          throw chErr;
        }

        await Manga.findByIdAndUpdate(manga._id, {
          $inc: { chapterCount: 1 },
          $max: { latestChapter: chNum },
          lastUpdated: new Date(),
        });
        newChs++;
      }

      newChaptersTotal += newChs;
      console.log(`[Scraper] ✓ ${title} — ${newChs} new chapter(s)`);
      ok++;
    } catch (e) {
      console.error('[Scraper] ✗ Error processing manga:', e.message);
      skipped++;
    }
  }

  console.log(`[Scraper] ── Done: ${ok} processed, ${skipped} errors, ${newChaptersTotal} new chapters total ──`);
  return { ok: true, processed: ok, errors: skipped, newChapters: newChaptersTotal };
}

module.exports = { scrapeManga };
