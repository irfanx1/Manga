require('dotenv').config();
const express   = require('express');
const mongoose  = require('mongoose');
const cors      = require('cors');
const helmet    = require('helmet');
const rateLimit = require('express-rate-limit');
const path      = require('path');

const app = express();

// ── Fail fast on missing critical config ─────────────────────────────────────
// A missing/placeholder JWT_SECRET is the #1 cause of "login doesn't work":
// jwt.sign()/jwt.verify() throw synchronously when the secret is undefined,
// which previously surfaced as a generic 500 with no clear explanation.
if (!process.env.JWT_SECRET || process.env.JWT_SECRET.trim().length < 16) {
  console.error('\n✗ FATAL: JWT_SECRET is missing or too short.');
  console.error('  Set a long, random JWT_SECRET in your .env file before starting the server.');
  console.error('  Example: JWT_SECRET=' + require('crypto').randomBytes(32).toString('hex') + '\n');
  process.exit(1);
}

// ── Security middleware ──────────────────────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false, crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({
  origin: process.env.NODE_ENV === 'production'
    ? (process.env.FRONTEND_URL || true)
    : ['http://localhost:3000', 'http://127.0.0.1:3000'],
  credentials: true,
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// ── Rate limiting ────────────────────────────────────────────────────────────
app.use('/api/', rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 500,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: 'Too many requests — please slow down and try again shortly.' },
}));

// Stricter limiter on auth endpoints to slow down credential-stuffing attempts
app.use('/api/auth/login', rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: 'Too many login attempts. Please wait a few minutes and try again.' },
}));

// ── API Routes ───────────────────────────────────────────────────────────────
app.use('/api/auth',  require('./routes/auth'));
app.use('/api/manga', require('./routes/manga'));
app.use('/api/admin', require('./routes/admin'));

// ── Health check ─────────────────────────────────────────────────────────────
app.get('/api/health', (req, res) => res.json({
  status: 'ok',
  time: new Date(),
  dbConnected: mongoose.connection.readyState === 1,
}));

// ── Serve frontend in production ─────────────────────────────────────────────
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '../frontend/build')));
  app.get('*', (req, res) =>
    res.sendFile(path.join(__dirname, '../frontend/build/index.html')));
}

// ── 404 for unmatched API routes ──────────────────────────────────────────────
app.use('/api', (req, res) => res.status(404).json({ message: 'Endpoint not found' }));

// ── Global error handler ─────────────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('[Error]', err.message);
  res.status(err.status || 500).json({ message: err.message || 'Server error' });
});

// ── Connect & boot ───────────────────────────────────────────────────────────
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/mangaflux';

mongoose.connect(MONGODB_URI)
  .then(async () => {
    console.log('✓ MongoDB connected');

    // Ensure default owner account exists
    const User = require('./models/User');
    const ownerExists = await User.findOne({ role: 'owner' });
    if (!ownerExists) {
      const ownerEmail    = process.env.ADMIN_EMAIL    || 'admin@mangaflux.com';
      const ownerPassword = process.env.ADMIN_PASSWORD || 'admin123';
      await User.create({
        username: 'admin',
        email:    ownerEmail,
        password: ownerPassword,
        role: 'owner',
      });
      console.log(`✓ Default owner account created: ${ownerEmail}`);
      if (!process.env.ADMIN_PASSWORD) {
        console.warn('  ⚠ Using default password "admin123" — set ADMIN_PASSWORD in .env and change it after first login.');
      }
    }

    // Start auto-scraper
    if (process.env.AUTO_SCRAPE !== 'false') {
      const ScraperService = require('./services/scraper');
      ScraperService.start();
    } else {
      console.log('[ScraperService] AUTO_SCRAPE=false — skipping auto-start');
    }

    const PORT = process.env.PORT || 5000;
    app.listen(PORT, () => console.log(`✓ Server running on http://localhost:${PORT}`));
  })
  .catch(err => {
    console.error('✗ MongoDB connection failed:', err.message);
    console.error('  Check that MongoDB is running and MONGODB_URI in .env is correct.');
    process.exit(1);
  });

// ── Graceful shutdown ─────────────────────────────────────────────────────────
process.on('SIGINT', async () => {
  console.log('\nShutting down gracefully...');
  await mongoose.connection.close();
  process.exit(0);
});
