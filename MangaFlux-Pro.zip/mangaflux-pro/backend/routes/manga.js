const express = require('express');
const Manga   = require('../models/Manga');
const Chapter = require('../models/Chapter');
const { protect, restrictTo, optionalAuth } = require('../middleware/auth');
const router = express.Router();

// ── List / search manga ──────────────────────────────────────────────────────
router.get('/', optionalAuth, async (req, res) => {
  try {
    const {
      page = 1, limit = 20,
      genre, status, type, sort = '-lastUpdated',
      search, featured, isPremium
    } = req.query;

    const safeLimit = Math.min(Number(limit) || 20, 100);
    const safePage  = Math.max(Number(page) || 1, 1);

    const query = { isPublished: true };
    if (genre)     query.genres  = { $in: [genre] };
    if (status)    query.status  = status;
    if (type)      query.type    = type;
    if (featured)  query.featured   = true;
    if (isPremium) query.isPremium  = isPremium === 'true';
    if (search)    query.$text = { $search: search };

    const [total, manga] = await Promise.all([
      Manga.countDocuments(query),
      Manga.find(query)
        .sort(sort)
        .limit(safeLimit)
        .skip((safePage - 1) * safeLimit)
        .select('title coverImage type status genres rating views bookmarkCount chapterCount latestChapter lastUpdated slug featured isPremium'),
    ]);

    res.json({ manga, total, page: safePage, pages: Math.ceil(total / safeLimit) });
  } catch (err) {
    console.error('[Manga] List error:', err.message);
    res.status(500).json({ message: 'Failed to load manga list' });
  }
});

// ── Single manga by slug ─────────────────────────────────────────────────────
router.get('/:slug', optionalAuth, async (req, res) => {
  try {
    const manga = await Manga.findOne({ slug: req.params.slug, isPublished: true });
    if (!manga) return res.status(404).json({ message: 'Manga not found' });

    Manga.findByIdAndUpdate(manga._id, { $inc: { views: 1 } }).exec().catch(() => {});

    const chapters = await Chapter.find({ manga: manga._id, isPublished: true })
      .sort('-number')
      .select('number title views uploadedAt createdAt');

    res.json({ manga, chapters });
  } catch (err) {
    console.error('[Manga] Detail error:', err.message);
    res.status(500).json({ message: 'Failed to load manga' });
  }
});

// ── Single chapter ───────────────────────────────────────────────────────────
router.get('/:slug/chapter/:number', optionalAuth, async (req, res) => {
  try {
    const manga = await Manga.findOne({ slug: req.params.slug })
      .select('title slug coverImage');
    if (!manga) return res.status(404).json({ message: 'Manga not found' });

    const num = Number(req.params.number);
    if (Number.isNaN(num)) return res.status(400).json({ message: 'Invalid chapter number' });

    const chapter = await Chapter.findOne({ manga: manga._id, number: num });
    if (!chapter) return res.status(404).json({ message: 'Chapter not found' });

    Chapter.findByIdAndUpdate(chapter._id, { $inc: { views: 1 } }).exec().catch(() => {});

    if (req.user) {
      const User = require('../models/User');
      User.findByIdAndUpdate(req.user._id, {
        $push: {
          readHistory: {
            $each: [{ manga: manga._id, chapter: chapter._id, readAt: new Date() }],
            $slice: -200,
          }
        },
        lastSeen: new Date(),
      }).exec().catch(() => {});
    }

    const [prev, next] = await Promise.all([
      Chapter.findOne({ manga: manga._id, number: { $lt: num } }).sort('-number').select('number title'),
      Chapter.findOne({ manga: manga._id, number: { $gt: num } }).sort('number').select('number title'),
    ]);

    res.json({ manga, chapter, prev, next });
  } catch (err) {
    console.error('[Manga] Chapter error:', err.message);
    res.status(500).json({ message: 'Failed to load chapter' });
  }
});

// ── Create manga (admin) ─────────────────────────────────────────────────────
router.post('/', protect, restrictTo('admin', 'owner'), async (req, res) => {
  try {
    if (!req.body.title?.trim()) return res.status(400).json({ message: 'Title is required' });
    const manga = await Manga.create(req.body);
    res.status(201).json({ manga });
  } catch (err) {
    res.status(400).json({ message: err.message || 'Failed to create manga' });
  }
});

// ── Update manga (admin) ─────────────────────────────────────────────────────
router.patch('/:id', protect, restrictTo('admin', 'owner'), async (req, res) => {
  try {
    const manga = await Manga.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!manga) return res.status(404).json({ message: 'Manga not found' });
    res.json({ manga });
  } catch (err) {
    res.status(500).json({ message: err.message || 'Update failed' });
  }
});

// ── Delete manga (admin) ─────────────────────────────────────────────────────
router.delete('/:id', protect, restrictTo('admin', 'owner'), async (req, res) => {
  try {
    const manga = await Manga.findByIdAndDelete(req.params.id);
    if (!manga) return res.status(404).json({ message: 'Manga not found' });
    await Chapter.deleteMany({ manga: req.params.id });
    res.json({ message: 'Deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// ── Add chapter (admin) ──────────────────────────────────────────────────────
router.post('/:id/chapters', protect, restrictTo('admin', 'owner'), async (req, res) => {
  try {
    const chapter = await Chapter.create({ ...req.body, manga: req.params.id });
    await Manga.findByIdAndUpdate(req.params.id, {
      $inc: { chapterCount: 1 },
      $max: { latestChapter: chapter.number },
      lastUpdated: new Date(),
    });
    res.status(201).json({ chapter });
  } catch (err) {
    if (err.code === 11000) return res.status(409).json({ message: 'That chapter number already exists' });
    res.status(400).json({ message: err.message });
  }
});

module.exports = router;
