# ⚡ MangaFlux — Full-Stack Manga Website

A premium, fully-featured manga reading platform with auto-scraping from MangaDex.

---

## 🚀 Setup (2 steps)

### Backend
```bash
cd backend
cp .env.example .env        # edit MONGODB_URI + JWT_SECRET
npm install
npm run dev                 # → http://localhost:5000
```

### Frontend
```bash
cd frontend
npm install
npm start                   # → http://localhost:3000  (proxies /api → :5000)
```

---

## 🔑 First Login (Admin)
- URL: `http://localhost:3000/admin`
- Email: `admin@mangaflux.com`
- Password: `admin123`

> Change these in `.env` before going to production!

---

## 🤖 Scraper — How It Works

The scraper pulls from the **MangaDex public API** (no API key needed).

| | |
|---|---|
| **Source** | MangaDex (api.mangadex.org) |
| **Auto-runs** | On server boot (after 8s) + every 6 hours |
| **Batch** | 25 manga · 10 latest chapters each |
| **Images** | Data-saver CDN (fast, lightweight) |
| **Language** | English |
| **Retry** | 3 retries with backoff on rate-limit |

**To manually trigger:** Admin Panel → Scraper tab → **Run now**

**To disable auto-run:** Set `AUTO_SCRAPE=false` in `.env`

---

## ✨ Features

| Frontend | Backend |
|---|---|
| Dark premium UI (purple/cyan) | MangaDex auto-scraper |
| Hero carousel with auto-cycle | JWT auth + roles |
| Genre marquee ticker | Rate-limit safe API calls |
| Smooth card scroll rows | Read history tracking |
| Skeleton loading states | Bookmark sync |
| Search with debounce | Admin user management |
| Filter by genre/type/status | Featured manga toggle |
| Scroll + Page reader modes | Premium user flag |
| Tap-zone navigation | Health check endpoint |
| Terms of Service page | Auto-create admin on boot |
| Privacy Policy page | Soft delete (isPublished) |
| Premium plans page | |
| Admin dashboard + live scraper status | |
| Bottom nav + Navbar | |
| Auth (register / login) | |

---

## 📁 Project Structure

```
MangaFlux/
├── backend/
│   ├── middleware/auth.js       JWT protect + role restrict
│   ├── models/
│   │   ├── Manga.js             Title, cover, genres, stats
│   │   ├── Chapter.js           Pages, views, source
│   │   └── User.js              Auth, bookmarks, history, premium
│   ├── routes/
│   │   ├── auth.js              Register, login, bookmark, profile
│   │   ├── manga.js             List, search, detail, chapter
│   │   └── admin.js             Stats, users, scraper control
│   ├── scrapers/mangadex.js     MangaDex scraper (retry + rate-limit)
│   ├── services/scraper.js      Cron scheduler + runNow + status
│   ├── server.js                Express + MongoDB boot
│   └── .env.example
└── frontend/src/
    ├── pages/
    │   ├── Home.jsx             Hero, genre marquee, sections
    │   ├── Explore.jsx          Filter grid
    │   ├── Search.jsx           Debounced search
    │   ├── MangaDetail.jsx      Cover, chapters, about
    │   ├── Reader.jsx           Scroll/page modes
    │   ├── Auth.jsx             Login + Register
    │   ├── UserPages.jsx        Library, History, Profile
    │   ├── Admin.jsx            Dashboard, scraper, users
    │   ├── Premium.jsx          Plans + FAQ
    │   └── Terms.jsx            ToS + Privacy
    ├── components/
    │   ├── layout/Navbar.jsx
    │   ├── layout/BottomNav.jsx
    │   └── manga/MangaCard.jsx
    ├── context/AuthContext.jsx
    └── utils/api.js
```
