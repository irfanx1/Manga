import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import './Navbar.css';

export default function Navbar() {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [query, setQuery] = useState('');

  const handleSearch = (e) => {
    e.preventDefault();
    if (query.trim()) navigate(`/search?q=${encodeURIComponent(query.trim())}`);
  };

  const isReader = location.pathname.includes('/chapter/');

  if (isReader) return null;

  return (
    <nav className="navbar">
      <div className="navbar__inner">
        <Link to="/" className="navbar__logo">
          <span className="navbar__logo-icon">⚡</span>
          <span className="navbar__logo-text">Manga<span className="navbar__logo-accent">Flux</span></span>
        </Link>

        <form className="navbar__search" onSubmit={handleSearch}>
          <span className="navbar__search-icon">🔍</span>
          <input
            className="navbar__search-input"
            placeholder="Search manga, manhwa..."
            value={query}
            onChange={e => setQuery(e.target.value)}
          />
        </form>

        <div className="navbar__actions">
          <Link to="/explore" className="navbar__link">Explore</Link>
          {user ? (
            <div className="navbar__user">
              <Link to="/library" className="navbar__link">Library</Link>
              {user.role !== 'user' && <Link to="/admin" className="navbar__link navbar__link--admin">Admin</Link>}
              <button className="navbar__avatar" onClick={logout} title="Sign out">
                {user.avatar
                  ? <img src={user.avatar} alt={user.username} />
                  : <span>{user.username?.[0]?.toUpperCase()}</span>
                }
              </button>
            </div>
          ) : (
            <div className="navbar__auth">
              <Link to="/login" className="btn btn-ghost btn-sm">Log in</Link>
              <Link to="/register" className="btn btn-primary btn-sm">Join free</Link>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}
