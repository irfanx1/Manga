import { Link, useLocation } from 'react-router-dom';
import './BottomNav.css';

const NAV = [
  { to: '/', icon: '🏠', label: 'Home' },
  { to: '/explore', icon: '🧭', label: 'Explore' },
  { to: '/search', icon: '🔍', label: 'Search' },
  { to: '/library', icon: '📚', label: 'Library' },
  { to: '/profile', icon: '👤', label: 'Profile' },
];

export default function BottomNav() {
  const { pathname } = useLocation();
  const isReader = pathname.includes('/chapter/');
  if (isReader) return null;

  return (
    <nav className="bottom-nav">
      {NAV.map(({ to, icon, label }) => {
        const active = to === '/' ? pathname === '/' : pathname.startsWith(to);
        return (
          <Link key={to} to={to} className={`bottom-nav__item ${active ? 'active' : ''}`}>
            <span className="bottom-nav__icon">{icon}</span>
            <span className="bottom-nav__label">{label}</span>
          </Link>
        );
      })}
    </nav>
  );
}
