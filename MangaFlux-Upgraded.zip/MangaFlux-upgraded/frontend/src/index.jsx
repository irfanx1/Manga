import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';

// Remove boot loader once React mounts
const bootLoader = document.querySelector('.boot-loader');
if (bootLoader) bootLoader.style.display = 'none';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
