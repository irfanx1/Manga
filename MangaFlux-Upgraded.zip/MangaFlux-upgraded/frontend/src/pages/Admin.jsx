import { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import './Admin.css';

export default function Admin() {
  const { user, isAdmin } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [tab, setTab] = useState('dashboard');
  const [scraperStatus, setScraperStatus] = useState(null);
  const [scraperRunning, setScraperRunning] = useState(false);
  const [mangaForm, setMangaForm] = useState({
    title:'', description:'', coverImage:'', bannerImage:'',
    type:'manga', status:'ongoing', genres:'', authors:'',
  });
  const [toast, setToast] = useState('');
  const [userSearch, setUserSearch] = useState('');

  const showToast = (msg, dur = 3500) => {
    setToast(msg);
    setTimeout(() => setToast(''), dur);
  };

  const loadStats = useCallback(() =>
    api.get('/admin/stats').then(setStats).catch(() => {}), []);

  const loadScraperStatus = useCallback(() =>
    api.get('/admin/scraper/status').then(setScraperStatus).catch(() => {}), []);

  useEffect(() => {
    if (!isAdmin) { navigate('/'); return; }
    loadStats();
  }, [isAdmin]);

  useEffect(() => {
    if (tab === 'scraper') {
      loadScraperStatus();
      const t = setInterval(loadScraperStatus, 5000);
      return () => clearInterval(t);
    }
    if (tab === 'users') loadUsers(userSearch);
  }, [tab]);

  const loadUsers = (search = '') =>
    api.get(`/admin/users?search=${search}`).then(d => setUsers(d.users || []));

  const toggleScraper = async (val) => {
    await api.post('/admin/scraper/toggle', { enabled: val });
    showToast(val ? '✅ Auto scraper enabled' : '⛔ Auto scraper disabled');
    loadScraperStatus();
  };

  const runScraper = async () => {
    if (scraperRunning) return;
    setScraperRunning(true);
    showToast('🔄 Scraper running in background — check back in ~2 min', 5000);
    try {
      await api.post('/admin/scraper/run', { source: 'mangadex' });
    } catch { showToast('❌ Failed to start scraper'); }
    finally {
      setTimeout(() => { setScraperRunning(false); loadStats(); }, 3000);
    }
  };

  const addManga = async (e) => {
    e.preventDefault();
    try {
      await api.post('/manga', {
        ...mangaForm,
        genres:  mangaForm.genres.split(',').map(g => g.trim()).filter(Boolean),
        authors: mangaForm.authors.split(',').map(a => a.trim()).filter(Boolean),
      });
      showToast('✅ Manga added!');
      setMangaForm({ title:'', description:'', coverImage:'', bannerImage:'', type:'manga', status:'ongoing', genres:'', authors:'' });
      loadStats();
    } catch (err) { showToast('❌ ' + (err?.message || err)); }
  };

  const banUser = async (id, ban) => {
    await api.patch(`/admin/users/${id}/ban`, { isBanned: ban });
    showToast(ban ? '🚫 User banned' : '✅ User unbanned');
    loadUsers(userSearch);
  };

  const setRole = async (id, role) => {
    await api.patch(`/admin/users/${id}/role`, { role });
    showToast('✅ Role updated');
    loadUsers(userSearch);
  };

  const TABS = [
    { id: 'dashboard', label: '📊 Dashboard' },
    { id: 'scraper',   label: '🤖 Scraper'   },
    { id: 'manga',     label: '📚 Add Manga'  },
    { id: 'users',     label: '👥 Users'      },
  ];

  return (
    <div className="page admin-page">
      {toast && <div className="admin-toast">{toast}</div>}

      <div className="admin-head">
        <div className="admin-head__icon">🛡</div>
        <div>
          <h1 className="admin-head__title">Admin Panel</h1>
          <p className="admin-head__sub">
            {user?.role === 'owner' ? '👑 Owner access' : '⚡ Admin access'}
          </p>
        </div>
      </div>

      <div className="admin-tabs">
        {TABS.map(t => (
          <button key={t.id} className={`admin-tab ${tab === t.id ? 'active' : ''}`}
            onClick={() => setTab(t.id)}>
            {t.label}
          </button>
        ))}
      </div>

      {/* ── DASHBOARD ── */}
      {tab === 'dashboard' && (
        <div className="admin-content">
          {stats ? (
            <>
              <div className="admin-stat-grid">
                {[
                  { val: stats.users,       label: 'Total Users',  icon: '👥', color: '#a855f7' },
                  { val: stats.manga,       label: 'Manga Titles', icon: '📚', color: '#06b6d4' },
                  { val: stats.chapters,    label: 'Chapters',     icon: '📖', color: '#10b981' },
                  { val: stats.activeToday, label: 'Active Today', icon: '🔥', color: '#f59e0b' },
                ].map(s => (
                  <div key={s.label} className="admin-stat-card" style={{'--c': s.color}}>
                    <span className="admin-stat-card__icon">{s.icon}</span>
                    <span className="admin-stat-card__val">{(s.val || 0).toLocaleString()}</span>
                    <span className="admin-stat-card__label">{s.label}</span>
                  </div>
                ))}
              </div>

              <div className="admin-section-head">
                <h2 className="admin-section-title">🏆 Top Manga by Views</h2>
                <button className="btn btn-ghost btn-sm" onClick={loadStats}>↻ Refresh</button>
              </div>
              <div className="admin-top-list">
                {(stats.topManga || []).map((m, i) => (
                  <div key={m._id} className="admin-top-item">
                    <span className="admin-top-rank">#{i + 1}</span>
                    {m.coverImage && <img src={m.coverImage} className="admin-top-cover" alt="" />}
                    <span className="admin-top-title">{m.title}</span>
                    <div className="admin-top-meta">
                      <span>👁 {(m.views || 0).toLocaleString()}</span>
                      <span>⭐ {m.rating?.toFixed(1) || 'N/A'}</span>
                    </div>
                  </div>
                ))}
              </div>

              <h2 className="admin-section-title" style={{marginTop:24}}>🆕 Recently Added</h2>
              <div className="admin-top-list">
                {(stats.recentManga || []).map(m => (
                  <div key={m._id} className="admin-top-item">
                    <span className="admin-top-rank" style={{fontSize:12}}>{new Date(m.createdAt).toLocaleDateString()}</span>
                    <span className="admin-top-title">{m.title}</span>
                    <span className="admin-role-badge admin-role-badge--user">{m.source}</span>
                  </div>
                ))}
              </div>
            </>
          ) : <div className="admin-loading"><div className="user-spinner" /></div>}
        </div>
      )}

      {/* ── SCRAPER ── */}
      {tab === 'scraper' && (
        <div className="admin-content">
          <h2 className="admin-section-title">🤖 Auto Scraper</h2>

          {scraperStatus && (
            <div className={`scraper-live-status ${scraperStatus.isRunning ? 'running' : ''}`}>
              <div className="scraper-live-dot" />
              <span>{scraperStatus.isRunning ? 'Scraper is currently running…' : 'Scraper is idle'}</span>
              {scraperStatus.lastRun && (
                <span className="scraper-live-time">
                  Last run: {new Date(scraperStatus.lastRun).toLocaleString()}
                </span>
              )}
            </div>
          )}

          <div className="scraper-card">
            <div className="scraper-source">
              <div className="scraper-source__icon">🌐</div>
              <div className="scraper-source__info">
                <strong>MangaDex API</strong>
                <span>Official API — no key required · rate-limit safe</span>
              </div>
              <span className="scraper-source__status">Active</span>
            </div>

            <div className="divider" />

            <div className="scraper-row">
              <div>
                <div className="scraper-label">Auto-scraping schedule</div>
                <div className="scraper-sub">Fetches top 25 manga every 6 hours + runs once on boot</div>
              </div>
              <button
                className={`toggle ${scraperStatus?.scheduled ? 'on' : ''}`}
                onClick={() => toggleScraper(!scraperStatus?.scheduled)}
              />
            </div>

            <div className="divider" />

            <div className="scraper-row">
              <div>
                <div className="scraper-label">Manual run</div>
                <div className="scraper-sub">Scrape latest content right now (runs in background)</div>
              </div>
              <button
                className="btn btn-primary btn-sm"
                onClick={runScraper}
                disabled={scraperRunning || scraperStatus?.isRunning}
              >
                {scraperRunning || scraperStatus?.isRunning ? '⏳ Running…' : '▶ Run now'}
              </button>
            </div>

            <div className="divider" />

            <div className="scraper-info-grid">
              {[
                ['Source',      'MangaDex (api.mangadex.org)'],
                ['Schedule',    'Every 6 hours via node-cron'],
                ['Batch size',  '25 manga · 10 chapters each'],
                ['Languages',   'English only'],
                ['Content',     'Safe + Suggestive'],
                ['Images',      'Data-saver CDN (faster)'],
                ['Boot scrape', 'Runs automatically 8s after start'],
                ['Retry',       '3 retries on rate-limit / timeout'],
              ].map(([k, v]) => (
                <div key={k} className="scraper-info-item">
                  <span className="scraper-info-key">{k}</span>
                  <span className="scraper-info-val">{v}</span>
                </div>
              ))}
            </div>

            <div className="scraper-tip">
              💡 <strong>First time setup:</strong> Click <em>Run now</em> to populate your database.
              Takes ~1–3 minutes. Check the server console for progress logs.
              {scraperStatus?.lastError && (
                <div style={{marginTop:8,color:'#f87171'}}>
                  ⚠ Last error: {scraperStatus.lastError}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ── ADD MANGA ── */}
      {tab === 'manga' && (
        <div className="admin-content">
          <h2 className="admin-section-title">📚 Add Manga Manually</h2>
          <form onSubmit={addManga} className="admin-form">
            <div className="admin-field">
              <label>Title *</label>
              <input className="input" placeholder="Manga title" required
                value={mangaForm.title} onChange={e => setMangaForm({...mangaForm, title: e.target.value})} />
            </div>
            <div className="admin-field">
              <label>Cover Image URL</label>
              <input className="input" placeholder="https://..." 
                value={mangaForm.coverImage} onChange={e => setMangaForm({...mangaForm, coverImage: e.target.value})} />
            </div>
            <div className="admin-field">
              <label>Banner Image URL (optional)</label>
              <input className="input" placeholder="https://..." 
                value={mangaForm.bannerImage} onChange={e => setMangaForm({...mangaForm, bannerImage: e.target.value})} />
            </div>
            <div className="admin-row">
              <div className="admin-field">
                <label>Type</label>
                <select className="input" value={mangaForm.type}
                  onChange={e => setMangaForm({...mangaForm, type: e.target.value})}>
                  {['manga','manhwa','manhua','webtoon'].map(t => <option key={t}>{t}</option>)}
                </select>
              </div>
              <div className="admin-field">
                <label>Status</label>
                <select className="input" value={mangaForm.status}
                  onChange={e => setMangaForm({...mangaForm, status: e.target.value})}>
                  {['ongoing','completed','hiatus','cancelled'].map(s => <option key={s}>{s}</option>)}
                </select>
              </div>
            </div>
            <div className="admin-field">
              <label>Genres (comma separated)</label>
              <input className="input" placeholder="Action, Fantasy, Romance"
                value={mangaForm.genres} onChange={e => setMangaForm({...mangaForm, genres: e.target.value})} />
            </div>
            <div className="admin-field">
              <label>Authors (comma separated)</label>
              <input className="input" placeholder="Author Name"
                value={mangaForm.authors} onChange={e => setMangaForm({...mangaForm, authors: e.target.value})} />
            </div>
            <div className="admin-field">
              <label>Description</label>
              <textarea className="input" rows={4} placeholder="Brief description…"
                value={mangaForm.description} onChange={e => setMangaForm({...mangaForm, description: e.target.value})} />
            </div>
            <button type="submit" className="btn btn-primary">+ Add Manga</button>
          </form>
        </div>
      )}

      {/* ── USERS ── */}
      {tab === 'users' && (
        <div className="admin-content">
          <div className="admin-section-head">
            <h2 className="admin-section-title">👥 Users ({users.length})</h2>
            <input className="input" style={{width:180,padding:'7px 12px',fontSize:13}}
              placeholder="Search…" value={userSearch}
              onChange={e => { setUserSearch(e.target.value); loadUsers(e.target.value); }} />
          </div>
          {users.length === 0
            ? <div className="admin-loading"><div className="user-spinner" /></div>
            : (
              <div className="admin-user-list">
                {users.map(u => (
                  <div key={u._id} className="admin-user-item">
                    <div className="admin-user-avatar">{u.username?.[0]?.toUpperCase()}</div>
                    <div className="admin-user-info">
                      <div className="admin-user-name">
                        {u.username}
                        <span className={`admin-role-badge admin-role-badge--${u.role}`}>{u.role}</span>
                        {u.isBanned && <span className="admin-role-badge admin-role-badge--banned">banned</span>}
                        {u.isPremium && <span className="admin-role-badge" style={{background:'rgba(245,158,11,0.1)',color:'#f59e0b'}}>premium</span>}
                      </div>
                      <div className="admin-user-email">{u.email}</div>
                    </div>
                    {u.role !== 'owner' && (
                      <div className="admin-user-actions">
                        <button
                          className={`btn btn-sm ${u.isBanned ? 'btn-primary' : 'btn-ghost'}`}
                          onClick={() => banUser(u._id, !u.isBanned)}
                          style={!u.isBanned ? {color:'#ef4444',borderColor:'rgba(239,68,68,0.3)'} : {}}
                        >
                          {u.isBanned ? 'Unban' : 'Ban'}
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )
          }
        </div>
      )}
    </div>
  );
}
