import { useEffect, useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import api from '../utils/api';
import MangaCard, { MangaCardSkeleton } from '../components/manga/MangaCard';
import './Home.css';

const GENRES = ['Action','Adventure','Romance','Fantasy','Horror','Comedy','Drama','Mystery','Sci-Fi','Slice of Life','Sports','Isekai','Shounen','Seinen','Psychological','Supernatural'];
const FEATURED_TAGS = ['🔥 Trending','⭐ Top Rated','🆕 Latest Update','🏆 All-Time'];

export default function Home() {
  const [featured, setFeatured] = useState(null);
  const [trending, setTrending] = useState([]);
  const [latest, setLatest] = useState([]);
  const [manhwa, setManhwa] = useState([]);
  const [topRated, setTopRated] = useState([]);
  const [activeTab, setActiveTab] = useState('foryou');
  const [loading, setLoading] = useState(true);
  const [heroIdx, setHeroIdx] = useState(0);
  const [heroItems, setHeroItems] = useState([]);
  const heroRef = useRef(null);

  useEffect(() => {
    Promise.all([
      api.get('/manga?featured=true&limit=5'),
      api.get('/manga?sort=-views&limit=12'),
      api.get('/manga?sort=-lastUpdated&limit=12'),
      api.get('/manga?type=manhwa&limit=12'),
      api.get('/manga?sort=-rating&limit=12'),
    ]).then(([feat, trend, lat, mh, top]) => {
      const heroes = feat.manga?.length ? feat.manga : trend.manga?.slice(0,5) || [];
      setHeroItems(heroes);
      setFeatured(heroes[0]);
      setTrending(trend.manga || []);
      setLatest(lat.manga || []);
      setManhwa(mh.manga || []);
      setTopRated(top.manga || []);
    }).finally(() => setLoading(false));
  }, []);

  // Auto-cycle hero
  useEffect(() => {
    if (heroItems.length < 2) return;
    const t = setInterval(() => {
      setHeroIdx(i => {
        const next = (i + 1) % heroItems.length;
        setFeatured(heroItems[next]);
        return next;
      });
    }, 5000);
    return () => clearInterval(t);
  }, [heroItems]);

  const goHero = (i) => { setHeroIdx(i); setFeatured(heroItems[i]); };

  return (
    <div className="page home-page">
      {/* ── HERO ── */}
      <div className="hero" ref={heroRef}>
        <div
          className="hero__bg"
          style={featured?.bannerImage || featured?.coverImage
            ? { backgroundImage: `url(${featured.bannerImage || featured.coverImage})` }
            : {}
          }
        />
        <div className="hero__gradient" />
        <div className="hero__noise" />

        <div className="hero__content">
          <div className="hero__left fade-in-up">
            {loading ? (
              <HeroSkeleton />
            ) : featured ? (
              <>
                <div className="hero__tags">
                  <span className="badge badge-featured">Featured</span>
                  {featured.type && <span className="hero__type-tag">{featured.type}</span>}
                </div>
                <h1 className="hero__title">{featured.title}</h1>
                <p className="hero__desc">{featured.description?.slice(0,160)}{featured.description?.length > 160 ? '…' : ''}</p>
                <div className="hero__stats">
                  <span className="hero__stat">📖 Ch.{featured.latestChapter || '?'}</span>
                  <span className="hero__stat">⭐ {featured.rating > 0 ? featured.rating.toFixed(1) : 'N/A'}</span>
                  <span className={`hero__stat status-${featured.status}`}>
                    ● {featured.status}
                  </span>
                </div>
                <div className="hero__btns">
                  <Link to={`/manga/${featured.slug}`} className="btn btn-primary">
                    ▶ Read now
                  </Link>
                  <Link to={`/manga/${featured.slug}`} className="btn btn-ghost">
                    ℹ Details
                  </Link>
                </div>
              </>
            ) : (
              <div className="hero__empty">
                <p style={{color:'var(--text-secondary)',fontSize:15}}>No manga yet — run the scraper in Admin to populate content.</p>
                <Link to="/admin" className="btn btn-primary" style={{marginTop:12}}>Go to Admin →</Link>
              </div>
            )}
          </div>

          <div className="hero__right">
            {featured?.coverImage && (
              <div className="hero__cover-wrap">
                <img src={featured.coverImage} alt={featured.title} className="hero__cover-img" />
                <div className="hero__cover-glow" />
              </div>
            )}
          </div>
        </div>

        {/* Dots */}
        {heroItems.length > 1 && (
          <div className="hero__dots">
            {heroItems.map((_, i) => (
              <button key={i} className={`hero__dot ${i === heroIdx ? 'active' : ''}`} onClick={() => goHero(i)} />
            ))}
          </div>
        )}

        {/* Thumbnail strip */}
        {heroItems.length > 1 && (
          <div className="hero__strip">
            {heroItems.map((m, i) => (
              <button key={m._id} className={`hero__strip-item ${i === heroIdx ? 'active' : ''}`} onClick={() => goHero(i)}>
                {m.coverImage && <img src={m.coverImage} alt={m.title} />}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* ── MARQUEE GENRES ── */}
      <div className="genre-marquee-wrap">
        <div className="genre-marquee">
          {[...GENRES, ...GENRES].map((g, i) => (
            <Link key={i} to={`/explore?genre=${g}`} className="genre-marquee__pill">
              {g}
            </Link>
          ))}
        </div>
      </div>

      {/* ── TABS ── */}
      <div className="tabs-bar">
        {['foryou','trending','new','genres'].map(t => (
          <button
            key={t}
            className={`tab-btn ${activeTab === t ? 'active' : ''}`}
            onClick={() => setActiveTab(t)}
          >
            {t === 'foryou' ? '✨ For You' : t === 'trending' ? '🔥 Trending' : t === 'new' ? '🆕 New' : '🏷 Genres'}
          </button>
        ))}
      </div>

      {activeTab === 'genres' ? (
        <div className="genres-grid">
          {GENRES.map(g => (
            <Link key={g} to={`/explore?genre=${g}`} className="genre-card">
              <span className="genre-card__name">{g}</span>
              <span className="genre-card__arrow">→</span>
            </Link>
          ))}
        </div>
      ) : activeTab === 'trending' ? (
        <ScrollSection title="🔥 Trending Now" eyebrow="Most Popular" link="/explore" items={trending} loading={loading} />
      ) : activeTab === 'new' ? (
        <ScrollSection title="🆕 Latest Updates" eyebrow="Fresh Releases" link="/explore" items={latest} loading={loading} />
      ) : (
        <>
          <ScrollSection title="Continue Reading" eyebrow="Your History" link="/history" items={latest.slice(0,8)} loading={loading} />
          <ScrollSection title="🔥 Trending Now" eyebrow="Most Viewed" link="/trending" items={trending.slice(0,8)} loading={loading} />
          <ScrollSection title="⭐ Top Rated" eyebrow="Highest Rated" link="/explore" items={topRated.slice(0,8)} loading={loading} />
          <ScrollSection title="Popular Manhwa" eyebrow="Korean Webtoons" link="/explore?type=manhwa" items={manhwa.slice(0,8)} loading={loading} />

          {/* ── PREMIUM BANNER ── */}
          <div className="premium-banner">
            <div className="premium-banner__glow" />
            <div className="premium-banner__content">
              <div className="premium-banner__left">
                <span className="badge badge-premium">✦ Premium</span>
                <h3 className="premium-banner__title">Read ad-free, faster</h3>
                <p className="premium-banner__sub">Unlock all chapters, HD quality, offline reading & exclusive manhwa.</p>
                <Link to="/premium" className="btn btn-primary" style={{marginTop:14}}>
                  Upgrade — Free Trial →
                </Link>
              </div>
              <div className="premium-banner__perks">
                {['✓ Ad-free reading','✓ HD chapter images','✓ Offline mode','✓ Early access','✓ 1000+ exclusives'].map(p => (
                  <span key={p} className="premium-banner__perk">{p}</span>
                ))}
              </div>
            </div>
          </div>

          {/* ── QUICK STATS ── */}
          <div className="quick-stats">
            {[
              { n: '10,000+', l: 'Titles' },
              { n: '500K+', l: 'Chapters' },
              { n: '2M+', l: 'Readers' },
              { n: 'Daily', l: 'Updates' },
            ].map(({ n, l }) => (
              <div key={l} className="quick-stat">
                <span className="quick-stat__num">{n}</span>
                <span className="quick-stat__label">{l}</span>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

function ScrollSection({ title, eyebrow, link, items, loading }) {
  const ref = useRef(null);
  const scroll = (dir) => {
    if (ref.current) ref.current.scrollBy({ left: dir * 200, behavior: 'smooth' });
  };

  return (
    <section className="scroll-section">
      <div className="scroll-section__head">
        <div>
          <p className="section-eyebrow">{eyebrow}</p>
          <h2 className="section-title">{title}</h2>
        </div>
        <div className="scroll-section__actions">
          <button className="scroll-btn" onClick={() => scroll(-1)}>‹</button>
          <button className="scroll-btn" onClick={() => scroll(1)}>›</button>
          <Link to={link} className="see-all-btn">See all →</Link>
        </div>
      </div>
      <div className="manga-scroll-track" ref={ref}>
        {loading
          ? Array(6).fill(0).map((_, i) => <MangaCardSkeleton key={i} />)
          : items.map(m => <MangaCard key={m._id} manga={m} />)
        }
      </div>
    </section>
  );
}

function HeroSkeleton() {
  return (
    <div style={{display:'flex',flexDirection:'column',gap:12}}>
      <div className="skeleton" style={{height:22,width:90,borderRadius:6}} />
      <div className="skeleton" style={{height:40,width:'80%',borderRadius:8}} />
      <div className="skeleton" style={{height:16,width:'100%',borderRadius:6}} />
      <div className="skeleton" style={{height:16,width:'70%',borderRadius:6}} />
      <div style={{display:'flex',gap:10,marginTop:8}}>
        <div className="skeleton" style={{height:42,width:130,borderRadius:12}} />
        <div className="skeleton" style={{height:42,width:100,borderRadius:12}} />
      </div>
    </div>
  );
}
