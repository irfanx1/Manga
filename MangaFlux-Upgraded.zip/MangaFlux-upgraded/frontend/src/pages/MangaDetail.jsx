import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import './MangaDetail.css';

export default function MangaDetail() {
  const { slug } = useParams();
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [bookmarked, setBookmarked] = useState(false);
  const [showAll, setShowAll] = useState(false);
  const [activeTab, setActiveTab] = useState('chapters');

  useEffect(() => {
    setLoading(true);
    api.get(`/manga/${slug}`).then(d => {
      setData(d);
      if (user) setBookmarked(user.bookmarks?.includes(d.manga._id));
    }).finally(() => setLoading(false));
  }, [slug]);

  const toggleBookmark = async () => {
    if (!user) return;
    const res = await api.post(`/auth/bookmark/${data.manga._id}`);
    setBookmarked(res.bookmarked);
  };

  if (loading) return (
    <div className="page detail-page">
      <div className="detail-banner skeleton" style={{height:220}} />
      <div className="detail-header">
        <div className="detail-cover skeleton" style={{width:110,height:158}} />
        <div style={{flex:1,display:'flex',flexDirection:'column',gap:10}}>
          <div className="skeleton" style={{height:28,width:'80%',borderRadius:6}} />
          <div className="skeleton" style={{height:14,width:'50%',borderRadius:4}} />
          <div className="skeleton" style={{height:14,width:'60%',borderRadius:4}} />
        </div>
      </div>
    </div>
  );
  if (!data) return <div className="page" style={{paddingTop:120,textAlign:'center'}}>Manga not found</div>;

  const { manga, chapters } = data;
  const displayChapters = showAll ? chapters : chapters.slice(0, 25);
  const firstCh = chapters[chapters.length - 1];
  const latestCh = chapters[0];

  return (
    <div className="page detail-page">
      {/* ── BANNER ── */}
      <div className="detail-banner" style={(manga.bannerImage || manga.coverImage) ? {backgroundImage:`url(${manga.bannerImage || manga.coverImage})`} : {}}>
        <div className="detail-banner__overlay" />
      </div>

      {/* ── HEADER ── */}
      <div className="detail-header">
        <div className="detail-cover">
          {manga.coverImage
            ? <img src={manga.coverImage} alt={manga.title} />
            : <div className="detail-cover-placeholder">{manga.title[0]}</div>
          }
        </div>
        <div className="detail-meta">
          <div className="detail-tags">
            <span className={`badge badge-${manga.status === 'completed' ? 'completed' : manga.status === 'hiatus' ? 'hot' : 'new'}`}>{manga.status}</span>
            <span className="hero__type-tag">{manga.type}</span>
          </div>
          <h1 className="detail-title">{manga.title}</h1>
          {manga.authors?.length > 0 && (
            <p className="detail-author">by {manga.authors.join(', ')}</p>
          )}
          <div className="detail-stats-row">
            <div className="detail-stat"><span>⭐</span>{manga.rating > 0 ? manga.rating.toFixed(1) : 'N/A'}</div>
            <div className="detail-stat"><span>👁</span>{(manga.views || 0).toLocaleString()}</div>
            <div className="detail-stat"><span>📖</span>{manga.chapterCount || 0} ch</div>
          </div>
          <div className="detail-actions">
            {firstCh && <Link to={`/manga/${slug}/chapter/${firstCh.number}`} className="btn btn-primary">▶ Start Reading</Link>}
            {latestCh && latestCh !== firstCh && <Link to={`/manga/${slug}/chapter/${latestCh.number}`} className="btn btn-ghost">⏭ Latest</Link>}
            <button className={`btn btn-ghost bookmark-btn ${bookmarked ? 'active' : ''}`} onClick={toggleBookmark}>
              {bookmarked ? '❤️' : '🤍'}
            </button>
          </div>
        </div>
      </div>

      {/* ── GENRES ── */}
      <div className="detail-genres">
        {manga.genres?.map(g => <Link key={g} to={`/explore?genre=${g}`} className="genre-tag">{g}</Link>)}
      </div>

      {/* ── TABS ── */}
      <div className="detail-tabs">
        {['chapters','about'].map(t => (
          <button key={t} className={`detail-tab ${activeTab === t ? 'active' : ''}`} onClick={() => setActiveTab(t)}>
            {t === 'chapters' ? `📖 Chapters (${chapters.length})` : 'ℹ About'}
          </button>
        ))}
      </div>

      {activeTab === 'about' ? (
        <div className="detail-about">
          {manga.description && <p className="detail-desc">{manga.description}</p>}
          <div className="detail-info-grid">
            {[
              ['Type', manga.type],
              ['Status', manga.status],
              ['Source', manga.source || 'Manual'],
              ['Updated', manga.lastUpdated ? new Date(manga.lastUpdated).toLocaleDateString() : '-'],
            ].map(([k, v]) => (
              <div key={k} className="detail-info-item">
                <span className="detail-info-label">{k}</span>
                <span className="detail-info-value">{v}</span>
              </div>
            ))}
          </div>
          {manga.sourceUrl && (
            <a href={manga.sourceUrl} target="_blank" rel="noopener noreferrer" className="btn btn-ghost btn-sm" style={{marginTop:16}}>
              View source ↗
            </a>
          )}
        </div>
      ) : (
        <div className="chapter-list-wrap">
          <div className="chapter-list">
            {displayChapters.map(ch => (
              <Link key={ch._id} to={`/manga/${slug}/chapter/${ch.number}`} className="chapter-item">
                <div className="chapter-item__left">
                  <span className="chapter-item__num">Chapter {ch.number}</span>
                  {ch.title && <span className="chapter-item__title">{ch.title}</span>}
                </div>
                <div className="chapter-item__right">
                  <span className="chapter-item__date">{new Date(ch.uploadedAt || ch.createdAt).toLocaleDateString()}</span>
                  <span className="chapter-item__arrow">›</span>
                </div>
              </Link>
            ))}
          </div>
          {chapters.length > 25 && (
            <button className="btn btn-ghost load-more-btn" onClick={() => setShowAll(!showAll)}>
              {showAll ? '▲ Show less' : `▼ Show all ${chapters.length} chapters`}
            </button>
          )}
          {chapters.length === 0 && (
            <div className="no-chapters">
              <span>📭</span>
              <p>No chapters yet. Check back soon!</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
