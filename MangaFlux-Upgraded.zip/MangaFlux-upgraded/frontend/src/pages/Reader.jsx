import { useEffect, useState, useRef, useCallback } from 'react';
import { useParams, Link } from 'react-router-dom';
import api from '../utils/api';
import './Reader.css';

export default function Reader() {
  const { slug, number } = useParams();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [uiVisible, setUiVisible] = useState(true);
  const [mode, setMode] = useState(() => localStorage.getItem('reader_mode') || 'scroll');
  const [currentPage, setCurrentPage] = useState(0);
  const [loadedImages, setLoadedImages] = useState({});
  const hideTimer = useRef(null);
  const containerRef = useRef(null);

  useEffect(() => {
    setLoading(true);
    setCurrentPage(0);
    api.get(`/manga/${slug}/chapter/${number}`).then(setData).finally(() => setLoading(false));
  }, [slug, number]);

  const showUI = useCallback(() => {
    setUiVisible(true);
    clearTimeout(hideTimer.current);
    hideTimer.current = setTimeout(() => setUiVisible(false), 3500);
  }, []);

  useEffect(() => {
    showUI();
    return () => clearTimeout(hideTimer.current);
  }, []);

  const toggleMode = () => {
    const next = mode === 'scroll' ? 'page' : 'scroll';
    setMode(next);
    localStorage.setItem('reader_mode', next);
  };

  if (loading) return (
    <div className="reader-loading">
      <div className="reader-loading__ring" />
      <p>Loading chapter...</p>
    </div>
  );
  if (!data) return <div className="reader-error">Chapter not found.</div>;

  const { manga, chapter, prev, next } = data;
  const pages = chapter.pages || [];

  return (
    <div className="reader" onClick={showUI} onTouchStart={showUI}>
      {/* ── TOP BAR ── */}
      <div className={`reader-topbar ${uiVisible ? 'visible' : ''}`}>
        <Link to={`/manga/${slug}`} className="reader-back" onClick={e => e.stopPropagation()}>
          ‹
        </Link>
        <div className="reader-info">
          <div className="reader-manga-title">{manga.title}</div>
          <div className="reader-ch-title">Chapter {chapter.number}{chapter.title ? ` · ${chapter.title}` : ''}</div>
        </div>
        <div className="reader-controls" onClick={e => e.stopPropagation()}>
          <button className="reader-ctrl-btn" onClick={toggleMode} title="Toggle reading mode">
            {mode === 'scroll' ? '📄' : '📜'}
          </button>
        </div>
      </div>

      {/* ── PAGES ── */}
      {mode === 'scroll' ? (
        <div className="reader-scroll-container" ref={containerRef}>
          {pages.length > 0 ? (
            pages.map((p, i) => (
              <div key={i} className="reader-page">
                {!loadedImages[i] && <div className="reader-page__skeleton skeleton" />}
                <img
                  src={p.imageUrl}
                  alt={`Page ${p.pageNumber}`}
                  loading="lazy"
                  onLoad={() => setLoadedImages(l => ({...l, [i]: true}))}
                  style={loadedImages[i] ? {} : {opacity:0, position:'absolute'}}
                />
              </div>
            ))
          ) : (
            <div className="reader-no-pages">
              <span>📭</span>
              <h3>No pages available</h3>
              <p>Pages may still be fetching from source. Try again in a moment.</p>
            </div>
          )}
          {next && (
            <div className="reader-next-prompt" onClick={e => e.stopPropagation()}>
              <p className="reader-next-prompt__label">End of Chapter {chapter.number}</p>
              <Link to={`/manga/${slug}/chapter/${next.number}`} className="btn btn-primary">
                Next Chapter →
              </Link>
            </div>
          )}
        </div>
      ) : (
        <div className="reader-paged-container">
          {pages[currentPage] ? (
            <img
              src={pages[currentPage].imageUrl}
              alt={`Page ${currentPage + 1}`}
              className="reader-single-img"
            />
          ) : (
            <div className="reader-no-pages"><span>📭</span><p>No pages</p></div>
          )}
          <div className="reader-page-tap-zones" onClick={e => e.stopPropagation()}>
            <button className="reader-tap-left" onClick={() => setCurrentPage(p => Math.max(0, p - 1))} />
            <button className="reader-tap-right" onClick={() => setCurrentPage(p => Math.min(pages.length - 1, p + 1))} />
          </div>
        </div>
      )}

      {/* ── BOTTOM BAR ── */}
      <div className={`reader-bottombar ${uiVisible ? 'visible' : ''}`} onClick={e => e.stopPropagation()}>
        <div className="reader-nav-row">
          {prev
            ? <Link to={`/manga/${slug}/chapter/${prev.number}`} className="btn btn-ghost btn-sm">← Ch.{prev.number}</Link>
            : <span />
          }
          {mode === 'page' && pages.length > 0 && (
            <div className="reader-page-counter">
              <span className="reader-page-current">{currentPage + 1}</span>
              <span className="reader-page-sep">/</span>
              <span className="reader-page-total">{pages.length}</span>
            </div>
          )}
          {next
            ? <Link to={`/manga/${slug}/chapter/${next.number}`} className="btn btn-ghost btn-sm">Ch.{next.number} →</Link>
            : <span />
          }
        </div>
        {mode === 'page' && pages.length > 1 && (
          <input
            type="range" min={0} max={pages.length - 1} value={currentPage}
            onChange={e => setCurrentPage(Number(e.target.value))}
            className="reader-scrubber"
          />
        )}
      </div>
    </div>
  );
}
