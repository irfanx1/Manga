import { useEffect, useState, useRef } from 'react';
import { useSearchParams } from 'react-router-dom';
import api from '../utils/api';
import MangaCard, { MangaCardSkeleton } from '../components/manga/MangaCard';
import './Search.css';

const POPULAR = ['Solo Leveling','Attack on Titan','Jujutsu Kaisen','One Piece','Demon Slayer','Chainsaw Man','Tower of God','Naruto','Bleach','Vinland Saga'];

export default function Search() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [query, setQuery] = useState(searchParams.get('q') || '');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const inputRef = useRef(null);
  const debounceRef = useRef(null);

  useEffect(() => { inputRef.current?.focus(); }, []);

  useEffect(() => {
    const q = searchParams.get('q');
    if (q) { setQuery(q); doSearch(q); }
  }, [searchParams]);

  const doSearch = async (q) => {
    if (!q?.trim()) return;
    setLoading(true); setSearched(true);
    try {
      const data = await api.get(`/manga?search=${encodeURIComponent(q)}&limit=24`);
      setResults(data.manga || []);
    } finally { setLoading(false); }
  };

  const handleInput = (val) => {
    setQuery(val);
    clearTimeout(debounceRef.current);
    if (val.trim().length >= 2) {
      debounceRef.current = setTimeout(() => { setSearchParams({ q: val }); doSearch(val); }, 420);
    } else { setResults([]); setSearched(false); }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (query.trim()) { setSearchParams({ q: query }); doSearch(query); }
  };

  const clear = () => { setQuery(''); setResults([]); setSearched(false); inputRef.current?.focus(); };

  return (
    <div className="page search-page">
      <div className="search-header">
        <form onSubmit={handleSubmit} className="search-form">
          <div className="search-input-wrap">
            <span className="search-icon-txt">🔍</span>
            <input
              ref={inputRef}
              className="search-input"
              placeholder="Title, author, genre..."
              value={query}
              onChange={e => handleInput(e.target.value)}
              autoComplete="off"
            />
            {query && (
              <button type="button" className="search-clear-btn" onClick={clear}>✕</button>
            )}
          </div>
        </form>
      </div>

      {!searched && (
        <div className="search-popular">
          <p className="search-section-label">🔥 Popular searches</p>
          <div className="search-chips">
            {POPULAR.map(s => (
              <button
                key={s}
                className="search-chip"
                onClick={() => { setQuery(s); setSearchParams({ q: s }); doSearch(s); }}
              >{s}</button>
            ))}
          </div>
        </div>
      )}

      {loading && (
        <div className="search-grid">
          {Array(8).fill(0).map((_, i) => <MangaCardSkeleton key={i} />)}
        </div>
      )}

      {!loading && searched && (
        results.length > 0 ? (
          <>
            <div className="search-result-meta">
              {results.length} result{results.length !== 1 ? 's' : ''} for "<strong>{query}</strong>"
            </div>
            <div className="search-grid">
              {results.map(m => <MangaCard key={m._id} manga={m} />)}
            </div>
          </>
        ) : (
          <div className="search-empty">
            <span>😔</span>
            <h3>No results for "{query}"</h3>
            <p>Try a different title or spelling</p>
          </div>
        )
      )}
    </div>
  );
}
