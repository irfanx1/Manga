import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import './Auth.css';

export function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const from = location.state?.from || '/';

  const handleSubmit = async (e) => {
    e.preventDefault(); setError(''); setLoading(true);
    try { await login(email, password); navigate(from); }
    catch (err) { setError(typeof err === 'string' ? err : 'Login failed. Check your credentials.'); }
    finally { setLoading(false); }
  };

  return (
    <div className="auth-page">
      <div className="auth-glow auth-glow--left" />
      <div className="auth-glow auth-glow--right" />
      <div className="auth-card">
        <Link to="/" className="auth-logo">⚡ Manga<span>Flux</span></Link>
        <h1 className="auth-title">Welcome back</h1>
        <p className="auth-sub">Sign in to continue your reading journey</p>
        {error && <div className="auth-error">⚠ {error}</div>}
        <form onSubmit={handleSubmit} className="auth-form">
          <div className="auth-field">
            <label className="auth-label">Email</label>
            <input className="input" type="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} required />
          </div>
          <div className="auth-field">
            <label className="auth-label">Password</label>
            <div className="auth-pass-wrap">
              <input className="input" type={showPass ? 'text' : 'password'} placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} required />
              <button type="button" className="auth-pass-toggle" onClick={() => setShowPass(s => !s)}>{showPass ? '🙈' : '👁'}</button>
            </div>
          </div>
          <button type="submit" className="btn btn-primary auth-submit" disabled={loading}>
            {loading ? <span className="auth-spinner" /> : 'Sign in →'}
          </button>
        </form>
        <div className="auth-divider"><span>or</span></div>
        <p className="auth-switch">New to MangaFlux? <Link to="/register">Create account</Link></p>
        <p className="auth-terms">By signing in, you agree to our <Link to="/terms">Terms</Link> & <Link to="/privacy">Privacy Policy</Link></p>
      </div>
    </div>
  );
}

export function Register() {
  const [form, setForm] = useState({ username: '', email: '', password: '' });
  const [showPass, setShowPass] = useState(false);
  const [agreed, setAgreed] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { register } = useAuth();
  const navigate = useNavigate();

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!agreed) { setError('Please accept the terms to continue.'); return; }
    setError(''); setLoading(true);
    try { await register(form.username, form.email, form.password); navigate('/'); }
    catch (err) { setError(typeof err === 'string' ? err : 'Registration failed.'); }
    finally { setLoading(false); }
  };

  return (
    <div className="auth-page">
      <div className="auth-glow auth-glow--left" />
      <div className="auth-glow auth-glow--right" />
      <div className="auth-card">
        <Link to="/" className="auth-logo">⚡ Manga<span>Flux</span></Link>
        <h1 className="auth-title">Create account</h1>
        <p className="auth-sub">Join millions of manga readers today — free forever</p>
        {error && <div className="auth-error">⚠ {error}</div>}
        <form onSubmit={handleSubmit} className="auth-form">
          <div className="auth-field">
            <label className="auth-label">Username</label>
            <input className="input" placeholder="yourname" value={form.username} onChange={e => set('username', e.target.value)} required minLength={3} />
          </div>
          <div className="auth-field">
            <label className="auth-label">Email</label>
            <input className="input" type="email" placeholder="you@example.com" value={form.email} onChange={e => set('email', e.target.value)} required />
          </div>
          <div className="auth-field">
            <label className="auth-label">Password</label>
            <div className="auth-pass-wrap">
              <input className="input" type={showPass ? 'text' : 'password'} placeholder="Min 6 characters" value={form.password} onChange={e => set('password', e.target.value)} required minLength={6} />
              <button type="button" className="auth-pass-toggle" onClick={() => setShowPass(s => !s)}>{showPass ? '🙈' : '👁'}</button>
            </div>
          </div>
          <label className="auth-agree">
            <input type="checkbox" checked={agreed} onChange={e => setAgreed(e.target.checked)} />
            <span>I agree to the <Link to="/terms" target="_blank">Terms of Service</Link> and <Link to="/privacy" target="_blank">Privacy Policy</Link></span>
          </label>
          <button type="submit" className="btn btn-primary auth-submit" disabled={loading || !agreed}>
            {loading ? <span className="auth-spinner" /> : 'Create account →'}
          </button>
        </form>
        <div className="auth-divider"><span>or</span></div>
        <p className="auth-switch">Already have an account? <Link to="/login">Sign in</Link></p>
      </div>
    </div>
  );
}
