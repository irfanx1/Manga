import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from '../utils/api';
import './UserPages.css';
import { useAuth } from '../context/AuthContext';
import MangaCard from '../components/manga/MangaCard';

/* ── Shared layout wrapper ── */
function PageShell({ title, icon, sub, children }) {
  return (
    <div className="page user-page">
      <div className="user-page-header">
        <span className="user-page-icon">{icon}</span>
        <div>
          <h1 className="user-page-title">{title}</h1>
          {sub && <p className="user-page-sub">{sub}</p>}
        </div>
      </div>
      {children}
    </div>
  );
}

/* ── Library ── */
export function Library() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [manga, setManga] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) { navigate('/login'); return; }
    if (!user.bookmarks?.length) { setLoading(false); return; }
    // Fetch all bookmarked manga
    api.get(`/manga?limit=100`).then(data => {
      const bookmarkedIds = new Set(user.bookmarks.map(String));
      setManga((data.manga || []).filter(m => bookmarkedIds.has(String(m._id))));
    }).finally(() => setLoading(false));
  }, [user]);

  if (!user) return null;
  return (
    <PageShell title="My Library" icon="❤️" sub={`${manga.length} saved titles`}>
      {loading ? (
        <div className="user-loading"><div className="user-spinner" /></div>
      ) : manga.length === 0 ? (
        <div className="user-empty">
          <span>🤍</span>
          <h3>Nothing saved yet</h3>
          <p>Bookmark manga from any page to build your library</p>
          <Link to="/explore" className="btn btn-primary">Discover manga</Link>
        </div>
      ) : (
        <div className="user-grid">
          {manga.map(m => <MangaCard key={m._id} manga={m} />)}
        </div>
      )}
    </PageShell>
  );
}

/* ── History ── */
export function History() {
  const { user } = useAuth();
  const navigate = useNavigate();
  useEffect(() => { if (!user) navigate('/login'); }, [user]);
  if (!user) return null;
  const history = [...(user.readHistory || [])].reverse();

  return (
    <PageShell title="Reading History" icon="🕐" sub={`${history.length} entries`}>
      {history.length === 0 ? (
        <div className="user-empty">
          <span>📖</span>
          <h3>No history yet</h3>
          <p>Start reading to track your progress</p>
          <Link to="/" className="btn btn-primary">Browse manga</Link>
        </div>
      ) : (
        <div className="history-list">
          {history.map((h, i) => (
            <div key={i} className="history-item">
              <div className="history-item__icon">📖</div>
              <div className="history-item__info">
                <div className="history-item__ch">Chapter {h.chapter?.number || '?'}</div>
                <div className="history-item__date">{new Date(h.readAt).toLocaleString()}</div>
              </div>
              {h.chapter?.number && (
                <span className="history-item__page">p.{h.page || 1}</span>
              )}
            </div>
          ))}
        </div>
      )}
    </PageShell>
  );
}

/* ── Profile ── */
export function Profile() {
  const { user, logout, isAdmin } = useAuth();
  const navigate = useNavigate();
  useEffect(() => { if (!user) navigate('/login'); }, [user]);
  if (!user) return null;

  const daysJoined = Math.floor((Date.now() - new Date(user.createdAt)) / 86400000);
  const roleColor = { owner: '#fbbf24', admin: '#a855f7', user: '#10b981' }[user.role] || '#10b981';
  const roleLabel = { owner: '👑 Owner', admin: '⚡ Admin', user: '🌟 Member' }[user.role] || 'Member';

  return (
    <div className="page user-page">
      {/* Header */}
      <div className="profile-header">
        <div className="profile-avatar">
          {user.avatar
            ? <img src={user.avatar} alt={user.username} />
            : <span>{user.username[0].toUpperCase()}</span>
          }
        </div>
        <div className="profile-info">
          <h1 className="profile-name">{user.username}</h1>
          <p className="profile-email">{user.email}</p>
          <span className="profile-role" style={{ color: roleColor, background: `${roleColor}20`, borderColor: `${roleColor}40` }}>
            {roleLabel}
          </span>
        </div>
      </div>

      {/* Stats */}
      <div className="profile-stats">
        {[
          { val: user.bookmarks?.length || 0, label: 'Bookmarks', icon: '❤️' },
          { val: user.readHistory?.length || 0, label: 'Chapters Read', icon: '📖' },
          { val: daysJoined, label: 'Days', icon: '📅' },
        ].map(s => (
          <div key={s.label} className="profile-stat">
            <span className="profile-stat__icon">{s.icon}</span>
            <span className="profile-stat__val">{s.val.toLocaleString()}</span>
            <span className="profile-stat__label">{s.label}</span>
          </div>
        ))}
      </div>

      {/* Menu */}
      <div className="profile-menu">
        {[
          { icon: '❤️', label: 'My Library', sub: 'Saved manga & bookmarks', to: '/library' },
          { icon: '🕐', label: 'Reading History', sub: 'Continue where you left off', to: '/history' },
          { icon: '🏆', label: 'Premium', sub: 'Upgrade for ad-free reading', to: '/premium' },
          isAdmin && { icon: '🛡', label: 'Admin Panel', sub: 'Manage content & users', to: '/admin' },
        ].filter(Boolean).map(item => (
          <Link key={item.to} to={item.to} className="profile-menu-item">
            <span className="profile-menu-item__icon">{item.icon}</span>
            <div className="profile-menu-item__text">
              <span className="profile-menu-item__label">{item.label}</span>
              <span className="profile-menu-item__sub">{item.sub}</span>
            </div>
            <span className="profile-menu-item__arrow">›</span>
          </Link>
        ))}

        <button
          className="profile-signout"
          onClick={() => { logout(); navigate('/'); }}
        >
          Sign out
        </button>
      </div>
    </div>
  );
}
