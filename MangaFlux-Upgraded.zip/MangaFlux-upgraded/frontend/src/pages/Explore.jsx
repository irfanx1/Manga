import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import api from '../utils/api';
import MangaCard, { MangaCardSkeleton } from '../components/manga/MangaCard';
import './Explore.css';

const GENRES = ['Action','Adventure','Comedy','Drama','Fantasy','Horror','Mystery','Romance','Sci-Fi','Slice of Life','Sports','Supernatural','Thriller','Isekai','Psychological','Shounen','Seinen'];
const TYPES = ['manga','manhwa','manhua','webtoon'];
const STATUSES = ['ongoing','completed','hiatus'];
const SORTS = [
  { value: '-lastUpdated', label: '🕐 Latest' },
  { value: '-views', label: '🔥 Popular' },
  { value: '-rating', label: '⭐ Top Rated' },
  { value: 'title', label: '🔤 A-Z' },
];

export default function Explore() {
  const [params, setParams] = useSearchParams();
  const [manga, setManga] = useState([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(true);
  const [filters, setFilters] = useState({
    genre: params.get('genre') || '',
    type: params.get('type') || '',
    status: '',
    sort: '-views',
  });

  const fetchManga = async (p = 1, reset = false) => {
    setLoading(true);
    try {
      const q = new URLSearchParams({ page: p, limit: 18, ...Object.fromEntries(Object.entries(filters).filter(([, v]) => v)) });
      const data = await api.get(`/manga?${q}`);
      setManga(prev => reset ? (data.manga || []) : [...prev, ...(data.manga || [])]);
      setTotal(data.total || 0);
      setPage(p);
    } finally { setLoading(false); }
  };

  useEffect(() => { fetchManga(1, true); }, [filters]);

  const setFilter = (key, val) => setFilters(f => ({ ...f, [key]: f[key] === val ? '' : val }));
  const clearAll = () => setFilters({ genre: '', type: '', status: '', sort: '-views' });

  const activeCount = [filters.genre, filters.type, filters.status].filter(Boolean).length;

  return (
    <div className="page explore-page">
      <div className="explore-header">
        <div>
          <p className="section-eyebrow">Discover</p>
          <h1 className="section-title">Explore</h1>
          <p className="explore-count">{total.toLocaleString()} titles</p>
        </div>
        <button className="filter-toggle-btn" onClick={() => setShowFilters(s => !s)}>
          🎛 Filters {activeCount > 0 && <span className="filter-badge">{activeCount}</span>}
        </button>
      </div>

      {showFilters && (
        <div className="explore-filters">
          {activeCount > 0 && (
            <button className="clear-filters-btn" onClick={clearAll}>✕ Clear all</button>
          )}
          <FilterGroup label="Sort by" options={SORTS.map(s => ({value:s.value,label:s.label}))} value={filters.sort} onChange={v => setFilters(f=>({...f,sort:v}))} single />
          <FilterGroup label="Type" options={TYPES.map(t=>({value:t,label:t}))} value={filters.type} onChange={v => setFilter('type', v)} />
          <FilterGroup label="Status" options={STATUSES.map(s=>({value:s,label:s}))} value={filters.status} onChange={v => setFilter('status', v)} />
          <FilterGroup label="Genre" options={GENRES.map(g=>({value:g,label:g}))} value={filters.genre} onChange={v => setFilter('genre', v)} />
        </div>
      )}

      <div className="explore-grid">
        {loading && manga.length === 0
          ? Array(12).fill(0).map((_, i) => <MangaCardSkeleton key={i} />)
          : manga.map(m => <MangaCard key={m._id} manga={m} />)
        }
      </div>

      {!loading && manga.length === 0 && (
        <div className="explore-empty">
          <span>🔍</span>
          <h3>No manga found</h3>
          <p>Try different filters</p>
          <button className="btn btn-ghost" onClick={clearAll}>Clear filters</button>
        </div>
      )}

      {manga.length < total && manga.length > 0 && (
        <div className="explore-load-more">
          <button className="btn btn-ghost load-more-wide" onClick={() => fetchManga(page + 1)} disabled={loading}>
            {loading ? 'Loading...' : `Load more (${manga.length}/${total})`}
          </button>
        </div>
      )}
    </div>
  );
}

function FilterGroup({ label, options, value, onChange, single }) {
  return (
    <div className="filter-group">
      <div className="filter-label">{label}</div>
      <div className="filter-chips">
        {options.map(o => (
          <button
            key={o.value}
            className={`filter-chip ${value === o.value ? 'active' : ''}`}
            onClick={() => onChange(single && value === o.value ? o.value : o.value)}
          >
            {o.label}
          </button>
        ))}
      </div>
    </div>
  );
}
