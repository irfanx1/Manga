import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import './Premium.css';

const PERKS = [
  { icon:'🚫', label:'Ad-free reading', sub:'Zero interruptions, pure immersion' },
  { icon:'🖼', label:'HD quality images', sub:'Crisp, high-resolution chapter pages' },
  { icon:'📥', label:'Offline mode', sub:'Download chapters to read anywhere' },
  { icon:'⚡', label:'Early access', sub:'New chapters before free users' },
  { icon:'🏷', label:'1,000+ exclusives', sub:'Premium-only manga and manhwa' },
  { icon:'💬', label:'Community perks', sub:'Premium badge, exclusive forums' },
];

const PLANS = [
  { id:'monthly', label:'Monthly', price:'$4.99', per:'/month', badge:null },
  { id:'annual', label:'Annual', price:'$39.99', per:'/year', badge:'Save 33%', highlight:true },
];

export default function Premium() {
  const { user } = useAuth();

  return (
    <div className="page premium-page">
      <div className="premium-hero">
        <div className="premium-hero__glow" />
        <span className="badge badge-premium">✦ MangaFlux Premium</span>
        <h1 className="premium-hero__title">Read without limits</h1>
        <p className="premium-hero__sub">The best manga reading experience — ad-free, HD, offline, and early access.</p>
      </div>

      {/* Plans */}
      <div className="premium-plans">
        {PLANS.map(plan => (
          <div key={plan.id} className={`premium-plan ${plan.highlight ? 'highlight' : ''}`}>
            {plan.badge && <span className="premium-plan__badge">{plan.badge}</span>}
            <div className="premium-plan__label">{plan.label}</div>
            <div className="premium-plan__price">{plan.price}</div>
            <div className="premium-plan__per">{plan.per}</div>
            <Link
              to={user ? '#' : '/register'}
              className={`btn ${plan.highlight ? 'btn-primary' : 'btn-ghost'} premium-plan__btn`}
            >
              {user ? 'Subscribe' : 'Start free trial'}
            </Link>
          </div>
        ))}
      </div>

      {/* Perks */}
      <div className="premium-perks-section">
        <p className="section-eyebrow">Everything included</p>
        <h2 className="section-title">What you get</h2>
        <div className="premium-perks">
          {PERKS.map(p => (
            <div key={p.label} className="premium-perk">
              <span className="premium-perk__icon">{p.icon}</span>
              <div>
                <div className="premium-perk__label">{p.label}</div>
                <div className="premium-perk__sub">{p.sub}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* FAQ */}
      <div className="premium-faq">
        <p className="section-eyebrow">Questions</p>
        <h2 className="section-title">FAQ</h2>
        {[
          ['Can I cancel anytime?','Yes. Cancel at any time from your profile. You keep premium until the end of your billing period.'],
          ['Is there a free trial?','New accounts get a 7-day free trial of Premium.'],
          ['What payment methods?','We accept all major credit cards, PayPal, and UPI.'],
          ['Are all titles available in Premium?','Yes — everything on MangaFlux, plus 1,000+ exclusive titles.'],
        ].map(([q,a]) => (
          <div key={q} className="faq-item">
            <div className="faq-q">{q}</div>
            <div className="faq-a">{a}</div>
          </div>
        ))}
      </div>

      <div className="premium-footer-note">
        By subscribing you agree to our <Link to="/terms">Terms of Service</Link>. Cancel anytime.
      </div>
    </div>
  );
}
