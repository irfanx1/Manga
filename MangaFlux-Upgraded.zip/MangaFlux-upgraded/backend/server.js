require('dotenv').config();
const express  = require('express');
const mongoose = require('mongoose');
const cors     = require('cors');
const helmet   = require('helmet');
const rateLimit = require('express-rate-limit');
const path     = require('path');

const app = express();

// ── Security middleware ──────────────────────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({
  origin: process.env.NODE_ENV === 'production'
    ? process.env.FRONTEND_URL
    : ['http://localhost:3000', 'http://127.0.0.1:3000'],
  credentials: true,
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// ── Rate limiting ────────────────────────────────────────────────────────────
app.use('/api/', rateLimit({ windowMs: 15 * 60 * 1000, max: 500, standardHeaders: true, legacyHeaders: false }));

// ── API Routes ───────────────────────────────────────────────────────────────
app.use('/api/auth',  require('./routes/auth'));
app.use('/api/manga', require('./routes/manga'));
app.use('/api/admin', require('./routes/admin'));

// ── Health check ─────────────────────────────────────────────────────────────
app.get('/api/health', (req, res) => res.json({ status: 'ok', time: new Date() }));

// ── Serve frontend in production ─────────────────────────────────────────────
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '../frontend/build')));
  app.get('*', (req, res) =>
    res.sendFile(path.join(__dirname, '../frontend/build/index.html')));
}

// ── Global error handler ─────────────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('[Error]', err.message);
  res.status(err.status || 500).json({ message: err.message || 'Server error' });
});

// ── Connect & boot ───────────────────────────────────────────────────────────
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/mangaflux')
  .then(async () => {
    console.log('✓ MongoDB connected');

    // Ensure default owner account exists
    const User = require('./models/User');
    const ownerExists = await User.findOne({ role: 'owner' });
    if (!ownerExists) {
      await User.create({
        username: 'admin',
        email:    process.env.ADMIN_EMAIL    || 'admin@mangaflux.com',
        password: process.env.ADMIN_PASSWORD || 'admin123',
        role: 'owner',
      });
      console.log('✓ Default owner created:', process.env.ADMIN_EMAIL || 'admin@mangaflux.com');
    }

    // Start auto-scraper
    if (process.env.AUTO_SCRAPE !== 'false') {
      const ScraperService = require('./services/scraper');
      ScraperService.start();
    } else {
      console.log('[ScraperService] AUTO_SCRAPE=false — skipping auto-start');
    }

    const PORT = process.env.PORT || 5000;
    app.listen(PORT, () => console.log(`✓ Server running on http://localhost:${PORT}`));
  })
  .catch(err => {
    console.error('✗ MongoDB connection failed:', err.message);
    process.exit(1);
  });
