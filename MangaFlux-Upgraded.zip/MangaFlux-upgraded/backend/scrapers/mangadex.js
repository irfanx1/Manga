const axios = require('axios');
const Manga = require('../models/Manga');
const Chapter = require('../models/Chapter');

const BASE = 'https://api.mangadex.org';
const COVERS = 'https://uploads.mangadex.org/covers';

// Retry wrapper — MangaDex rate-limits at ~5 req/s
async function apiGet(url, params = {}, retries = 3) {
  for (let i = 0; i < retries; i++) {
    try {
      const res = await axios.get(url, { params, timeout: 15000,
        headers: { 'User-Agent': 'MangaFlux/1.0 (contact@mangaflux.com)' } });
      return res.data;
    } catch (e) {
      if (e.response?.status === 429) {
        // Rate limited — wait and retry
        const wait = (i + 1) * 2000;
        console.log(`[MangaDex] Rate limited. Waiting ${wait}ms...`);
        await new Promise(r => setTimeout(r, wait));
      } else {
        console.error(`[MangaDex] ${url} error:`, e.message);
        return null;
      }
    }
  }
  return null;
}

async function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function fetchPopularManga(limit = 25) {
  const data = await apiGet(`${BASE}/manga`, {
    limit,
    order: { followedCount: 'desc' },
    includes: ['cover_art', 'author', 'artist'],
    availableTranslatedLanguage: ['en'],
    contentRating: ['safe', 'suggestive'],
    hasAvailableChapters: 'true',
  });
  return data?.data || [];
}

async function fetchChapters(mangadexId, limit = 10) {
  const data = await apiGet(`${BASE}/chapter`, {
    manga: mangadexId,
    limit,
    translatedLanguage: ['en'],
    order: { chapter: 'desc' },       // latest first
    contentRating: ['safe', 'suggestive'],
    includes: ['scanlation_group'],
  });
  return data?.data || [];
}

async function fetchChapterPages(chapterId) {
  const data = await apiGet(`${BASE}/at-home/server/${chapterId}`);
  if (!data) return [];
  const { baseUrl, chapter } = data;
  // prefer data-saver (smaller) for faster loads
  const files = chapter.dataSaver || chapter.data;
  const folder = chapter.dataSaver ? 'data-saver' : 'data';
  return (files || []).map((file, i) => ({
    pageNumber: i + 1,
    imageUrl: `${baseUrl}/${folder}/${chapter.hash}/${file}`,
  }));
}

function extractCover(manga) {
  const rel = manga.relationships?.find(r => r.type === 'cover_art');
  if (rel?.attributes?.fileName)
    return `${COVERS}/${manga.id}/${rel.attributes.fileName}.512.jpg`;
  return '';
}

function extractAuthors(manga, type = 'author') {
  return manga.relationships?.filter(r => r.type === type)
    .map(r => r.attributes?.name || '').filter(Boolean) || [];
}

function buildSlug(title, id) {
  return title.toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 80) + '-' + id.slice(0, 6);
}

async function scrapeManga() {
  console.log('[Scraper] ── Starting MangaDex scrape ──');
  const mangaList = await fetchPopularManga(25);
  if (!mangaList.length) {
    console.log('[Scraper] No manga returned. Check network / MangaDex status.');
    return;
  }

  let ok = 0, skipped = 0;

  for (const item of mangaList) {
    try {
      const attrs = item.attributes;
      const title = attrs.title?.en
        || attrs.title?.['ja-ro']
        || Object.values(attrs.title || {})[0]
        || 'Unknown';

      const slug = buildSlug(title, item.id);
      const coverImage = extractCover(item);
      const authors  = extractAuthors(item, 'author');
      const artists  = extractAuthors(item, 'artist');

      const type = attrs.originalLanguage === 'ko' ? 'manhwa'
                 : attrs.originalLanguage === 'zh' ? 'manhua'
                 : 'manga';

      const status = attrs.status === 'completed' ? 'completed'
                   : attrs.status === 'hiatus'    ? 'hiatus'
                   : 'ongoing';

      const genres = attrs.tags
        ?.filter(t => t.attributes?.group === 'genre')
        .map(t => t.attributes?.name?.en)
        .filter(Boolean) || [];

      const mangaData = {
        title, description: attrs.description?.en?.slice(0, 2000) || '',
        coverImage, type, status, genres, authors, artists,
        source: 'mangadex', sourceId: item.id,
        sourceUrl: `https://mangadex.org/title/${item.id}`,
        lastUpdated: new Date(),
      };

      // Upsert
      let manga = await Manga.findOne({ sourceId: item.id });
      if (manga) {
        Object.assign(manga, mangaData);
        await manga.save();
      } else {
        manga = await Manga.create({ ...mangaData, slug });
      }

      // Fetch latest chapters
      const chapters = await fetchChapters(item.id, 10);
      await sleep(300); // polite delay between manga

      let newChs = 0;
      for (const ch of chapters) {
        const chNum = parseFloat(ch.attributes?.chapter);
        if (isNaN(chNum)) continue;
        const exists = await Chapter.findOne({ manga: manga._id, number: chNum });
        if (exists) continue;

        await sleep(400); // polite delay between chapter page fetches
        const pages = await fetchChapterPages(ch.id);
        if (!pages.length) continue;

        await Chapter.create({
          manga: manga._id,
          number: chNum,
          title: ch.attributes?.title || `Chapter ${chNum}`,
          pages,
          source: 'mangadex',
          sourceId: ch.id,
          sourceUrl: `https://mangadex.org/chapter/${ch.id}`,
        });

        await Manga.findByIdAndUpdate(manga._id, {
          $inc: { chapterCount: 1 },
          $max: { latestChapter: chNum },
          lastUpdated: new Date(),
        });
        newChs++;
      }

      console.log(`[Scraper] ✓ ${title} — ${newChs} new chapter(s)`);
      ok++;
    } catch (e) {
      console.error('[Scraper] ✗ Error:', e.message);
      skipped++;
    }
  }
  console.log(`[Scraper] ── Done: ${ok} processed, ${skipped} errors ──`);
}

module.exports = { scrapeManga };
