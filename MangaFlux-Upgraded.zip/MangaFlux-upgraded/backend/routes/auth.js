const express = require('express');
const jwt     = require('jsonwebtoken');
const User    = require('../models/User');
const { protect } = require('../middleware/auth');
const router  = express.Router();

const signToken = (id) =>
  jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '30d',
  });

// ── Register ─────────────────────────────────────────────────────────────────
router.post('/register', async (req, res) => {
  try {
    const { username, email, password } = req.body;
    if (!username || !email || !password)
      return res.status(400).json({ message: 'All fields required' });
    if (password.length < 6)
      return res.status(400).json({ message: 'Password must be at least 6 characters' });

    const exists = await User.findOne({ $or: [{ email }, { username }] });
    if (exists) return res.status(400).json({ message: 'Username or email already taken' });

    const user = await User.create({ username, email, password });
    const token = signToken(user._id);
    res.status(201).json({ token, user });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

// ── Login ─────────────────────────────────────────────────────────────────────
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password)
      return res.status(400).json({ message: 'Email and password required' });

    const user = await User.findOne({ email }).select('+password');
    if (!user || !(await user.comparePassword(password)))
      return res.status(401).json({ message: 'Invalid email or password' });
    if (user.isBanned)
      return res.status(403).json({ message: 'Account suspended. Contact support.' });

    // update lastSeen
    User.findByIdAndUpdate(user._id, { lastSeen: new Date() }).exec();

    const token = signToken(user._id);
    res.json({ token, user: user.toJSON() });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

// ── Get current user ──────────────────────────────────────────────────────────
router.get('/me', protect, async (req, res) => {
  res.json({ user: req.user });
});

// ── Update profile ────────────────────────────────────────────────────────────
router.patch('/me', protect, async (req, res) => {
  try {
    const allowed = ['username', 'avatar', 'preferences'];
    const updates = {};
    allowed.forEach(f => { if (req.body[f] !== undefined) updates[f] = req.body[f]; });
    const user = await User.findByIdAndUpdate(req.user._id, updates, { new: true });
    res.json({ user });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

// ── Toggle bookmark ───────────────────────────────────────────────────────────
router.post('/bookmark/:mangaId', protect, async (req, res) => {
  try {
    const user  = await User.findById(req.user._id);
    const Manga = require('../models/Manga');
    const idx   = user.bookmarks.findIndex(b => b.toString() === req.params.mangaId);

    if (idx === -1) {
      user.bookmarks.push(req.params.mangaId);
      Manga.findByIdAndUpdate(req.params.mangaId, { $inc: { bookmarkCount: 1 } }).exec();
    } else {
      user.bookmarks.splice(idx, 1);
      Manga.findByIdAndUpdate(req.params.mangaId, { $inc: { bookmarkCount: -1 } }).exec();
    }
    await user.save();
    res.json({ bookmarked: idx === -1, bookmarks: user.bookmarks });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

// ── Delete account ────────────────────────────────────────────────────────────
router.delete('/me', protect, async (req, res) => {
  try {
    await User.findByIdAndDelete(req.user._id);
    res.json({ message: 'Account deleted' });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

module.exports = router;
