const express = require('express');
const User    = require('../models/User');
const Manga   = require('../models/Manga');
const Chapter = require('../models/Chapter');
const { protect, restrictTo } = require('../middleware/auth');
const router = express.Router();

router.use(protect, restrictTo('admin', 'owner'));

// ── Dashboard stats ──────────────────────────────────────────────────────────
router.get('/stats', async (req, res) => {
  try {
    const [users, manga, chapters, activeToday] = await Promise.all([
      User.countDocuments(),
      Manga.countDocuments(),
      Chapter.countDocuments(),
      User.countDocuments({ lastSeen: { $gte: new Date(Date.now() - 86400000) } }),
    ]);
    const topManga = await Manga.find().sort('-views').limit(5)
      .select('title views coverImage slug rating');
    const recentManga = await Manga.find().sort('-createdAt').limit(5)
      .select('title createdAt type source');
    res.json({ users, manga, chapters, activeToday, topManga, recentManga });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

// ── Scraper status ───────────────────────────────────────────────────────────
router.get('/scraper/status', async (req, res) => {
  const ScraperService = require('../services/scraper');
  res.json(ScraperService.getStatus());
});

// ── Toggle scraper ───────────────────────────────────────────────────────────
router.post('/scraper/toggle', restrictTo('owner'), async (req, res) => {
  try {
    const ScraperService = require('../services/scraper');
    req.body.enabled ? ScraperService.start() : ScraperService.stop();
    res.json({ enabled: req.body.enabled });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

// ── Manual scrape ────────────────────────────────────────────────────────────
router.post('/scraper/run', restrictTo('owner'), async (req, res) => {
  try {
    const ScraperService = require('../services/scraper');
    // respond immediately, run in background
    res.json({ message: 'Scraper started in background' });
    ScraperService.runNow(req.body.source || 'mangadex');
  } catch (err) { res.status(500).json({ message: err.message }); }
});

// ── Users list ───────────────────────────────────────────────────────────────
router.get('/users', async (req, res) => {
  try {
    const { page = 1, limit = 30, search } = req.query;
    const q = search ? { $or: [
      { username: new RegExp(search, 'i') },
      { email:    new RegExp(search, 'i') }
    ]} : {};
    const [users, total] = await Promise.all([
      User.find(q).sort('-createdAt').limit(Number(limit)).skip((Number(page)-1)*Number(limit)),
      User.countDocuments(q),
    ]);
    res.json({ users, total });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

// ── Ban / unban ──────────────────────────────────────────────────────────────
router.patch('/users/:id/ban', restrictTo('owner'), async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(
      req.params.id, { isBanned: req.body.isBanned }, { new: true });
    res.json({ user });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

// ── Set role ─────────────────────────────────────────────────────────────────
router.patch('/users/:id/role', restrictTo('owner'), async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(
      req.params.id, { role: req.body.role }, { new: true });
    res.json({ user });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

// ── Grant / revoke premium ───────────────────────────────────────────────────
router.patch('/users/:id/premium', restrictTo('owner'), async (req, res) => {
  try {
    const until = req.body.months
      ? new Date(Date.now() + req.body.months * 30 * 86400000)
      : null;
    const user = await User.findByIdAndUpdate(req.params.id, {
      isPremium: req.body.isPremium,
      premiumUntil: until,
    }, { new: true });
    res.json({ user });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

// ── Feature / unfeature manga ────────────────────────────────────────────────
router.patch('/manga/:id/feature', async (req, res) => {
  try {
    const manga = await Manga.findByIdAndUpdate(
      req.params.id, { featured: req.body.featured }, { new: true });
    res.json({ manga });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

// ── Delete manga + chapters ──────────────────────────────────────────────────
router.delete('/manga/:id', async (req, res) => {
  try {
    await Manga.findByIdAndDelete(req.params.id);
    await Chapter.deleteMany({ manga: req.params.id });
    res.json({ message: 'Deleted' });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

module.exports = router;
