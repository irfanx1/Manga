const express = require('express');
const Manga   = require('../models/Manga');
const Chapter = require('../models/Chapter');
const { protect, restrictTo, optionalAuth } = require('../middleware/auth');
const router = express.Router();

// ── List / search manga ──────────────────────────────────────────────────────
router.get('/', optionalAuth, async (req, res) => {
  try {
    const {
      page = 1, limit = 20,
      genre, status, type, sort = '-lastUpdated',
      search, featured, isPremium
    } = req.query;

    const query = { isPublished: true };
    if (genre)     query.genres  = { $in: [genre] };
    if (status)    query.status  = status;
    if (type)      query.type    = type;
    if (featured)  query.featured   = true;
    if (isPremium) query.isPremium  = isPremium === 'true';
    if (search)    query.$text = { $search: search };

    const [total, manga] = await Promise.all([
      Manga.countDocuments(query),
      Manga.find(query)
        .sort(sort)
        .limit(Math.min(Number(limit), 100))
        .skip((Number(page) - 1) * Math.min(Number(limit), 100))
        .select('title coverImage type status genres rating views bookmarkCount chapterCount latestChapter lastUpdated slug featured isPremium'),
    ]);

    res.json({ manga, total, page: Number(page), pages: Math.ceil(total / Number(limit)) });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

// ── Single manga by slug ─────────────────────────────────────────────────────
router.get('/:slug', optionalAuth, async (req, res) => {
  try {
    const manga = await Manga.findOne({ slug: req.params.slug, isPublished: true });
    if (!manga) return res.status(404).json({ message: 'Manga not found' });

    // increment views without blocking response
    Manga.findByIdAndUpdate(manga._id, { $inc: { views: 1 } }).exec();

    const chapters = await Chapter.find({ manga: manga._id, isPublished: true })
      .sort('-number')
      .select('number title views uploadedAt');

    res.json({ manga, chapters });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

// ── Single chapter ───────────────────────────────────────────────────────────
router.get('/:slug/chapter/:number', optionalAuth, async (req, res) => {
  try {
    const manga = await Manga.findOne({ slug: req.params.slug })
      .select('title slug coverImage');
    if (!manga) return res.status(404).json({ message: 'Manga not found' });

    const num = Number(req.params.number);
    const chapter = await Chapter.findOne({ manga: manga._id, number: num });
    if (!chapter) return res.status(404).json({ message: 'Chapter not found' });

    // increment views without blocking
    Chapter.findByIdAndUpdate(chapter._id, { $inc: { views: 1 } }).exec();

    // Track read history for logged-in users
    if (req.user) {
      const User = require('../models/User');
      User.findByIdAndUpdate(req.user._id, {
        $push: {
          readHistory: {
            $each: [{ manga: manga._id, chapter: chapter._id, readAt: new Date() }],
            $slice: -200,  // keep last 200
          }
        },
        lastSeen: new Date(),
      }).exec();
    }

    const [prev, next] = await Promise.all([
      Chapter.findOne({ manga: manga._id, number: num - 1 }).select('number title'),
      Chapter.findOne({ manga: manga._id, number: num + 1 }).select('number title'),
    ]);

    res.json({ manga, chapter, prev, next });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

// ── Create manga (admin) ─────────────────────────────────────────────────────
router.post('/', protect, restrictTo('admin', 'owner'), async (req, res) => {
  try {
    const manga = await Manga.create(req.body);
    res.status(201).json({ manga });
  } catch (err) { res.status(400).json({ message: err.message }); }
});

// ── Update manga (admin) ─────────────────────────────────────────────────────
router.patch('/:id', protect, restrictTo('admin', 'owner'), async (req, res) => {
  try {
    const manga = await Manga.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json({ manga });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

// ── Delete manga (admin) ─────────────────────────────────────────────────────
router.delete('/:id', protect, restrictTo('admin', 'owner'), async (req, res) => {
  try {
    await Manga.findByIdAndDelete(req.params.id);
    await Chapter.deleteMany({ manga: req.params.id });
    res.json({ message: 'Deleted' });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

// ── Add chapter (admin) ──────────────────────────────────────────────────────
router.post('/:id/chapters', protect, restrictTo('admin', 'owner'), async (req, res) => {
  try {
    const chapter = await Chapter.create({ ...req.body, manga: req.params.id });
    await Manga.findByIdAndUpdate(req.params.id, {
      $inc: { chapterCount: 1 },
      $max: { latestChapter: chapter.number },
      lastUpdated: new Date(),
    });
    res.status(201).json({ chapter });
  } catch (err) { res.status(400).json({ message: err.message }); }
});

module.exports = router;
